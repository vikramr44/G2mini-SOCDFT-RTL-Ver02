"""Write dv_eco/tb_soc_dft_eco.sv, the directed bench of the change round of
12 Nov 2026 (tests T01-T19 of
docs/SemiCond/Gemini_dft/change-20261112/G2M-DIRECTED-TESTS-2026-11-12.md).

REVIEW DRAFT - NOT GATED. The delivered bench dv/tb_soc_dft.sv is frozen and
is not touched; this bench lives beside it in dv_eco/ and copies its style:
the same TCK1, the same TAP walks, chk / chk_eq, and the log lines
TEST START / PT / TEST PASS / TEST FAIL and RESULT.

The lane slices are read from rtl/dft_part_map_pkg.sv (scan_mode_sel,
lane_lo, nch, chan_base), the one table the router uses. Tests T03-T09 also
hold that table to the lane slices written as numbers below (LIT_SLICES),
so a wrong table entry that the router and the elaboration check both
follow is still caught by the bench. A later answer to K12 changes the
table AND the ASSUMED K12 rows of LIT_SLICES.

Usage (from the package): python -I -X utf8 dv_eco/gen_tb_soc_dft_eco.py [out.sv]
With no argument the bench is written to dv_eco/tb_soc_dft_eco.sv.
"""
import os
import sys

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(PKG, "dv_eco", "tb_soc_dft_eco.sv")

# name, block index, width (C3/C11; K1 = 8, K2 = 4, K3 = 12)
BLOCKS = [("scc", 0, 6), ("hic", 1, 6), ("g2muc", 2, 8), ("l4ga", 3, 8), ("l4gb", 4, 8),
          ("pcia", 5, 12), ("pcib", 6, 12), ("ahb", 7, 4), ("apb", 8, 4), ("axis", 9, 8),
          ("axim", 10, 4)]
# delivered SMS ports kept (OPEN S1, K16): name, in width, out width
SMS_KEPT = [("scc", 5, 1), ("hic", 5, 1), ("l4ga", 5, 1), ("l4gb", 5, 1), ("ahb", 5, 1),
            ("lpddr", 5, 1), ("pcia", 10, 2), ("pcib", 10, 2)]
GUCC_OUT = ["WSI", "UpdateWR", "SelectWIR", "ShiftWR", "CaptureWR", "index_based_repair"]
GUCC = [f"vl_sms_u_1_sms_sram_proc_TopGucc_{i}" for i in (1, 2)]
# the DDR controls compared with the delivered design every half cycle (T16)
DDR_OUT = [("lpddr_atpg_mode", 1), ("lpddr_compression_mode", 1), ("lpddr_phy0_burnin", 1),
           ("lpddr_phy1_burnin", 1), ("lpddr_atpg_se", 16), ("lpddr_scan_ctl", 2),
           ("lpddr_scan_shift_cg", 1), ("lpddr_scan_rstn", 1), ("lpddr_sms_dm", 3),
           ("lpddr_ring_bypass", 7), ("lpddr_sfp_dft_mode", 1), ("lpddr_tdrclk", 1),
           ("lpddr_wrstn", 1), ("lpddr_cmd_tdr_capture_en", 2), ("lpddr_cmd_tdr_shift_en", 2),
           ("lpddr_cmd_tdr_update_en", 2), ("lpddr_rd_tdr_capture_en", 2),
           ("lpddr_rd_tdr_shift_en", 2), ("lpddr_rd_tdr_update_en", 2), ("lpddr_wsi", 2),
           ("lpddr_sms_in", 5), ("dft_crg_lpddr_clk_en", 5)]
CRG_OUT = [("dft_crg_test_clk_sel", 1), ("dft_crg_pll_byp", 3), ("dft_crg_blk_clk_en", 13),
           ("dft_crg_comp_clk_en", 13), ("dft_crg_rst_byp", 1), ("dft_crg_rst_n_test", 1)]
# delivered per-block widths, for the reference instance (rtl_delivered/soc_dft.sv)
DLV_W = {"scc": 5, "hic": 5, "g2muc": 6, "l4ga": 3, "l4gb": 3, "pcia": 20, "pcib": 20,
         "ahb": 6, "apb": 4, "axis": 3, "axim": 4}

# FIX 5: the expected lane slices of modes 1-6, written as numbers in the
# bench and never read from dft_part_map_pkg: mode -> [(block, hi, lo)].
# Modes 1 and 6 are as the customer drew them; modes 2-5 are ASSUMED K12
# (the values the table holds today).
LIT_SLICES = {
    1: [("pcia", 19, 8), ("axis", 7, 0)],
    2: [("pcib", 19, 8), ("axis", 7, 0)],                     # ASSUMED K12
    3: [("g2muc", 19, 12), ("axim", 11, 8), ("axis", 7, 0)],  # ASSUMED K12
    4: [("l4ga", 19, 12), ("ahb", 11, 8), ("axis", 7, 0)],    # ASSUMED K12
    5: [("l4gb", 19, 12), ("apb", 11, 8), ("axis", 7, 0)],    # ASSUMED K12
    6: [("scc", 19, 14), ("hic", 13, 8), ("axis", 7, 0)],
}
LIT_SOURCE = {1: "as the customer drew it", 6: "as the customer drew it"}

TESTS = [
    ("t_reset_defaults", "T01", "C0a, C0"),
    ("t_mode0_lpddr", "T02", "C5, C6, K17"),
    ("t_mode1_pcia_axis", "T03", "C5, C6"),
    ("t_mode2_pcib_axis", "T04", "C5, C6"),
    ("t_mode3_g2muc_axim_axis", "T05", "C5, C6, K12"),
    ("t_mode4_l4ga_ahb_axis", "T06", "C5, C6, K1, K2, K12"),
    ("t_mode5_l4gb_apb_axis", "T07", "C5, C6, K1, K12"),
    ("t_mode6_scc_hic_axis", "T08", "C5, C6, K14"),
    ("t_axis_6to1_mux", "T09", "C5, K13"),
    ("t_mode7_extest", "T10", "C9, K8"),
    ("t_mode_switch", "T11", "C4, C5, K10"),
    ("t_pad_loopback", "T12", "C7, K7"),
    ("t_test_mode_tdr", "T13", "C0a"),
    ("t_dfttm_dftse_passthrough", "T14", "C1"),
    ("t_dftmax_not_decoded", "T15", "C2, K9"),
    ("t_ddr_controls_unchanged", "T16", "C0"),
    ("t_jtag_regression", "T17", "C0"),
    ("t_sms_connectivity", "T19", "C8, K15, K16"),
]


def wdecl(w):
    return f"[{w-1}:0] " if w > 1 else ""


L = []
a = L.append
a("// Artifact identity: Verification environment")
a("// =====================================================================")
a("// REVIEW DRAFT - NOT GATED. Directed bench of the change round of 12 Nov")
a("// 2026 (T01-T19 of G2M-DIRECTED-TESTS-2026-11-12.md), beside the frozen")
a("// delivered bench dv/tb_soc_dft.sv, which is not touched.")
a("//")
a("// GENERATED by dv_eco/gen_tb_soc_dft_eco.py. Edit the generator and re-run")
a("// it rather than editing this file.")
a("//")
a("// The log grammar is the delivered bench's, plus one PT line per test:")
a("//   TEST START <name> / PT <name> checks=<n> cycles=<n> / TEST PASS <name>")
a("//   TEST FAIL <name> / RESULT PASS / RESULT FAIL")
a("//")
a("// Two designs are built: u_dut (rtl/, the change) and u_ref")
a("// (dv_eco/ref_delivered/, the delivered RTL with every module renamed")
a("// <name>_dlv). Both see the same pads. Every DDR control output is compared")
a("// between them twice per TCK1 cycle for the whole run (T16), and the JTAG")
a("// outputs during T17.")
a("//")
a("// The lane slices are read from dft_part_map_pkg (scan_mode_sel, lane_lo,")
a("// nch, chan_base): the one table the router uses. Modes 2-5 follow it as")
a("// ASSUMED K12. T03-T09 also hold that table, and the pins, to the lane")
a("// slices written as numbers in lit_in / lit_lo / lit_w below, so the bench")
a("// does not only follow the table it checks.")
a("//")
a("// T18 (removed ports) is a compile and lint check, not a test of this")
a("// bench: dv_eco/run_eco.ps1 prints it in the same log grammar.")
a("// =====================================================================")
a("// No `timescale directive, as in the delivered bench.")
a("")
a("module tb_soc_dft_eco;")
a("  import dft_part_map_pkg::*;")
a("")
a("  localparam int unsigned TAP_IR_LEN   = 5;")
a("  localparam int unsigned SMS_IR_LEN   = 4;")
a("  localparam int unsigned CHAIN_IR_LEN = TAP_IR_LEN + SMS_IR_LEN;")
a("  localparam logic [4:0]  IRC_DTR_CFG   = 5'b00010;")
a("  localparam logic [4:0]  IRC_DTR_LPDDR = 5'b00011;")
a("  localparam logic [4:0]  IRC_DTR_STS   = 5'b00100;")
a("  localparam logic [4:0]  IRC_DTR_TM    = 5'b01001;   // ASSUMED code (rtl/dft_part_map_pkg.sv IR_DTR_TM)")
a("  localparam logic [31:0] CFG_RESET     = 32'h003F_FFA5 & 32'h007F_FFFF;")
a("  localparam logic [31:0] P_IDCODE_EXPECTED     = 32'h0000_0001;")
a("  localparam logic [31:0] P_SMS_IDCODE_EXPECTED = 32'h0001_0001;")
a("  localparam logic        DFTMAX_COMP  = 1'b1;   // P_DFTMAX_COMP default")
a("  localparam logic        DFTMAX_PLAIN = 1'b0;")
a("")
a("  // ------------------------------------------------- the pads (shared)")
for n, w in [("DFTTM", 1), ("DFTMAX", 1), ("DFTSE", 1), ("DFTSI", 20), ("DeMuxSel", 3),
             ("TSEL1", 2), ("TCK1", 1), ("TMS1", 1), ("TDI1", 1), ("TRSTN1", 1), ("PwrOk", 1),
             ("Rstn", 1), ("arc_tdo1", 1), ("arc_tdo1_oe", 1), ("pcia_tdo1", 1),
             ("pcia_tdo1_oe", 1), ("pcib_tdo1", 1), ("pcib_tdo1_oe", 1),
             ("lpddr_cmd_tdr_tdo", 2), ("lpddr_rd_tdr_tdo", 2), ("crg_pll_ready", 3)]:
    a(f"  logic {wdecl(w)}{n};")
a("")
a("  // ------------------------------------------------- u_dut returns (driven by the bench)")
for p, i, w in BLOCKS:
    a(f"  logic {wdecl(w)}{p}_test_so;")
    a(f"  logic {p}_wrap_so;")
a("  logic [2:0] top_test_so;")
a("  logic [19:0] lpddr_test_so;")
for p, wi, wo in SMS_KEPT:
    a(f"  logic {wdecl(wo)}{p}_sms_out;")
for g in GUCC:
    a(f"  logic {g}_WSO;")
a("")
a("  // ------------------------------------------------- u_dut outputs")
for n, w in [("DFTSO", 20), ("DFTSO_OE", 1), ("TDO1", 1), ("TDO1_OE", 1), ("arc_tms1", 1),
             ("pcia_tms1", 1), ("pcib_tms1", 1), ("dftmax_out", 1), ("top_scan_shift_en", 1),
             ("top_test_si", 3), ("lpddr_test_si", 20)]:
    a(f"  logic {wdecl(w)}{n};")
for p, i, w in BLOCKS:
    a(f"  logic {p}_dfttm;")
    a(f"  logic {p}_scan_shift_en;")
    if p != "ahb":
        a(f"  logic {p}_wrap_shift_en;")
    a(f"  logic [1:0] {p}_test_mode;")
    a(f"  logic {wdecl(w)}{p}_test_si;")
    a(f"  logic {p}_wrap_si;")
for p, wi, wo in SMS_KEPT:
    a(f"  logic {wdecl(wi)}{p}_sms_in;")
for g in GUCC:
    for s in GUCC_OUT:
        a(f"  logic {g}_{s};")
for n, w in DDR_OUT + CRG_OUT:
    if n == "lpddr_sms_in":
        continue
    a(f"  logic {wdecl(w)}{n};")
a("")
a("  // ------------------------------------------------- u_ref outputs (delivered)")
for n, w in [("DFTSO", 20), ("DFTSO_OE", 1), ("TDO1", 1), ("TDO1_OE", 1), ("arc_tms1", 1),
             ("pcia_tms1", 1), ("pcib_tms1", 1)]:
    a(f"  logic {wdecl(w)}r_{n};")
for n, w in DDR_OUT + CRG_OUT:
    a(f"  logic {wdecl(w)}r_{n};")
a("")
a("  int unsigned errors;")
a("  int unsigned checks;")
a("  int unsigned test_errors;")
a("  int unsigned tests;")
a("  int unsigned tests_passed;")
a("  int unsigned cycles;")
a("  int unsigned test_checks0;")
a("  int unsigned test_cycles0;")
a("  int unsigned ddr_compares;")
a("  int unsigned ddr_mismatches;")
a("  int unsigned jtag_compares;")
a("  int unsigned jtag_mismatches;")
a("  bit          jtag_compare_on;")
a("  logic [31:0] rng;")
a("")

# ---------------------------------------------------------------- DUT
a("  // ------------------------------------------------------------- u_dut")
a("  soc_dft u_dut (")
conns = []
for n in ["DFTTM", "DFTMAX", "dftmax_out", "DFTSE", "DFTSI", "DFTSO", "DFTSO_OE", "DeMuxSel",
          "TSEL1", "TMS1", "TDI1", "TDO1", "TDO1_OE", "TCK1", "TRSTN1", "PwrOk", "Rstn",
          "arc_tms1", "pcia_tms1", "pcib_tms1", "arc_tdo1", "arc_tdo1_oe", "pcia_tdo1",
          "pcia_tdo1_oe", "pcib_tdo1", "pcib_tdo1_oe"]:
    conns.append((n, n))
for p, i, w in BLOCKS:
    for s in ["dfttm", "scan_shift_en"] + ([] if p == "ahb" else ["wrap_shift_en"]) + \
             ["test_mode", "test_si", "test_so", "wrap_si", "wrap_so"]:
        conns.append((f"{p}_{s}", f"{p}_{s}"))
conns += [("top_scan_shift_en", "top_scan_shift_en"), ("top_test_si", "top_test_si"),
          ("top_test_so", "top_test_so")]
for p, wi, wo in SMS_KEPT:
    conns += [(f"{p}_sms_in", f"{p}_sms_in"), (f"{p}_sms_out", f"{p}_sms_out")]
for g in GUCC:
    conns.append((f"{g}_WSO", f"{g}_WSO"))
    for s in GUCC_OUT:
        conns.append((f"{g}_{s}", f"{g}_{s}"))
conns += [("lpddr_test_si", "lpddr_test_si"), ("lpddr_test_so", "lpddr_test_so")]
for n, w in DDR_OUT + CRG_OUT:
    if n != "lpddr_sms_in":
        conns.append((n, n))
conns += [("lpddr_cmd_tdr_tdo", "lpddr_cmd_tdr_tdo"), ("lpddr_rd_tdr_tdo", "lpddr_rd_tdr_tdo"),
          ("crg_pll_ready", "crg_pll_ready")]
for k, (port, sig) in enumerate(conns):
    a(f"      .{port}({sig})" + ("," if k < len(conns) - 1 else ""))
a("  );")
a("")

# ---------------------------------------------------------------- REF
a("  // ------------------------------------------------------------- u_ref")
a("  // The delivered design on the same pads. Its block returns are tied to 0:")
a("  // only its DDR controls and its JTAG outputs are compared, and neither")
a("  // reads a block return. Its block-side outputs are not read.")
a("  soc_dft_dlv u_ref (")
rc = []
for n in ["DFTTM", "DFTMAX", "DFTSE", "DFTSI", "TSEL1", "TMS1", "TDI1", "TCK1", "TRSTN1",
          "PwrOk", "Rstn", "arc_tdo1", "arc_tdo1_oe", "pcia_tdo1", "pcia_tdo1_oe", "pcib_tdo1",
          "pcib_tdo1_oe", "lpddr_cmd_tdr_tdo", "lpddr_rd_tdr_tdo", "crg_pll_ready"]:
    rc.append((n, n))
for n in ["DFTSO", "DFTSO_OE", "TDO1", "TDO1_OE", "arc_tms1", "pcia_tms1", "pcib_tms1"]:
    rc.append((n, f"r_{n}"))
for p, i, w in BLOCKS:
    dw = DLV_W[p]
    for s in ["dfttm", "scan_shift_en", "wrap_shift_en", "test_mode", "test_mode_tp",
              "test_si", "wrap_si"]:
        rc.append((f"{p}_{s}", ""))
    rc.append((f"{p}_test_so", f"{dw}'d0"))
    rc.append((f"{p}_wrap_so", "2'd0"))
rc += [("top_scan_shift_en", ""), ("top_test_si", ""), ("top_test_so", "3'd0")]
for p in ["scc", "hic", "g2muc", "l4ga", "l4gb", "ahb", "lpddr"]:
    rc += [(f"{p}_sms_in", "r_lpddr_sms_in" if p == "lpddr" else ""), (f"{p}_sms_out", "1'b0")]
for p in ["pcia", "pcib"]:
    rc += [(f"{p}_sms_in", ""), (f"{p}_sms_out", "2'd0")]
for n, w in DDR_OUT + CRG_OUT:
    if n != "lpddr_sms_in":
        rc.append((n, f"r_{n}"))
for k, (port, sig) in enumerate(rc):
    a(f"      .{port}({sig})" + ("," if k < len(rc) - 1 else ""))
a("  );")
a("")

# ---------------------------------------------------------------- per-block access
a("  // ------------------------------------------------- per-block access by index")
a("  function automatic string blk_name(input int unsigned b);")
a("    case (b)")
for p, i, w in BLOCKS:
    a(f"      {i}: blk_name = \"{p}\";")
a("      default: blk_name = \"?\";")
a("    endcase")
a("  endfunction")
a("")
a("  function automatic logic [19:0] blk_si(input int unsigned b);")
a("    case (b)")
for p, i, w in BLOCKS:
    a(f"      {i}: blk_si = 20'({p}_test_si);")
a("      default: blk_si = '0;")
a("    endcase")
a("  endfunction")
a("")
a("  task automatic set_blk_so(input int unsigned b, input logic [19:0] v);")
a("    case (b)")
for p, i, w in BLOCKS:
    a(f"      {i}: {p}_test_so = v[{w-1}:0];")
a("      default: ;")
a("    endcase")
a("  endtask")
a("")
a("  function automatic logic blk_wsi(input int unsigned b);")
a("    case (b)")
for p, i, w in BLOCKS:
    a(f"      {i}: blk_wsi = {p}_wrap_si;")
a("      default: blk_wsi = 1'b0;")
a("    endcase")
a("  endfunction")
a("")
a("  task automatic set_blk_wso(input int unsigned b, input logic v);")
a("    case (b)")
for p, i, w in BLOCKS:
    a(f"      {i}: {p}_wrap_so = v;")
a("      default: ;")
a("    endcase")
a("  endtask")
a("")
a("  function automatic logic [1:0] blk_tm(input int unsigned b);")
a("    case (b)")
for p, i, w in BLOCKS:
    a(f"      {i}: blk_tm = {p}_test_mode;")
a("      default: blk_tm = 2'b00;")
a("    endcase")
a("  endfunction")
a("")
a("  // {wrap_shift_en, scan_shift_en, dfttm}; ahb has no wrap_shift_en (C0),")
a("  // so its bit 2 reads the scan shift enable and is not checked apart.")
a("  function automatic logic [2:0] blk_pad(input int unsigned b);")
a("    case (b)")
for p, i, w in BLOCKS:
    wse = f"{p}_scan_shift_en" if p == "ahb" else f"{p}_wrap_shift_en"
    a(f"      {i}: blk_pad = {{{wse}, {p}_scan_shift_en, {p}_dfttm}};")
a("      default: blk_pad = 3'b000;")
a("    endcase")
a("  endfunction")
a("")
a("  // Every block's scan-side outputs as one word, for 'nothing moved' checks.")
a("  function automatic logic [127:0] blk_state();")
parts = []
for p, i, w in BLOCKS:
    parts += [f"{p}_test_si", f"{p}_wrap_si", f"{p}_test_mode"]
a("    blk_state = 128'({" + ", ".join(parts) + "});")
a("  endfunction")
a("")

# ---------------------------------------------------------------- literal lane slices (FIX 5)
BIDX = {p: i for p, i, w in BLOCKS}
a("  // ------------------------------------------------- the lane slices as numbers")
a("  // The expected lanes of modes 1-6, written here as numbers and NOT read")
a("  // from dft_part_map_pkg, so that a wrong table entry the router follows is")
a("  // still caught. Modes 1 and 6 are as the customer drew them; modes 2-5")
a("  // are ASSUMED K12 (the table's values today, written out).")
for m in sorted(LIT_SLICES):
    src = LIT_SOURCE.get(m, "ASSUMED K12")
    a(f"  //   mode {m} ({src}): " +
      ", ".join(f"{p} {hi}:{lo}" for p, hi, lo in LIT_SLICES[m]))
a("  function automatic bit lit_in(input int unsigned m, input int unsigned b);")
a("    lit_in = 1'b0;")
for m in sorted(LIT_SLICES):
    for p, hi, lo in LIT_SLICES[m]:
        a(f"    if (m == {m} && b == {BIDX[p]}) lit_in = 1'b1;   // {p}")
a("  endfunction")
a("")
a("  function automatic int unsigned lit_lo(input int unsigned m, input int unsigned b);")
a("    lit_lo = 0;")
for m in sorted(LIT_SLICES):
    for p, hi, lo in LIT_SLICES[m]:
        a(f"    if (m == {m} && b == {BIDX[p]}) lit_lo = {lo};   // mode {m} {p} {hi}:{lo}")
a("  endfunction")
a("")
a("  function automatic int unsigned lit_w(input int unsigned m, input int unsigned b);")
a("    lit_w = 0;")
for m in sorted(LIT_SLICES):
    for p, hi, lo in LIT_SLICES[m]:
        a(f"    if (m == {m} && b == {BIDX[p]}) lit_w = {hi - lo + 1};   // mode {m} {p} {hi}:{lo}")
a("  endfunction")
a("")

BODY = r'''
  // ------------------------------------------------- TCK1, the only clock
  initial TCK1 = 1'b0;
  always #5 TCK1 = ~TCK1;

  // T16: every DDR control of u_dut against the delivered design u_ref,
  // twice per TCK1 cycle (high and low phase) for the whole run.
  task automatic ddr_compare(input string where);
    ddr_compares = ddr_compares + 1;
@@DDR_COMPARE@@
  endtask

  // T17: the JTAG outputs against the delivered design, while switched on.
  task automatic jtag_compare(input string where);
    if (jtag_compare_on) begin
      jtag_compares = jtag_compares + 1;
      if ({TDO1, TDO1_OE, arc_tms1, pcia_tms1, pcib_tms1} !==
          {r_TDO1, r_TDO1_OE, r_arc_tms1, r_pcia_tms1, r_pcib_tms1}) begin
        jtag_mismatches = jtag_mismatches + 1;
        if (jtag_mismatches <= 10)
          $display("JTAG MISMATCH %s: {TDO1,OE,arc,pcia,pcib} new %b delivered %b", where,
                   {TDO1, TDO1_OE, arc_tms1, pcia_tms1, pcib_tms1},
                   {r_TDO1, r_TDO1_OE, r_arc_tms1, r_pcia_tms1, r_pcib_tms1});
      end
    end
  endtask

  task automatic sample(input string where);
    ddr_compare(where);
    jtag_compare(where);
  endtask

  // One cycle, returning in the LOW phase with the cycle's outputs settled,
  // as the delivered bench's `tick`.
  task automatic tick(input int unsigned n = 1);
    for (int unsigned i = 0; i < n; i++) begin
      @(posedge TCK1);
      cycles = cycles + 1;
      #1;
      sample("high phase");
      @(negedge TCK1);
      #1;
      sample("low phase");
    end
  endtask

  // Let combinational paths settle without moving the clock.
  task automatic settle_comb();
    #1;
  endtask

  // --------------------------------------------------------- the checkers
  task automatic chk(input logic cond, input string what);
    checks = checks + 1;
    if (cond !== 1'b1) begin
      test_errors = test_errors + 1;
      errors = errors + 1;
      $display("CHECK FAIL %s", what);
    end
  endtask

  task automatic chk_eq(input logic [63:0] got, input logic [63:0] exp,
                        input string what);
    checks = checks + 1;
    if (got !== exp) begin
      test_errors = test_errors + 1;
      errors = errors + 1;
      $display("CHECK FAIL %s: got %0h expected %0h", what, got, exp);
    end
  endtask

  // A deterministic pattern source, the same on every simulator.
  function automatic logic [31:0] lfsr_next(input logic [31:0] s);
    lfsr_next = {s[30:0], s[31] ^ s[21] ^ s[1] ^ s[0]};
  endfunction
  task automatic next_rng();
    rng = lfsr_next(rng);
  endtask

  // --------------------------------------------------------- the stimulus
  task automatic idle_inputs();
    DFTTM = 1'b0; DFTMAX = DFTMAX_PLAIN; DFTSE = 1'b0; DFTSI = '0; DeMuxSel = 3'd0;
    TSEL1 = 2'd0; TMS1 = 1'b1; TDI1 = 1'b0;
    TRSTN1 = 1'b1; PwrOk = 1'b1; Rstn = 1'b1;
    arc_tdo1 = 1'b0; arc_tdo1_oe = 1'b0;
    pcia_tdo1 = 1'b0; pcia_tdo1_oe = 1'b0;
    pcib_tdo1 = 1'b0; pcib_tdo1_oe = 1'b0;
    for (int unsigned b = 0; b < NSCAN; b++) begin
      set_blk_so(b, '0);
      set_blk_wso(b, 1'b0);
    end
    top_test_so = '0;
    lpddr_test_so = '0;
@@SMS_IDLE@@
    lpddr_cmd_tdr_tdo = '0;
    lpddr_rd_tdr_tdo = '0;
    crg_pll_ready = '0;
  endtask

  task automatic cold_reset();
    idle_inputs();
    #1;
    PwrOk = 1'b0; TRSTN1 = 1'b0;
    tick(4);
    PwrOk = 1'b1; TRSTN1 = 1'b1;
    tick(2);
  endtask

  // ------------------------------------------------------- the TAP driver
  // As the delivered bench: one TMS1 bit per TCK1 cycle, returning in the low
  // phase with the outputs settled.
  task automatic tms(input logic v);
    TMS1 = v;
    tick(1);
  endtask

  task automatic goto_tlr();
    for (int unsigned i = 0; i < 5; i++) tms(1'b1);
  endtask

  task automatic goto_rti();
    goto_tlr();
    tms(1'b0);
  endtask

  task automatic shift_ir_raw(input logic [CHAIN_IR_LEN-1:0] code, input int unsigned len);
    tms(1'b1);                 // Select-DR
    tms(1'b1);                 // Select-IR
    tms(1'b0);                 // Capture-IR
    tms(1'b0);                 // Shift-IR
    for (int unsigned i = 0; i < len; i++) begin
      TDI1 = code[i];
      tms(i == (len - 1) ? 1'b1 : 1'b0);
    end
    tms(1'b1);                 // Update-IR
    tms(1'b0);                 // Run-Test/Idle
  endtask

  task automatic shift_dr_raw(input logic [32:0] tdi_bits, input int unsigned len,
                              output logic [32:0] tdo_bits);
    tdo_bits = '0;
    tms(1'b1);                 // Select-DR
    tms(1'b0);                 // Capture-DR
    tms(1'b0);                 // Shift-DR
    for (int unsigned i = 0; i < len; i++) begin
      TDI1 = tdi_bits[i];
      tdo_bits[i] = TDO1;
      tms(i == (len - 1) ? 1'b1 : 1'b0);
    end
    tms(1'b1);                 // Update-DR
    tms(1'b0);                 // Run-Test/Idle
  endtask

  // The two-device chain at TSEL1 = 3 (the SMS stub, held in BYPASS, then
  // dft_tap). The main TAP's bits go in first.
  task automatic chain_ir(input logic [4:0] tap_code);
    logic [CHAIN_IR_LEN-1:0] v;
    goto_rti();
    v = {{SMS_IR_LEN{1'b1}}, tap_code};
    shift_ir_raw(v, CHAIN_IR_LEN);
  endtask

  task automatic chain_dr(input logic [32:0] tap_bits, input int unsigned tap_len,
                          output logic [32:0] tap_out);
    shift_dr_raw(tap_bits, tap_len + 1, tap_out);
  endtask

  // One pass over a 32-bit DTR: `wr` becomes the shadow at Update-DR (only
  // while DFTTM is low), and `rd` is what the register captured on the way
  // in, the shadow as it was before. DFTTM is driven low here and left low:
  // ACT-DTR-UPD is gated by DFTTM, and in test the SOC_DFT TAP's TMS is
  // parked high (ACT-JTAG-PARK).
  task automatic dtr_xfer(input logic [4:0] code, input logic [31:0] wr,
                          output logic [31:0] rd);
    logic [32:0] seen;
    DFTTM = 1'b0;
    TSEL1 = 2'd3;
    tick(2);
    chain_ir(code);
    chain_dr({1'b0, wr}, 32, seen);
    rd = seen[31:0];
    chk_eq(64'(seen[32]), 64'(1'b0), "the SMS stub's BYPASS bit closes the chain");
    tick(2);
  endtask

  // C0a: write DTR_TM (IR_DTR_TM, ASSUMED code 5'b01001).
  task automatic tm_write(input logic [31:0] value);
    logic [31:0] seen;
    dtr_xfer(IRC_DTR_TM, value, seen);
    chk(!$isunknown(seen), "DTR_TM captured a known word");
  endtask

  // Read DTR_TM without changing it: shift the value back in.
  task automatic tm_read(input logic [31:0] expect_value, output logic [31:0] seen);
    dtr_xfer(IRC_DTR_TM, expect_value, seen);
  endtask

  // Enter test with the scan mode `m`: the select is set while DFTTM is low.
  task automatic enter_mode(input logic [2:0] m);
    DFTTM = 1'b0;
    DeMuxSel = m;
    settle_comb();
    DFTTM = 1'b1;
    tick(1);
  endtask

  // Every scan output at 0: what DFTTM low must leave (INV-05).
  task automatic chk_quiet(input string what);
    chk_eq(64'(DFTSO), 64'(0), {what, ": DFTSO"});
    chk_eq(64'(lpddr_test_si), 64'(0), {what, ": lpddr_test_si"});
    chk_eq(64'(top_test_si), 64'(0), {what, ": top_test_si"});
    for (int unsigned b = 0; b < NSCAN; b++) begin
      chk_eq(64'(blk_si(b)), 64'(0), $sformatf("%s: %s_test_si", what, blk_name(b)));
      chk_eq(64'(blk_wsi(b)), 64'(0), $sformatf("%s: %s_wrap_si", what, blk_name(b)));
    end
  endtask

  function automatic logic [19:0] wmask(input int unsigned w);
    wmask = (20'd1 << w) - 20'd1;
  endfunction

  // INTEST of mode m (0-6): drive `si` on DFTSI and, on each selected block,
  // the slice of `so` its lanes carry; every block the mode does not select
  // returns the complement, which must reach no lane. Then check both
  // directions lane by lane, from the package's lane table.
  task automatic chk_intest(input logic [2:0] m, input logic [19:0] si,
                            input logic [19:0] so, input string tname);
    logic [NBLK-1:0] msel;
    int unsigned     lo;
    int unsigned     w;
    logic [19:0]     exp_si;
    msel = scan_mode_sel(m);
    DFTSI = si;
    for (int unsigned b = 0; b < NSCAN; b++) begin
      if (msel[b]) set_blk_so(b, so >> lane_lo(m, b));
      else         set_blk_so(b, ~so);
      set_blk_wso(b, 1'b1);
    end
    top_test_so = 3'b111;
    lpddr_test_so = (m == SMODE_LPDDR) ? so : ~so;
    settle_comb();
    for (int unsigned b = 0; b < NSCAN; b++) begin
      w = nch(b);
      if (msel[b]) begin
        lo = lane_lo(m, b);
        exp_si = (si >> lo) & wmask(w);
        chk_eq(64'(blk_si(b)), 64'(exp_si),
               $sformatf("%s mode %0d %s_test_si lanes %0d..%0d", tname, m, blk_name(b), lo + w - 1, lo));
      end else begin
        chk_eq(64'(blk_si(b)), 64'(0),
               $sformatf("%s mode %0d %s_test_si quiet (0)", tname, m, blk_name(b)));
      end
      chk_eq(64'(blk_wsi(b)), 64'(0),
             $sformatf("%s mode %0d %s_wrap_si quiet (0)", tname, m, blk_name(b)));
    end
    chk_eq(64'(lpddr_test_si), (m == SMODE_LPDDR) ? 64'(si) : 64'(0),
           $sformatf("%s mode %0d lpddr_test_si", tname, m));
    chk_eq(64'(top_test_si), 64'(0), $sformatf("%s mode %0d top_test_si quiet (0)", tname, m));
    for (int unsigned k = 0; k < NPIN; k++)
      chk_eq(64'(DFTSO[k]), 64'(so[k]), $sformatf("%s mode %0d lane %0d DFTSO", tname, m, k));
  endtask

  // The patterns of T02-T08: walking 1, walking 0, then 32 words from the
  // pattern source, each on DFTSI and (a different word) on the returns.
  task automatic run_mode_patterns(input logic [2:0] m, input string tname);
    logic [19:0] p;
    enter_mode(m);
    for (int unsigned k = 0; k < NPIN; k++) begin
      p = 20'd1 << k;
      chk_intest(m, p, ~p, tname);
      chk_intest(m, ~p, p, tname);
    end
    for (int unsigned k = 0; k < 32; k++) begin
      next_rng();
      p = rng[19:0];
      next_rng();
      chk_intest(m, p, rng[19:0], tname);
    end
    tick(1);
  endtask

  // FIX 5: the package table against the lane slices written as numbers
  // (lit_in / lit_lo / lit_w): the same blocks, the same lowest lane, the
  // same width, for every scanned block of mode m.
  task automatic chk_lane_literals(input int unsigned m, input string tname);
    logic [NBLK-1:0] msel;
    msel = scan_mode_sel(m[2:0]);
    for (int unsigned b = 0; b < NSCAN; b++) begin
      chk_eq(64'(msel[b]), 64'(lit_in(m, b)),
             $sformatf("%s mode %0d %s in the mode: table equals the written slices", tname, m, blk_name(b)));
      if (lit_in(m, b)) begin
        chk_eq(64'(lane_lo(m[2:0], b)), 64'(lit_lo(m, b)),
               $sformatf("%s mode %0d %s lowest lane: table equals the written slices", tname, m, blk_name(b)));
        chk_eq(64'(nch(b)), 64'(lit_w(m, b)),
               $sformatf("%s mode %0d %s lane count: table equals the written slices", tname, m, blk_name(b)));
      end
    end
  endtask

  // FIX 5: INTEST of mode m driven and checked by the written slices only:
  // each block the slices name gets its slice of `so` and must see its slice
  // of `si`; every other block returns the complement and must see 0.
  task automatic chk_intest_literal(input int unsigned m, input logic [19:0] si,
                                    input logic [19:0] so, input string tname);
    int unsigned lo;
    int unsigned w;
    DFTSI = si;
    for (int unsigned b = 0; b < NSCAN; b++) begin
      if (lit_in(m, b)) set_blk_so(b, so >> lit_lo(m, b));
      else              set_blk_so(b, ~so);
      set_blk_wso(b, 1'b1);
    end
    top_test_so = 3'b111;
    lpddr_test_so = ~so;
    settle_comb();
    for (int unsigned b = 0; b < NSCAN; b++) begin
      if (lit_in(m, b)) begin
        lo = lit_lo(m, b);
        w = lit_w(m, b);
        chk_eq(64'(blk_si(b)), 64'((si >> lo) & wmask(w)),
               $sformatf("%s mode %0d %s_test_si written lanes %0d..%0d", tname, m, blk_name(b), lo + w - 1, lo));
        chk_eq(64'((DFTSO >> lo) & wmask(w)), 64'((so >> lo) & wmask(w)),
               $sformatf("%s mode %0d DFTSO written lanes %0d..%0d from %s_test_so", tname, m, lo + w - 1, lo, blk_name(b)));
      end else begin
        chk_eq(64'(blk_si(b)), 64'(0),
               $sformatf("%s mode %0d %s_test_si quiet (0), not in the written slices", tname, m, blk_name(b)));
      end
    end
  endtask

  // FIX 5: walking 1 and walking 0 on DFTSI, the complement on the returns,
  // checked by the written slices (the mode is already entered).
  task automatic run_literal_patterns(input int unsigned m, input string tname);
    logic [19:0] p;
    for (int unsigned k = 0; k < NPIN; k++) begin
      p = 20'd1 << k;
      chk_intest_literal(m, p, ~p, tname);
      chk_intest_literal(m, ~p, p, tname);
    end
  endtask

  // T03-T08: the table check, the table-driven patterns, then the patterns
  // checked by the written slices.
  task automatic run_mode_test(input int unsigned m, input string tname);
    cold_reset();
    chk_lane_literals(m, tname);
    run_mode_patterns(m[2:0], tname);
    run_literal_patterns(m, tname);
  endtask

  // EXTEST (mode 7): block b's wrapper chain on lane b, the three TOP chains
  // on lanes 11-13 (ASSUMED K8), lanes 14-19 at 0.
  task automatic chk_extest(input logic [19:0] si, input logic [10:0] wso,
                            input logic [2:0] tso, input string tname);
    DFTSI = si;
    for (int unsigned b = 0; b < NSCAN; b++) begin
      set_blk_wso(b, wso[b]);
      set_blk_so(b, 20'hFFFFF);
    end
    top_test_so = tso;
    lpddr_test_so = 20'hFFFFF;
    settle_comb();
    for (int unsigned b = 0; b < NSCAN; b++) begin
      chk_eq(64'(blk_wsi(b)), 64'(si[b]),
             $sformatf("%s mode 7 %s_wrap_si from lane %0d", tname, blk_name(b), b));
      chk_eq(64'(DFTSO[b]), 64'(wso[b]),
             $sformatf("%s mode 7 lane %0d DFTSO from %s_wrap_so", tname, b, blk_name(b)));
      chk_eq(64'(blk_si(b)), 64'(0), $sformatf("%s mode 7 %s_test_si quiet (0)", tname, blk_name(b)));
    end
    chk_eq(64'(top_test_si), 64'(si[13:11]), $sformatf("%s mode 7 top_test_si from lanes 13..11", tname));
    chk_eq(64'(DFTSO[13:11]), 64'(tso), $sformatf("%s mode 7 lanes 13..11 DFTSO from top_test_so", tname));
    chk_eq(64'(DFTSO[19:14]), 64'(0), $sformatf("%s mode 7 lanes 19..14 DFTSO unmapped (0)", tname));
    chk_eq(64'(lpddr_test_si), 64'(0), $sformatf("%s mode 7 lpddr_test_si quiet (0)", tname));
    chk_eq(64'(top_scan_shift_en), 64'(DFTSE), $sformatf("%s mode 7 top_scan_shift_en = DFTSE", tname));
  endtask

  // ---------------------------------------------------------------------
  // T01 t_reset_defaults
  task automatic t_reset_defaults();
    logic [31:0] seen;
    cold_reset();
    for (int unsigned b = 0; b < NSCAN; b++)
      chk_eq(64'(blk_tm(b)), 64'(0), $sformatf("T01 %s_test_mode after reset, DFTTM low", blk_name(b)));
    chk_quiet("T01 scan routing idle after reset (DFTTM low)");
    chk_eq(64'(DFTSO_OE), 64'(0), "T01 DFTSO_OE low out of test (P_DFTSO_HIZ_M0 = 1)");
    // No JTAG access yet: DTR_TM holds its reset value, so in test every
    // test_mode still reads 00.
    DFTTM = 1'b1;
    tick(1);
    for (int unsigned b = 0; b < NSCAN; b++)
      chk_eq(64'(blk_tm(b)), 64'(0), $sformatf("T01 %s_test_mode after reset, DFTTM high", blk_name(b)));
    DFTTM = 1'b0;
    tick(1);
    tm_read(32'h0, seen);
    chk_eq(64'(seen), 64'(0), "T01 DTR_TM reset value");
    // The DDR outputs against the delivered design's reset values: the
    // half-cycle compare (T16) has run through the reset above.
    chk_eq(64'(ddr_mismatches), 64'(0), "T01 every DDR output equals the delivered RTL through reset");
  endtask

  // T02-T08: the seven INTEST modes, by the lane table; T03-T08 also by the
  // lane slices written as numbers (FIX 5).
  task automatic t_mode0_lpddr();            cold_reset(); run_mode_patterns(3'd0, "T02"); endtask
  task automatic t_mode1_pcia_axis();        run_mode_test(1, "T03"); endtask
  task automatic t_mode2_pcib_axis();        run_mode_test(2, "T04"); endtask
  task automatic t_mode3_g2muc_axim_axis();  run_mode_test(3, "T05"); endtask
  task automatic t_mode4_l4ga_ahb_axis();    run_mode_test(4, "T06"); endtask
  task automatic t_mode5_l4gb_apb_axis();    run_mode_test(5, "T07"); endtask
  task automatic t_mode6_scc_hic_axis();     run_mode_test(6, "T08"); endtask

  // T09 t_axis_6to1_mux: modes 1-6 in turn, a distinct pattern per mode.
  // Axis's place in the table is first held to the written slice (lanes
  // 7:0 in every mode 1-6, FIX 5).
  task automatic t_axis_6to1_mux();
    logic [7:0] pat;
    logic [7:0] npat;   // the complement held at 8 bits: a cast widens before ~
    logic [NBLK-1:0] msel;
    cold_reset();
    for (int unsigned m = 1; m <= 6; m++) begin
      msel = scan_mode_sel(m[2:0]);
      chk_eq(64'(msel[9]), 64'(lit_in(m, 9)), $sformatf("T09 mode %0d axis in the mode: table equals the written slice", m));
      chk_eq(64'(lane_lo(m[2:0], 9)), 64'(lit_lo(m, 9)), $sformatf("T09 mode %0d axis lowest lane: table equals the written slice", m));
      chk_eq(64'(nch(9)), 64'(lit_w(m, 9)), $sformatf("T09 mode %0d axis lane count: table equals the written slice", m));
      enter_mode(m[2:0]);
      pat = 8'(8'h11 * m);
      npat = ~pat;
      DFTSI = {12'hABC, npat};
      axis_test_so = pat;
      settle_comb();
      chk_eq(64'(axis_test_si), 64'(npat), $sformatf("T09 mode %0d axis_test_si from lanes 7..0", m));
      chk_eq(64'(DFTSO[7:0]), 64'(pat), $sformatf("T09 mode %0d lanes 7..0 DFTSO from axis_test_so", m));
    end
    // In modes 0 and 7, axis_test_so reaches no lane.
    enter_mode(3'd0);
    lpddr_test_so = 20'h5A5A5;
    axis_test_so = 8'hFF;
    settle_comb();
    chk_eq(64'(DFTSO), 64'(20'h5A5A5), "T09 mode 0 DFTSO carries lpddr only, not axis");
    chk_eq(64'(axis_test_si), 64'(0), "T09 mode 0 axis_test_si quiet (0)");
    enter_mode(3'd7);
    for (int unsigned b = 0; b < NSCAN; b++) set_blk_wso(b, 1'b0);
    top_test_so = 3'b000;
    axis_test_so = 8'hFF;
    settle_comb();
    chk_eq(64'(DFTSO), 64'(0), "T09 mode 7 axis_test_so reaches no lane");
    chk_eq(64'(axis_test_si), 64'(0), "T09 mode 7 axis_test_si quiet (0)");
  endtask

  // T10 t_mode7_extest
  task automatic t_mode7_extest();
    cold_reset();
    enter_mode(3'd7);
    for (int unsigned k = 0; k < NPIN; k++) begin
      chk_extest(20'd1 << k, 11'(1 << (k % NSCAN)), 3'(k % 8), "T10");
      chk_extest(~(20'd1 << k), ~11'(1 << (k % NSCAN)), ~3'(k % 8), "T10");
    end
    for (int unsigned k = 0; k < 16; k++) begin
      next_rng();
      DFTSE = rng[31];
      chk_extest(rng[19:0], rng[30:20], rng[2:0] ^ rng[5:3], "T10");
    end
  endtask

  // T11 t_mode_switch: DeMuxSel 0 -> 7 -> 0 with DFTTM low between steps and
  // data running on DFTSI.
  task automatic t_mode_switch();
    int unsigned seq [15];
    seq[0]  = 0; seq[1]  = 1; seq[2]  = 2; seq[3]  = 3; seq[4]  = 4;
    seq[5]  = 5; seq[6]  = 6; seq[7]  = 7; seq[8]  = 6; seq[9]  = 5;
    seq[10] = 4; seq[11] = 3; seq[12] = 2; seq[13] = 1; seq[14] = 0;
    cold_reset();
    for (int unsigned s = 0; s < 15; s++) begin
      DFTTM = 1'b0;
      next_rng();
      DFTSI = rng[19:0];
      settle_comb();
      chk_quiet($sformatf("T11 step %0d DFTTM low before mode %0d", s, seq[s]));
      enter_mode(3'(seq[s]));
      next_rng();
      if (seq[s] == 7) chk_extest(rng[19:0], rng[30:20], rng[2:0], $sformatf("T11 step %0d", s));
      else begin
        logic [19:0] si;
        si = rng[19:0];
        next_rng();
        chk_intest(3'(seq[s]), si, rng[19:0], $sformatf("T11 step %0d", s));
      end
      tick(1);
    end
  endtask

  // T12 t_pad_loopback: DTR_TM bit 22 (ASSUMED K7).
  task automatic t_pad_loopback();
    logic [19:0] p;
    cold_reset();
    tm_write(32'h0040_0000);
    for (int unsigned m = 0; m < 8; m++) begin
      enter_mode(m[2:0]);
      for (int unsigned k = 0; k < 4; k++) begin
        next_rng();
        p = (k[0]) ? ~rng[19:0] : rng[19:0];
        DFTSI = p;
        for (int unsigned b = 0; b < NSCAN; b++) begin
          set_blk_so(b, ~p);
          set_blk_wso(b, 1'b1);
        end
        lpddr_test_so = ~p;
        top_test_so = 3'b111;
        settle_comb();
        for (int unsigned j = 0; j < NPIN; j++)
          chk_eq(64'(DFTSO[j]), 64'(p[j]), $sformatf("T12 loopback mode %0d lane %0d DFTSO = DFTSI", m, j));
        for (int unsigned b = 0; b < NSCAN; b++) begin
          chk_eq(64'(blk_si(b)), 64'(0), $sformatf("T12 loopback mode %0d %s_test_si quiet (0)", m, blk_name(b)));
          chk_eq(64'(blk_wsi(b)), 64'(0), $sformatf("T12 loopback mode %0d %s_wrap_si quiet (0)", m, blk_name(b)));
        end
        chk_eq(64'(lpddr_test_si), 64'(0), $sformatf("T12 loopback mode %0d lpddr_test_si quiet (0)", m));
      end
    end
    // Off again: normal routing comes back.
    tm_write(32'h0000_0000);
    enter_mode(3'd1);
    chk_intest(3'd1, 20'h12345, 20'hEDCBA, "T12 loopback off");
    enter_mode(3'd7);
    chk_extest(20'h0F0F0, 11'h5A5, 3'b101, "T12 loopback off");
  endtask

  // T13 t_test_mode_tdr: each block's two bits, walking 1 and walking 0 over
  // the 22 bits, read back.
  task automatic chk_tm_outputs(input logic [21:0] v, input string what);
    DFTTM = 1'b1;
    tick(1);
    for (int unsigned b = 0; b < NSCAN; b++)
      chk_eq(64'(blk_tm(b)), 64'(v[2*b +: 2]), $sformatf("%s: %s_test_mode", what, blk_name(b)));
    DFTTM = 1'b0;
    tick(1);
    for (int unsigned b = 0; b < NSCAN; b++)
      chk_eq(64'(blk_tm(b)), 64'(0), $sformatf("%s: %s_test_mode 00 while DFTTM low (ASSUMED N13)", what, blk_name(b)));
  endtask

  task automatic t_test_mode_tdr();
    logic [31:0] seen;
    logic [21:0] v;
    cold_reset();
    for (int unsigned b = 0; b < NSCAN; b++) begin
      for (int unsigned c = 0; c < 4; c++) begin
        v = 22'(c) << (2 * b);
        tm_write({10'd0, v});
        tm_read({10'd0, v}, seen);
        chk_eq(64'(seen), 64'({10'd0, v}), $sformatf("T13 read-back %s = %0d", blk_name(b), c));
        chk_tm_outputs(v, $sformatf("T13 %s = %0d", blk_name(b), c));
      end
    end
    for (int unsigned k = 0; k < 22; k++) begin
      v = 22'd1 << k;
      tm_write({10'd0, v});
      tm_read({10'd0, v}, seen);
      chk_eq(64'(seen), 64'({10'd0, v}), $sformatf("T13 walking 1 bit %0d read-back", k));
      chk_tm_outputs(v, $sformatf("T13 walking 1 bit %0d", k));
      v = ~(22'd1 << k);
      tm_write({10'd0, v});
      tm_read({10'd0, v}, seen);
      chk_eq(64'(seen), 64'({10'd0, v}), $sformatf("T13 walking 0 bit %0d read-back", k));
      chk_tm_outputs(v, $sformatf("T13 walking 0 bit %0d", k));
    end
    // Bits 31:23 are not held and capture as 0.
    tm_write(32'hFFFF_FFFF);
    tm_read(32'h0, seen);
    chk_eq(64'(seen), 64'(32'h007F_FFFF), "T13 bits 31:23 read 0");
    tm_write(32'h0);
  endtask

  // T14 t_dfttm_dftse_passthrough
  task automatic chk_pads(input string what);
    for (int unsigned b = 0; b < NSCAN; b++) begin
      chk_eq(64'(blk_pad(b)), 64'({DFTSE, DFTSE, DFTTM}),
             $sformatf("%s: %s {wrap_shift_en, scan_shift_en, dfttm}", what, blk_name(b)));
    end
  endtask

  task automatic t_dfttm_dftse_passthrough();
    cold_reset();
    for (int unsigned m = 0; m < 8; m++) begin
      next_rng();
      tm_write({9'd0, 1'b0, rng[21:0]});
      DeMuxSel = m[2:0];
      for (int unsigned c = 0; c < 4; c++) begin
        DFTTM = c[1];
        DFTSE = c[0];
        settle_comb();
        chk_pads($sformatf("T14 mode %0d DFTTM %0d DFTSE %0d", m, c[1], c[0]));
      end
    end
    // No dependence on reset: the same with PwrOk and TRSTN1 held low.
    PwrOk = 1'b0; TRSTN1 = 1'b0;
    for (int unsigned c = 0; c < 4; c++) begin
      DFTTM = c[1];
      DFTSE = c[0];
      settle_comb();
      chk_pads($sformatf("T14 in reset DFTTM %0d DFTSE %0d", c[1], c[0]));
    end
    PwrOk = 1'b1; TRSTN1 = 1'b1;
    DFTSE = 1'b0;
    tick(2);
  endtask

  // T15 t_dftmax_not_decoded
  task automatic t_dftmax_not_decoded();
    logic [127:0] state0;
    logic [19:0]  so_before;
    logic [2:0]   top_before;
    logic [19:0]  lp_before;
    logic [12:0]  comp_before;
    int unsigned  comp_moved;
    comp_moved = 0;
    cold_reset();
    tm_write(32'h0015_5A5A);
    for (int unsigned m = 0; m < 8; m++) begin
      enter_mode(m[2:0]);
      next_rng();
      DFTSI = rng[19:0];
      for (int unsigned b = 0; b < NSCAN; b++) begin
        set_blk_so(b, rng[31:12]);
        set_blk_wso(b, rng[b]);
      end
      lpddr_test_so = rng[29:10];
      top_test_so = rng[2:0];
      DFTMAX = DFTMAX_PLAIN;
      settle_comb();
      state0 = blk_state(); so_before = DFTSO; top_before = top_test_si; lp_before = lpddr_test_si;
      comp_before = dft_crg_comp_clk_en;
      chk_eq(64'(dftmax_out), 64'(DFTMAX_PLAIN), $sformatf("T15 mode %0d dftmax_out follows DFTMAX (low)", m));
      DFTMAX = DFTMAX_COMP;
      settle_comb();
      chk_eq(64'(blk_state() != state0), 64'(0), $sformatf("T15 mode %0d no block test_si, wrap_si or test_mode moved", m));
      chk_eq(64'(DFTSO), 64'(so_before), $sformatf("T15 mode %0d no DFTSO lane moved", m));
      chk_eq(64'(top_test_si), 64'(top_before), $sformatf("T15 mode %0d top_test_si did not move", m));
      chk_eq(64'(lpddr_test_si), 64'(lp_before), $sformatf("T15 mode %0d lpddr_test_si did not move", m));
      chk_pads($sformatf("T15 mode %0d", m));
      chk_eq(64'(dftmax_out), 64'(DFTMAX_COMP), $sformatf("T15 mode %0d dftmax_out follows DFTMAX (high)", m));
      if (dft_crg_comp_clk_en != comp_before) comp_moved = comp_moved + 1;
    end
    // OPEN N5: the compression clock enables of the delivered clock control
    // (kept byte-identical, K18) still follow DFTMAX. Reported, not checked.
    $display("NOTE T15 dft_crg_comp_clk_en moved with DFTMAX in %0d of 8 modes (OPEN N5, dft_crg_ctl unchanged)", comp_moved);
    DFTMAX = DFTMAX_PLAIN;
    tm_write(32'h0);
  endtask

  // T16 t_ddr_controls_unchanged: DDR stimulus, every DDR control compared
  // with the delivered design twice per cycle (here and through the whole run).
  task automatic t_ddr_controls_unchanged();
    logic [31:0] seen;
    logic [32:0] dseen;
    int unsigned compares0;
    cold_reset();
    compares0 = ddr_compares;
    // DTR_LPDDR values, DTR_CFG burn-in and the DDR TDR enable
    dtr_xfer(IRC_DTR_LPDDR, 32'h0003_FFFF, seen);
    dtr_xfer(IRC_DTR_LPDDR, 32'h0001_5555, seen);
    dtr_xfer(IRC_DTR_CFG,   CFG_RESET | 32'h0040_0010, seen);
    for (int unsigned k = 0; k < 6; k++) begin
      next_rng();
      dtr_xfer(IRC_DTR_LPDDR, rng & 32'h0003_FFFF, seen);
      lpddr_cmd_tdr_tdo = rng[1:0];
      lpddr_rd_tdr_tdo  = rng[3:2];
      // the four DDR TDR instructions, shifted through
      chain_ir(5'(5 + (k % 4)));
      chain_dr({1'b0, rng}, 32, dseen);
      chk(!$isunknown(dseen[31:0]), "T16 the DDR TDR shift returned a known word");
      for (int unsigned m = 0; m < 8; m++) begin
        DeMuxSel = m[2:0];
        DFTTM = 1'b1; DFTSE = rng[m]; DFTMAX = rng[m + 8];
        tick(2);
        DFTTM = 1'b0;
        tick(1);
      end
    end
    dtr_xfer(IRC_DTR_CFG, CFG_RESET, seen);
    dtr_xfer(IRC_DTR_LPDDR, 32'h0, seen);
    DFTSE = 1'b0; DFTMAX = DFTMAX_PLAIN;
    chk(ddr_compares > compares0, "T16 the DDR compare ran");
    chk_eq(64'(ddr_mismatches), 64'(0), "T16 every DDR control equals the delivered RTL at every half cycle (whole run so far)");
  endtask

  // T17 t_jtag_regression: TAP, JTAG1 router and TSEL1 against the delivered
  // design, cycle by cycle, plus the two IDCODEs by value.
  task automatic t_jtag_regression();
    logic [63:0] ids;
    logic [31:0] seen;
    cold_reset();
    jtag_compare_on = 1'b1;
    for (int unsigned t = 0; t < 4; t++) begin
      TSEL1 = t[1:0];
      for (int unsigned d = 0; d < 2; d++) begin
        DFTTM = d[0];
        for (int unsigned k = 0; k < 24; k++) begin
          next_rng();
          arc_tdo1 = rng[0]; arc_tdo1_oe = rng[1];
          pcia_tdo1 = rng[2]; pcia_tdo1_oe = rng[3];
          pcib_tdo1 = rng[4]; pcib_tdo1_oe = rng[5];
          TDI1 = rng[6];
          tms(rng[7]);
        end
      end
    end
    DFTTM = 1'b0;
    TSEL1 = 2'd3;
    goto_tlr();
    goto_rti();
    tms(1'b1); tms(1'b0); tms(1'b0);   // Select-DR, Capture-DR, Shift-DR
    for (int unsigned i = 0; i < 64; i++) begin
      TDI1 = 1'b0;
      ids[i] = TDO1;
      tms(i == 63 ? 1'b1 : 1'b0);
    end
    tms(1'b1); tms(1'b0);
    chk_eq(ids[31:0], 64'(P_IDCODE_EXPECTED), "T17 SOC_DFT TAP IDCODE");
    chk_eq(ids[63:32], 64'(P_SMS_IDCODE_EXPECTED), "T17 SMS stub IDCODE");
    // BYPASS on both devices, DTR_CFG write and read back, DTR_STS read
    chain_ir(5'b11111);
    begin
      logic [32:0] b;
      shift_dr_raw(33'h1_5555_5555, 33, b);
    end
    dtr_xfer(IRC_DTR_CFG, CFG_RESET ^ 32'h0000_0100, seen);
    dtr_xfer(IRC_DTR_CFG, CFG_RESET, seen);
    chk_eq(64'(seen), 64'(CFG_RESET ^ 32'h0000_0100), "T17 DTR_CFG read-back");
    dtr_xfer(IRC_DTR_STS, 32'h0, seen);
    jtag_compare_on = 1'b0;
    chk(jtag_compares > 0, "T17 the JTAG compare ran");
    chk_eq(64'(jtag_mismatches), 64'(0), "T17 TDO1, TDO1_OE and the three target TMS equal the delivered RTL at every half cycle");
  endtask

  // T19 t_sms_connectivity: limited to what the port sheet defines (the G2
  // reference files are not available, OPEN K15): every sheet SMS output
  // present and held at 0 (idle), and no WSO reaches any output.
  task automatic chk_sms_idle(input string what);
@@SMS_CHECK@@
  endtask

  task automatic t_sms_connectivity();
    cold_reset();
    for (int unsigned m = 0; m < 8; m++) begin
      for (int unsigned d = 0; d < 2; d++) begin
        DeMuxSel = m[2:0];
        DFTTM = d[0];
        next_rng();
@@SMS_DRIVE@@
        tick(1);
        chk_sms_idle($sformatf("T19 mode %0d DFTTM %0d", m, d));
      end
    end
  endtask

  // ------------------------------------------------- test wrapper
  task automatic begin_test(input string name);
    test_errors = 0;
    tests = tests + 1;
    test_checks0 = checks;
    test_cycles0 = cycles;
    $display("TEST START %s", name);
  endtask

  task automatic end_test(input string name);
    $display("PT %s checks=%0d cycles=%0d", name, checks - test_checks0, cycles - test_cycles0);
    if (test_errors == 0) begin
      tests_passed = tests_passed + 1;
      $display("TEST PASS %s", name);
    end
    else $display("TEST FAIL %s", name);
  endtask

  // ------------------------------------------------- the test selection
  string sdip_tests;

  function automatic bit selected(input string name);
    int unsigned i, start;
    if (sdip_tests.len() == 0) return 1'b1;
    start = 0;
    for (i = 0; i <= sdip_tests.len(); i++) begin
      if (i == sdip_tests.len() || sdip_tests[i] == ",") begin
        if (i > start && sdip_tests.substr(start, i - 1) == name)
          return 1'b1;
        start = i + 1;
      end
    end
    return 1'b0;
  endfunction

  // ---------------------------------------------------------------- main
  initial begin
    sdip_tests = "";
    void'($value$plusargs("SDIP_TESTS=%s", sdip_tests));
    if (sdip_tests.len() == 0)
      void'($value$plusargs("SDIP_TEST=%s", sdip_tests));
    errors = 0;
    checks = 0;
    tests = 0;
    tests_passed = 0;
    cycles = 0;
    ddr_compares = 0;
    ddr_mismatches = 0;
    jtag_compares = 0;
    jtag_mismatches = 0;
    jtag_compare_on = 1'b0;
    rng = 32'hACE1_2026;
    idle_inputs();
@@RUNS@@
    $display("TESTS %0d", tests);
    $display("TESTS_PASSED %0d", tests_passed);
    $display("CYCLES %0d", cycles);
    $display("CHECKS %0d", checks);
    $display("CHECK_FAILS %0d", errors);
    $display("DDR_COMPARES %0d", ddr_compares);
    $display("DDR_MISMATCHES %0d", ddr_mismatches);
    $display("JTAG_COMPARES %0d", jtag_compares);
    $display("JTAG_MISMATCHES %0d", jtag_mismatches);
@@SINK@@
    if (errors == 0) $display("RESULT PASS");
    else             $display("RESULT FAIL %0d", errors);
    $finish;
  end

endmodule
'''

ddr = []
for n, w in DDR_OUT:
    ddr.append(f"    if ({n} !== r_{n}) begin")
    ddr.append("      ddr_mismatches = ddr_mismatches + 1;")
    ddr.append(f"      if (ddr_mismatches <= 10) $display(\"DDR MISMATCH %s: {n} new %0h delivered %0h\", where, {n}, r_{n});")
    ddr.append("    end")
sms_idle = []
for p, wi, wo in SMS_KEPT:
    sms_idle.append(f"    {p}_sms_out = '0;")
for g in GUCC:
    sms_idle.append(f"    {g}_WSO = 1'b0;")
sms_chk = []
for p, wi, wo in SMS_KEPT:
    sms_chk.append(f"    chk_eq(64'({p}_sms_in), 64'(0), {{what, \": {p}_sms_in idle (0)\"}});")
for g in GUCC:
    for s in GUCC_OUT:
        sms_chk.append(f"    chk_eq(64'({g}_{s}), 64'(0), {{what, \": {g}_{s} idle (0)\"}});")
sms_drive = []
k = 0
for p, wi, wo in SMS_KEPT:
    sms_drive.append(f"        {p}_sms_out = rng[{k} +: {wo}];")
    k += wo
for g in GUCC:
    sms_drive.append(f"        {g}_WSO = rng[{k}];")
    k += 1
runs = []
for name, tid, cid in TESTS:
    runs.append(f"    if (selected(\"{name}\")) begin  // {tid} ({cid})")
    runs.append(f"      begin_test(\"{name}\");")
    runs.append(f"      {name}();")
    runs.append(f"      end_test(\"{name}\");")
    runs.append("    end")
sink_terms = ["DFTSO_OE"] + [f"{g}_{s}" for g in GUCC for s in GUCC_OUT] + \
    [n for n, w in CRG_OUT] + ["r_DFTSO", "r_DFTSO_OE"] + [f"r_{n}" for n, w in CRG_OUT]
sink = ["    // Every output not otherwise compared, read once (as the delivered bench).",
        "    $display(\"design outputs read: %0b\", ^{1'b0, " + ", ".join(sink_terms) + "});"]

body = (BODY.replace("@@DDR_COMPARE@@", "\n".join(ddr))
        .replace("@@SMS_IDLE@@", "\n".join(sms_idle))
        .replace("@@SMS_CHECK@@", "\n".join(sms_chk))
        .replace("@@SMS_DRIVE@@", "\n".join(sms_drive))
        .replace("@@RUNS@@", "\n".join(runs))
        .replace("@@SINK@@", "\n".join(sink)))
L.extend(body.split("\n"))
open(OUT, "w", encoding="utf-8", newline="\n").write("\n".join(L) + "\n")
print(f"wrote {OUT} ({len(L)} lines, {len(TESTS)} tests)")
