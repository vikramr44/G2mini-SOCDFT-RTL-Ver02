# Artifact identity: RTL
#
# soc_dft.sdc -- the one top-level SDC of SOC_DFT (D91: constraints are one
# top-level SDC under constraints/, and rtl/ holds RTL only).
#
# Scope: the block-level constraints of SOC_DFT. The chip top owns the pad
# constraints, the functional clocks and the inter-block budgets; nothing here
# describes anything outside u_soc_dft.
#
# The numbers come from the specification: TCK1 at 20 MHz maximum (50 ns), and
# 10 MHz (100 ns) while the instruction register holds a DDRx code, because the
# PHY's TDR path is slower (24.7, CONF-25).

set TCK1_PERIOD_NS      50.0
set TCK1_TDR_PERIOD_NS  100.0

# ---------------------------------------------------------------------------
# Clocks
# ---------------------------------------------------------------------------
# TCK1 is the only clock entering SOC_DFT. It is not buffered in RTL: the
# chip-top clock tree drives it.
create_clock -name TCK1 -period $TCK1_PERIOD_NS [get_ports TCK1]

# TDRCLK is TCK1 gated by the library ICG. It is a generated clock so that the
# gate is in the timing graph rather than a second independent clock.
create_generated_clock -name TDRCLK \
    -source [get_ports TCK1] \
    -divide_by 1 \
    -master_clock TCK1 \
    [get_pins u_ddr_tdr/u_dft_icg_tdrclk_dont_touch/gclk]

# The two edges of TCK1 are both used: shift stages launch on the rising edge
# and the update stages, the TDO retime and the TDR enable launch on the
# falling edge. That is one clock with both edges, not two clocks, so no
# exception is needed between them.

# ---------------------------------------------------------------------------
# Input and output delays at the SOC_DFT boundary
# ---------------------------------------------------------------------------
# TMS1 and TDI1 are driven by the tester through the pads and are sampled on
# the rising TCK1 edge; TDO1 is launched on the falling edge. The budgets are
# a quarter period each way, which is what the 1149.1 timing of 24.7 allows.
set_input_delay  -clock TCK1 [expr {$TCK1_PERIOD_NS / 4}] [get_ports {TMS1 TDI1}]
set_output_delay -clock TCK1 -clock_fall [expr {$TCK1_PERIOD_NS / 4}] \
    [get_ports {TDO1 TDO1_OE}]

# The scan channels are timed by the block's own test clock at the chip top,
# not by TCK1. Inside SOC_DFT the scan path is purely combinational (12.8: no
# retiming flop on any scan path), so these ports carry no clock of their own
# and the chip top budgets them.
set_max_delay [expr {$TCK1_PERIOD_NS / 2}] \
    -from [get_ports DFTSI] -to [get_ports DFTSO]

# ---------------------------------------------------------------------------
# Static test configuration
# ---------------------------------------------------------------------------
# These pins are static for a test session: they are changed only with the
# design idle, and no pattern times a path from them. Declaring them false
# rather than leaving them unconstrained says which fact makes them safe.
set_false_path -from [get_ports {DFTTM DFTMAX TSEL1}]

# DeMuxSel[2:0] selects the scan mode (change round of 12 Nov 2026), for the
# scan routing and, through the block selects, for the block clock enables.
# It is taken as static during a pattern: changed only between patterns, with
# the design idle, so no pattern times a path from it (ASSUMED K10; the rule
# on when it may change is OPEN K10).
set_false_path -from [get_ports {DeMuxSel}]

# DFTSE is dynamic within a session: it is the shift enable and it does time.
# It is deliberately NOT in the list above.

# ---------------------------------------------------------------------------
# Resets
# ---------------------------------------------------------------------------
# TRSTN1 is asynchronous in both directions, as 1149.1 specifies for a TAP
# reset. PwrOk and Rstn are asynchronous chip-level levels. Each reaches its
# destination domain through a library synchroniser cell, so the crossing is
# the cell's and the path into it is not timed.
set_false_path -from [get_ports {TRSTN1 PwrOk Rstn}]

# ---------------------------------------------------------------------------
# Clock-domain crossings
# ---------------------------------------------------------------------------
# CR-01: PwrOk into TCK1, through u_pad_if/u_dft_reset_sync_rst_dtr_dont_touch.
# CR-02: TRSTN1 into TDRCLK, through
#        u_ddr_tdr/u_dft_reset_sync_wrstn_dont_touch.
# CR-03: eight pad and generator levels into TCK1, through
#        u_dtr/u_dft_sync2_sts_dont_touch.
#
# The data path into the first flop of each synchroniser is the crossing and is
# not timed; the path between the two flops of a synchroniser IS timed, because
# that is what gives the cell its settling time.
set_false_path -to [get_pins u_pad_if/u_dft_reset_sync_rst_dtr_dont_touch/arst_n]
set_false_path -to [get_pins u_ddr_tdr/u_dft_reset_sync_wrstn_dont_touch/arst_n]
set_false_path -to [get_pins u_dtr/u_dft_sync2_sts_dont_touch/d*]

# TCK1 and TDRCLK are the same clock through a gate, so they are not
# asynchronous to each other and no inter-clock exception is written between
# them. There is no second clock inside SOC_DFT to group.

# ---------------------------------------------------------------------------
# The slower TDR mode
# ---------------------------------------------------------------------------
# While the IR holds a DDRx code the tester runs TCK1 at 10 MHz. That is a
# second STA mode, constrained by re-reading this file with TCK1_PERIOD_NS set
# to $TCK1_TDR_PERIOD_NS; it is not a second clock in this mode. The mode list
# and its scope are in 24.7.

# ---------------------------------------------------------------------------
# Technology cells
# ---------------------------------------------------------------------------
# Every instance below is a technology cell carried through synthesis, scan
# insertion and place-and-route. The name ends in _dont_touch so that the
# constraint and the netlist name the same object (D90, 24.11).
set_dont_touch [get_cells u_crg_ctl/u_dft_mux2_rst_dont_touch]
set_dont_touch [get_cells u_crg_ctl/u_dft_mux2_scan_rstn_dont_touch]
set_dont_touch [get_cells u_ddr_tdr/u_dft_icg_tdrclk_dont_touch]
set_dont_touch [get_cells u_pad_if/u_dft_reset_sync_rst_dtr_dont_touch]
set_dont_touch [get_cells u_ddr_tdr/u_dft_reset_sync_wrstn_dont_touch]
set_dont_touch [get_cells u_dtr/u_dft_sync2_sts_dont_touch]

# The hierarchy itself is kept: the constraints above, the equivalence check
# and the connectivity check all address instance paths (24.15).
set_dont_touch [get_cells u_soc_dft] -quiet
