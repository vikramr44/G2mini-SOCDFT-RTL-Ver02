# G2mini SOC_DFT, change of 12 Nov 2026: release notes

**REVIEW DRAFT - NOT GATED.** This release is for review only. It is not signed off. Formal proof, coverage closure and timing have not been run on it.

## What changed

- **Scan modes:** a new input `DeMuxSel[2:0]` selects one of eight scan modes. The scan router is a 1:7 demux on DFTSI and a 7:1 mux to DFTSO, with the AXIS 6:1 mux, as drawn.
- **test_mode:** each block's `test_mode` is 2 bits, read from a new 32-bit test register, DTR_TM (new instruction code 5'b01001). It is 00 while DFTTM is low.
- **Test controls:** `dfttm`, `scan_shift_en` and `wrap_shift_en` of every block come straight from the DFTTM and DFTSE pads. DFTMAX selects no mode.
- **Removed:** the test-point enables (`*_test_mode_tp`) and `ahb_wrap_shift_en`.
- **Scan widths:** the block scan widths follow the sheets, and each block has one wrapper chain.
- **Pad loopback:** DFTSO = DFTSI in any mode when DTR_TM bit 22 is set.
- **SMS:** g2muc gets the 14 SMS ports of the port sheet. They are held idle.
- **Unchanged:** the DDR controls, the clock and reset control, the TAP, and all other delivered behaviour.

## Port changes at soc_dft

| Change | Ports |
|---|---|
| removed | 11 `<blk>_test_mode_tp`, `ahb_wrap_shift_en`, `g2muc_sms_in[4:0]`, `g2muc_sms_out` |
| added | `DeMuxSel[2:0]` (in), `dftmax_out` (out), `lpddr_test_si[19:0]` (out), `lpddr_test_so[19:0]` (in), 14 `vl_sms_u_1_sms_sram_proc_TopGucc_1/_2_*` SMS ports |
| width | `<blk>_test_mode` 4 -> 2 bits; `<blk>_wrap_si/so` 2 -> 1 bit; `<blk>_test_si/so`: scc, hic 6; g2muc, l4ga, l4gb, axis 8; pcia, pcib 12; ahb 4 (apb, axim 4 unchanged) |

## Scan modes and lanes

| DeMuxSel | Blocks | DFTSI / DFTSO lanes |
|---|---|---|
| 0 | LPDDR | 19:0 (see K17) |
| 1 | pcia, axis | pcia 19:8, axis 7:0 (as drawn) |
| 2 | pcib, axis | pcib 19:8, axis 7:0 (assumed, K12) |
| 3 | g2muc, axim, axis | g2muc 19:12, axim 11:8, axis 7:0 (assumed, K12) |
| 4 | l4ga, ahb, axis | l4ga 19:12, ahb 11:8, axis 7:0 (assumed, K12) |
| 5 | l4gb, apb, axis | l4gb 19:12, apb 11:8, axis 7:0 (assumed, K12) |
| 6 | scc, hic, axis | scc 19:14, hic 13:8, axis 7:0 (as drawn) |
| 7 | EXTEST, all 11 blocks | wrapper chain of block b on lane b; top chains on 13:11; 19:14 drive 0 (assumed, K8) |

In every mode:
- An unscanned block sees scan-in 0.
- Unmapped lanes drive 0.
- Everything is 0 while DFTTM is low.
- The loopback takes priority over every mode.

## Tests

`run.sh` compiles `dv/eco.f`; the top is `tb_soc_dft_eco`. The bench runs the new design beside the delivered one (`dv/ref_delivered/`) and has 18 directed tests. It passes 18/18 on three SystemVerilog simulators, which agree: 33451 checks and 14182 cycles each. It compares the DDR and JTAG outputs with the delivered design: 28364 DDR compares and 1040 JTAG compares, with 0 mismatches. A run ends with `RESULT PASS`. The router's structure was proven equivalent to the earlier table-driven router by a SAT check. Planted faults in the RTL were all caught.

## Open questions

1. **K17 (first to answer):** mode 0 routes the 20 lanes to `lpddr_test_si/so`, but the DDR controls are unchanged. As a result, `lpddr_atpg_se` never asserts. `lpddr_atpg_mode` and `lpddr_compression_mode` move only through their DTR_LPDDR overrides, and `dft_crg_lpddr_clk_en` never asserts. **Mode 0 is not a working LPDDR scan mode yet.** Choose either to change the DDR scan enable for mode 0 or to keep the overrides only. The port names are open too.
2. **K10:** which pins carry DeMuxSel, and when it may change. The constraints take it as static during a pattern.
3. **K12, K13:** the lanes of modes 2-5 are assumed, with the same shape as modes 1 and 6.
4. **K9:** where `dftmax_out` goes. **K6:** what the four test_mode codes mean.
5. **K15, K16, S1:**
   - No reference SMS server: the new g2muc SMS outputs are held at 0.
   - The ahb SMS ports are not yet changed.
   - The sheet names do not tell pcia/pcib, l4ga/l4gb or scc/hic apart, so those blocks keep their delivered SMS ports.
6. **K7, K8:** the loopback bit and the EXTEST top-chain lanes are assumed. **K11:** the GPIO lane mapping is outside this RTL.

## DFTMAX and the clocks

- DFTMAX no longer selects a mode. `dftmax_out` passes it through.
- DFTMAX still gates the compression clock enables in the clock control, as delivered, and is still captured in DTR_STS. This is unchanged on purpose: no clock enable was changed, and none moves while DFTTM is low.
- In the constraints, DFTMAX, DFTTM, TSEL1 and now DeMuxSel are static false paths.
