#!/bin/sh
# REVIEW DRAFT - NOT GATED. Run from the release folder. Each run ends with RESULT PASS.
set -e
iverilog -g2012 -s tb_soc_dft_eco -o eco.vvp -f dv/eco.f && vvp -n eco.vvp
verilator --binary -j 0 --timing -sv -Wno-fatal -Wno-lint -Wno-style --top-module tb_soc_dft_eco -f dv/eco.f && ./obj_dir/Vtb_soc_dft_eco
