// Artifact identity: RTL
//
// dft_dtr -- the three DFT test registers DTR_CFG, DTR_LPDDR and DTR_STS, and
// the LPDDR SMS statics they drive. Each register is an instance of
// dft_dtr_reg; this module holds the instruction decode, the DTR_STS capture
// value, and the CR-03 synchronisers that bring eight pad and generator levels
// into TCK1.
//
// Actions implemented: ACT-DTR-SMSSTAT, ACT-DTR-RST, ACT-DTR-CLR.
// Crossing: CR-03, pads and CRG into TCK1 through dft_sync2.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   DFT test registers: REQ-10, REQ-11, REQ-12, REQ-13, REQ-23, REQ-35
// end REQUIREMENTS

module dft_dtr #(
    parameter logic [31:0] P_CFG_RST   = 32'h003F_FFA5,
    parameter logic [31:0] P_LPDDR_RST = 32'h0000_0000,
    parameter logic [7:0]  P_RTL_REV   = 8'h05
) (
    input  logic        tck1,
    input  logic        rst_dtr_n,
    input  logic        tdi,
    input  logic        tm,
    input  logic [4:0]  ir,
    input  logic        capture_dr,
    input  logic        shift_dr,
    input  logic        update_dr,
    // The eight levels DTR_STS captures (Table 52), as one bus:
    //   [0] DFTTM, [1] DFTMAX_COMP, [3:2] TSEL1, [4] PwrOk,
    //   [7:5] crg_pll_ready {DfiClk, Gclk, Uclk}
    // They arrive as a bus rather than being gathered here, because this is
    // the source side of CR-03 and a crossing must reach its synchroniser
    // without passing through logic of the destination module.
    input  logic [7:0]  sts_levels,
    // the configuration this design runs under
    output logic [31:0] dtr_cfg,
    output logic [31:0] dtr_lpddr,
    // the LPDDR SMS statics
    output logic [2:0]  lpddr_sms_dm,
    output logic [6:0]  lpddr_ring_bypass,
    output logic        lpddr_sfp_dft_mode,
    // serial returns into the TAP's DR multiplexer
    output logic        dr_tdo_cfg,
    output logic        dr_tdo_lpddr,
    output logic        dr_tdo_sts
);
  // ---------------------------------------------------------------------
  // Instruction decode for the three registers.
  // ---------------------------------------------------------------------
  logic sel_cfg;
  logic sel_lpddr;
  logic sel_sts;

  assign sel_cfg   = (ir == dft_part_map_pkg::IR_DTR_CFG);
  assign sel_lpddr = (ir == dft_part_map_pkg::IR_DTR_LPDDR);
  assign sel_sts   = (ir == dft_part_map_pkg::IR_DTR_STS);

  // ---------------------------------------------------------------------
  // CR-03. Each of the eight levels is sampled twice on TCK1 before it can
  // reach a capture value. They are independent levels, not a word, so a
  // per-bit synchroniser is the right cell and no bit of the group needs to
  // change in the same TCK1 cycle as another.
  // ---------------------------------------------------------------------
  logic [dft_part_map_pkg::N_STS_SYNC-1:0] sts_sync;

  // No reset on this synchroniser, which is what 18.4 asks for: "Every
  // DTR_STS input from a pad or the CRG ...: 2-flop synchroniser on TCK1,
  // no reset." The reset domains 18.4's RDC paragraph lists do not include
  // it, and the MKM's reset table says rst_dtr_n covers "the DTR_CFG and
  // DTR_LPDDR shadow stages only; nothing else in SOC_DFT".
  //
  // It was wired to rst_dtr_n. That is a reset neither record gives it, and
  // it is observable: while PwrOk is low and for two TCK1 edges after it is
  // released, a DTR_STS capture would have read zero for DFTTM, DFTMAX,
  // TSEL1 and crg_pll_ready instead of the levels those pins were actually
  // carrying -- a tester reading status at power-on would have been told
  // the chip was in a state it was not in. These are quasi-static levels
  // whose whole purpose is to be observable; a synchroniser that forces
  // them to zero defeats that. Tied high, the two stages track their input
  // from the second TCK1 edge, which is the behaviour 18.4 describes.
  dft_sync2 #(
      .W(dft_part_map_pkg::N_STS_SYNC)
  ) u_dft_sync2_sts_dont_touch (
      .clk  (tck1),
      .rst_n(1'b1),
      .d    (sts_levels),
      .q    (sts_sync)
  );

  // The DTR_STS capture value (Table 52). PART comes from the configuration
  // shadow, not from a synchroniser, because it is already in this domain;
  // dft_part_map_pkg::NPART and RTL_REV are build-time constants. Bits 31:25 and bit 24 read 0:
  // bit 24 is reserved because the SMS wrapper this design inherits has no
  // busy output, so no BIST interlock exists to capture.
  logic [31:0] sts_capture;

  // Built with continuous assignments rather than a process: a process that
  // bit-selects a vector is sensitive to every bit of it, which one of the
  // flow's front ends declines to model, and the capture value is a pure
  // concatenation anyway. The bit positions are Table 52's.
  // One assignment per field, each naming the field's position in the package
  // rather than relying on a concatenation's order, so that a change to the
  // recorded layout moves this logic with it.
  assign sts_capture[dft_part_map_pkg::STS_DFTTM]       = sts_sync[0];
  assign sts_capture[dft_part_map_pkg::STS_DFTMAX_COMP] = sts_sync[1];
  assign sts_capture[dft_part_map_pkg::STS_TSEL1_HI:
                     dft_part_map_pkg::STS_TSEL1_LO]    = sts_sync[3:2];
  assign sts_capture[dft_part_map_pkg::STS_PLL_RDY_HI:
                     dft_part_map_pkg::STS_PLL_RDY_LO]  = sts_sync[7:5];
  assign sts_capture[dft_part_map_pkg::STS_PWROK]       = sts_sync[4];
  assign sts_capture[dft_part_map_pkg::STS_PART_HI:
                     dft_part_map_pkg::STS_PART_LO]     =
      dtr_cfg[dft_part_map_pkg::CFG_PART_HI:dft_part_map_pkg::CFG_PART_LO];
  assign sts_capture[dft_part_map_pkg::STS_NPART_HI:
                     dft_part_map_pkg::STS_NPART_LO]    = dft_part_map_pkg::NPART[3:0];
  assign sts_capture[dft_part_map_pkg::STS_RTL_REV_HI:
                     dft_part_map_pkg::STS_RTL_REV_LO]  = P_RTL_REV;
  // Bit 24 is driven explicitly, and to 0: it is the bit a BIST interlock
  // would have occupied, and the SMS wrapper this design inherits has no busy
  // output, so there is nothing to capture and a reader must see a definite 0.
  assign sts_capture[dft_part_map_pkg::STS_SMS_BUSY_RSVD] = 1'b0;
  // Bits 31:25 are reserved and read 0.
  assign sts_capture[31:25] = 7'b000_0000;


  // ---------------------------------------------------------------------
  // CLR. The bit is read from the DTR_CFG shift stage at Update-DR, never
  // from the shadow, and it clears both configuration shadows. Because the
  // shadow masks bits 31:23 to 0, DTR_CFG.CLR always reads back 0 (INV-08).
  // ---------------------------------------------------------------------
  logic [31:0] cfg_sr_value;
  logic [31:0] lpddr_sr_unused;
  logic [31:0] sts_sr_unused;
  logic        clr_req;

  assign clr_req = sel_cfg & cfg_sr_value[dft_part_map_pkg::CFG_CLR];

  // ---------------------------------------------------------------------
  // DTR_CFG
  // ---------------------------------------------------------------------
  dft_dtr_reg #(
      .P_WIDTH     (32),
      .P_HAS_SHADOW(1'b1),
      .P_RESET     (P_CFG_RST),
      .P_MASK      (dft_part_map_pkg::CFG_SHADOW_MASK)
  ) u_cfg (
      .tck1         (tck1),
      .rst_dtr_n    (rst_dtr_n),
      .tdi          (tdi),
      .tm           (tm),
      .sel          (sel_cfg),
      .capture_dr   (capture_dr),
      .shift_dr     (shift_dr),
      .update_dr    (update_dr),
      .capture_value(32'h0000_0000),
      .clr_req      (clr_req),
      .shadow       (dtr_cfg),
      .sr_value     (cfg_sr_value),
      .dr_tdo       (dr_tdo_cfg)
  );

  // ---------------------------------------------------------------------
  // DTR_LPDDR
  // ---------------------------------------------------------------------
  dft_dtr_reg #(
      .P_WIDTH     (32),
      .P_HAS_SHADOW(1'b1),
      .P_RESET     (P_LPDDR_RST),
      .P_MASK      (dft_part_map_pkg::LP_SHADOW_MASK)
  ) u_lpddr (
      .tck1         (tck1),
      .rst_dtr_n    (rst_dtr_n),
      .tdi          (tdi),
      .tm           (tm),
      .sel          (sel_lpddr),
      .capture_dr   (capture_dr),
      .shift_dr     (shift_dr),
      .update_dr    (update_dr),
      .capture_value(32'h0000_0000),
      .clr_req      (clr_req),
      .shadow       (dtr_lpddr),
      .sr_value     (lpddr_sr_unused),
      .dr_tdo       (dr_tdo_lpddr)
  );

  // ---------------------------------------------------------------------
  // DTR_STS: capture only, no shadow, no update.
  // ---------------------------------------------------------------------
  logic [31:0] sts_shadow_unused;

  dft_dtr_reg #(
      .P_WIDTH     (32),
      .P_HAS_SHADOW(1'b0),
      .P_RESET     (32'h0000_0000),
      .P_MASK      (32'h0000_0000)
  ) u_sts (
      .tck1         (tck1),
      .rst_dtr_n    (rst_dtr_n),
      .tdi          (tdi),
      .tm           (tm),
      .sel          (sel_sts),
      .capture_dr   (capture_dr),
      .shift_dr     (shift_dr),
      .update_dr    (update_dr),
      .capture_value(sts_capture),
      .clr_req      (1'b0),
      .shadow       (sts_shadow_unused),
      .sr_value     (sts_sr_unused),
      .dr_tdo       (dr_tdo_sts)
  );

  // ---------------------------------------------------------------------
  // ACT-DTR-SMSSTAT: the LPDDR SMS statics follow the DTR_LPDDR shadow.
  // ---------------------------------------------------------------------
  assign lpddr_sms_dm       = dtr_lpddr[dft_part_map_pkg::LP_SMS_DM_HI:dft_part_map_pkg::LP_SMS_DM_LO];
  assign lpddr_ring_bypass  = dtr_lpddr[dft_part_map_pkg::LP_RING_BYPASS_HI:dft_part_map_pkg::LP_RING_BYPASS_LO];
  assign lpddr_sfp_dft_mode = dtr_lpddr[dft_part_map_pkg::LP_SFP_DFT_MODE];

endmodule

