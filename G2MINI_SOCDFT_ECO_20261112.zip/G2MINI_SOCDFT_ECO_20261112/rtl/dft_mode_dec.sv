// Artifact identity: RTL
//
// dft_mode_dec -- the combinational test-mode decoder: scan-mode select from
// DeMuxSel (C4, C6), the per-block two-bit test_mode from DTR_TM (C0a), and
// the LPDDR ATPG statics.
//
// It holds no state. The scan-mode outputs (sel, active, extest, loopback)
// and blk_test_mode are functions of DeMuxSel and the DTR_TM shadow only;
// DFTTM and DFTSE are not used for them here. The LPDDR statics are
// functions of DFTTM, DFTSE, DFTMAX, the DTR_CFG and DTR_LPDDR shadows and
// the LPDDR active bit. A configuration write takes effect as soon as the
// shadow moves and nothing has to be sequenced.
//
// Change round of 12 Nov 2026: the test-point enables are removed (C0), and
// DFTTM, DFTSE and DFTMAX no longer reach any block control from here (C1,
// C2); soc_dft takes DFTTM and DFTSE straight from the pads to the blocks.
// Change order item 1: DFTTM and DFTSE are not used inside this decoder
// except in the LPDDR statics section, which stays as it is because C0 (do
// not touch the DDR controls) wins there. soc_dft applies DFTTM to the
// decoded outputs.
//
// Actions implemented: ACT-MODE-FUNC, ACT-MODE-EXTEST, ACT-LPDDR-ATPG, ACT-LPDDR-SE, ACT-LPDDR-OVR,
// ACT-LPDDR-COMP, ACT-LPDDR-BURNIN, ACT-LPDDR-SCANCTL, ACT-PINONLY.
// Invariants: INV-05 (nothing moves while DFTTM is low; it holds because
// soc_dft gates these outputs with DFTTM, and the LPDDR statics here keep
// their own DFTTM terms), INV-06 and INV-10.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   functional-mode safe state: REQ-01, REQ-02, REQ-20, REQ-22, REQ-23, REQ-24
//   partition select and scan routing: REQ-14, REQ-16, REQ-17, REQ-37
//   per-block test mode and shift enable: REQ-14, REQ-15, REQ-18, REQ-31
//   LPDDR ATPG statics: REQ-23
// end REQUIREMENTS

module dft_mode_dec (
    input  logic        tm,
    input  logic        dftse_i,
    input  logic        dftmax_i,
    input  logic [31:0] dtr_cfg,
    input  logic [31:0] dtr_lpddr,
    // C4: the scan-mode select from the DeMuxSel pads; C0a: the DTR_TM shadow
    input  logic [2:0]  demux_sel,
    input  logic [31:0] dtr_tm,
    // the scan-mode state, published for the router and the clock control
    output logic [12:0] sel,
    output logic [12:0] active,
    output logic        extest,
    output logic        loopback,
    // The eleven two-bit test_mode codes (C0a), packed low block first. A
    // packed vector rather than an unpacked array because an unpacked array
    // port is not read by every front end the checks run.
    output logic [21:0] blk_test_mode,
    // LPDDR ATPG statics
    output logic        lpddr_atpg_mode,
    output logic        lpddr_compression_mode,
    output logic [15:0] lpddr_atpg_se,
    output logic        lpddr_scan_shift_cg,
    output logic        lpddr_phy0_burnin,
    output logic        lpddr_phy1_burnin,
    output logic [1:0]  lpddr_scan_ctl
);
  // ---------------------------------------------------------------------
  // The configuration fields this decoder reads.
  // ---------------------------------------------------------------------
  logic burnin;

  assign burnin  = dtr_cfg[dft_part_map_pkg::CFG_BURNIN];

  // ---------------------------------------------------------------------
  // Scan-mode decode (C4, C6). DeMuxSel picks one of the eight modes of the
  // change file part 4.1. A block is selected when the INTEST mode 1-6 names
  // it; it is active when it is selected or when mode 7 (EXTEST) exercises
  // its wrapper. Mode 0 routes LPDDR only: LPDDR's select and active bits
  // stay 0, as delivered, so its ATPG controls below and its clock enables
  // keep their delivered values (C0). The consequence, OPEN K17: in mode 0
  // the twenty lanes reach the LPDDR, but lpddr_atpg_se and the DFTSE term
  // of lpddr_scan_shift_cg never assert, lpddr_atpg_mode and
  // lpddr_compression_mode move only through the DTR_LPDDR overrides, and
  // dft_crg_lpddr_clk_en (no override, rtl/dft_crg_ctl.sv) never asserts; mode 0
  // is not a working LPDDR scan mode until the DFT team chooses between
  // changing the DDR scan enable for mode 0 and keeping the overrides only.
  // OPEN K10: DeMuxSel is used as it
  // stands; no rule on when it may change is known.
  // No DFTTM term here (change order item 1): soc_dft applies DFTTM to sel,
  // active, extest and loopback.
  // ---------------------------------------------------------------------
  assign extest   = (demux_sel == dft_part_map_pkg::SMODE_EXTEST);
  // C7: the pad loopback is one DTR_TM bit (ASSUMED K7).
  assign loopback = dtr_tm[dft_part_map_pkg::TM_LOOPBACK];

  always_comb begin
    sel = dft_part_map_pkg::scan_mode_sel(demux_sel);
    for (int unsigned b = 0; b < dft_part_map_pkg::NBLK; b++) begin
      active[b] = sel[b] | (extest & dft_part_map_pkg::P0_MEMBER[b]);
    end
  end

  // ---------------------------------------------------------------------
  // Per-block test_mode (C0a). Each block's two bits are its two DTR_TM bits,
  // passed through unchanged (OPEN K6: no sheet says what 00, 01, 10 and 11
  // mean). soc_dft holds them at 00 while DFTTM is low (INV-05, ASSUMED N13).
  // ---------------------------------------------------------------------
  assign blk_test_mode = dtr_tm[dft_part_map_pkg::TM_MODE_HI:dft_part_map_pkg::TM_MODE_LO];

  // DTR_TM bits 31:23 read 0 and carry nothing; one deliberate sink, as the
  // delivered shell uses for its contracted inputs (rtl/dft_sms_srv.sv).
  logic unused_dtr_tm_high;
  assign unused_dtr_tm_high = ^{1'b0, dtr_tm[31:dft_part_map_pkg::TM_LOOPBACK+1]};

  // ---------------------------------------------------------------------
  // LPDDR ATPG statics. The PHY is a hard IP: it holds block index 11 for
  // clock gating and takes no scan channel, so no INTEST partition names it
  // and its ATPG controls are reached through the DTR_LPDDR overrides rather
  // than through the partition. That is why the override path is not a
  // debug feature here but the only way these controls assert.
  //
  // This section keeps its DFTTM, DFTSE and DFTMAX terms exactly as before:
  // change order item 1 takes DFTTM and DFTSE out of this decoder, but C0
  // (do not touch the DDR controls) wins here. lpddr_active reads the
  // ungated active bit, which is 0 in every mode (no scan mode selects the
  // LPDDR and it is not an EXTEST member), and every use of it below is
  // already ANDed with DFTTM, so the values are unchanged.
  // ---------------------------------------------------------------------
  logic lpddr_active;
  logic atpg_mode_ovr;
  logic atpg_mode_val;
  logic comp_ovr;
  logic comp_val;

  assign lpddr_active  = active[dft_part_map_pkg::BLK_LPDDR];
  assign atpg_mode_ovr = dtr_lpddr[dft_part_map_pkg::LP_ATPG_MODE_OVR];
  assign atpg_mode_val = dtr_lpddr[dft_part_map_pkg::LP_ATPG_MODE_VAL];
  assign comp_ovr      = dtr_lpddr[dft_part_map_pkg::LP_COMP_OVR];
  assign comp_val      = dtr_lpddr[dft_part_map_pkg::LP_COMP_VAL];

  // ACT-LPDDR-OVR takes precedence over the mode-derived value
  // (ACT-LPDDR-ATPG), which is what "override" means.
  assign lpddr_atpg_mode = atpg_mode_ovr ? atpg_mode_val
                                         : (tm & lpddr_active);

  // ACT-LPDDR-COMP and its override.
  assign lpddr_compression_mode = comp_ovr ? comp_val
                                           : (tm & dftmax_i & lpddr_active);

  // ACT-LPDDR-SE: the sixteen atpg_se bits are driven alike.
  assign lpddr_atpg_se       = {16{tm & dftse_i & lpddr_active}};
  assign lpddr_scan_shift_cg = (tm & dftse_i & lpddr_active)
                             | dtr_lpddr[dft_part_map_pkg::LP_SCAN_SHIFT_CG_OVR];

  // ACT-LPDDR-BURNIN: the burn-in controls need DFTTM, DTR_CFG.BURNIN and the
  // per-PHY bit of DTR_LPDDR, so no single bit can put a PHY into burn-in.
  assign lpddr_phy0_burnin = tm & burnin & dtr_lpddr[dft_part_map_pkg::LP_PHY0_BURNIN];
  assign lpddr_phy1_burnin = tm & burnin & dtr_lpddr[dft_part_map_pkg::LP_PHY1_BURNIN];

  // ACT-LPDDR-SCANCTL: tied off because ASST is not used.
  assign lpddr_scan_ctl = 2'b00;

  // The LPDDR scan reset (ACT-CRG-LPRST) is driven by dft_crg_ctl, which owns
  // the reset path and holds the library mux cell that selects it.

endmodule
