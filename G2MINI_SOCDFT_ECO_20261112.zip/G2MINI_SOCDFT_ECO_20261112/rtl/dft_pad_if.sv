// Artifact identity: RTL
//
// dft_pad_if -- pad-side buffering, the one DFTSO output-enable net, and the
// PwrOk reset for the DTR shadow stages.
//
// Actions implemented: ACT-M0-PAD, ACT-PAD-OE, ACT-PAD-RSTDTR, ACT-PAD-RSTREL.
// Crossing: CR-01, PwrOk into TCK1 through dft_reset_sync.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   DTR reset release on TCK1: REQ-03, REQ-29
// end REQUIREMENTS

module dft_pad_if #(
    parameter bit P_DFTSO_HIZ_M0 = 1'b1,  // CONF-03
    parameter bit P_DFTMAX_COMP  = 1'b1   // CONF-39
) (
    // pads
    input  logic dfttm_pad,
    input  logic dftmax_pad,
    input  logic dftse_pad,
    input  logic pwrok_pad,
    input  logic tck1,
    // buffered mode levels
    output logic tm,
    output logic dftmax_i,
    output logic dftse_i,
    // DFTSO output enable, one net for all twenty pads
    output logic dftso_oe,
    // the DTR reset, released on TCK1
    output logic rst_dtr_n
);

  // The three buffered levels. These are re-drives, not decisions: every
  // consumer inside soc_dft takes its mode from here and never from the pad,
  // so that one buffer carries the whole test session (REQ-01).
  assign tm       = dfttm_pad;
  assign dftse_i  = dftse_pad;
  assign dftmax_i = (dftmax_pad == P_DFTMAX_COMP);

  // ACT-M0-PAD and ACT-PAD-OE. With P_DFTSO_HIZ_M0 = 1 the twenty DFTSO pads
  // are Hi-Z in functional mode and driven in test; with 0 they are always
  // driven and the data is 0 in functional mode (the scan router holds the
  // data side of that).
  assign dftso_oe = P_DFTSO_HIZ_M0 ? tm : 1'b1;

  // CR-01, ACT-PAD-RSTDTR and ACT-PAD-RSTREL: PwrOk asserts the DTR reset
  // asynchronously and releases it on the second rising TCK1 after PwrOk = 1.
  dft_reset_sync u_dft_reset_sync_rst_dtr_dont_touch (
      .clk   (tck1),
      .arst_n(pwrok_pad),
      .rst_n (rst_dtr_n)
  );

endmodule
