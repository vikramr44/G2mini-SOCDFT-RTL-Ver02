// Artifact identity: RTL
//
// dft_jtag1_rtr -- TSEL1 decode, per-target TMS gating, and the TDO1 and
// TDO1_OE multiplexing of the JTAG1 pin group. Combinational throughout: it
// holds no state, so a target change takes effect as soon as TSEL1 settles,
// and TSEL1 is static for a session (changed only with TRSTN1 low or with
// every TAP in Test-Logic-Reset).
//
// Actions implemented: ACT-JTAG-T0, ACT-JTAG-T1, ACT-JTAG-T2, ACT-JTAG-T3,
// ACT-JTAG-PARK, ACT-JTAG-OPEN.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   JTAG1 target routing: REQ-04, REQ-05, REQ-35
// end REQUIREMENTS

module dft_jtag1_rtr #(
    parameter bit P_OE_GATED = 1'b1,  // 1 gates each target's OE with its select
    parameter bit P_TM_OPEN  = 1'b1   // 1 opens the external TAPs' TMS in test
) (
    input  logic       tm,
    input  logic [1:0] tsel1,
    input  logic       tms1,
    // returns from the three external targets
    input  logic       arc_tdo1,
    input  logic       arc_tdo1_oe,
    input  logic       pcia_tdo1,
    input  logic       pcia_tdo1_oe,
    input  logic       pcib_tdo1,
    input  logic       pcib_tdo1_oe,
    // the SOC_DFT chain (device 2 of the TSEL1 = 11 chain)
    input  logic       sms_tdo1,
    input  logic       sms_tdo1_oe,
    // gated TMS to each target
    output logic       arc_tms1,
    output logic       pcia_tms1,
    output logic       pcib_tms1,
    output logic       sms_tms1,
    // the pad side
    output logic       tdo1,
    output logic       tdo1_oe
);

  // TSEL1 decode (8.4). One select per target, and they are mutually
  // exclusive by construction because they decode the same two bits.
  logic arc_sel;
  logic pcia_sel;
  logic pcib_sel;
  logic sms_sel;

  assign arc_sel  = ~tsel1[1] & ~tsel1[0];
  assign pcia_sel = ~tsel1[1] &  tsel1[0];
  assign pcib_sel =  tsel1[1] & ~tsel1[0];
  assign sms_sel  =  tsel1[1] &  tsel1[0];

  // The opening term: in test, with P_TM_OPEN = 1, the three external TAPs
  // follow TMS1 whether or not they are selected, so a tester can walk them
  // all to Test-Logic-Reset at once (ACT-JTAG-OPEN).
  logic tm_o;
  assign tm_o = tm & P_TM_OPEN;

  // Per-target TMS. A target that is neither selected nor opened sees TMS = 1,
  // which parks it in Test-Logic-Reset (ACT-JTAG-T0..T3).
  assign arc_tms1  = (arc_sel  | tm_o) ? tms1 : 1'b1;
  assign pcia_tms1 = (pcia_sel | tm_o) ? tms1 : 1'b1;
  assign pcib_tms1 = (pcib_sel | tm_o) ? tms1 : 1'b1;

  // ACT-JTAG-PARK: the SOC_DFT TAP is parked by hardware in test at either
  // value of P_TM_OPEN, because its own data registers must not move while a
  // scan session is using the DFT pins.
  assign sms_tms1 = tm ? 1'b1 : (sms_sel ? tms1 : 1'b1);

  // TDO1 and its enable. The data mux follows the select; the enable is
  // either gated per target (P_OE_GATED = 1) or the ungated OR of the four,
  // which is the r0.2 behaviour kept as a build option.
  always_comb begin
    case (tsel1)
      2'b00:   tdo1 = arc_tdo1;
      2'b01:   tdo1 = pcia_tdo1;
      2'b10:   tdo1 = pcib_tdo1;
      default: tdo1 = sms_tdo1;
    endcase
  end

  always_comb begin
    if (P_OE_GATED) begin
      case (tsel1)
        2'b00:   tdo1_oe = arc_tdo1_oe;
        2'b01:   tdo1_oe = pcia_tdo1_oe;
        2'b10:   tdo1_oe = pcib_tdo1_oe;
        default: tdo1_oe = sms_tdo1_oe;
      endcase
    end else begin
      tdo1_oe = arc_tdo1_oe | pcia_tdo1_oe | pcib_tdo1_oe | sms_tdo1_oe;
    end
  end

endmodule
