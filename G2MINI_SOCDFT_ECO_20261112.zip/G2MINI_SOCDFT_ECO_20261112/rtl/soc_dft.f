// Artifact identity: RTL
//
// soc_dft filelist. Compile order: the package first, then the technology
// cells, then the leaf modules, then the top.

rtl/dft_part_map_pkg.sv

rtl/cells/dft_mux2.sv
rtl/cells/dft_icg.sv
rtl/cells/dft_reset_sync.sv
rtl/cells/dft_sync2.sv

rtl/dft_pad_if.sv
rtl/dft_jtag1_rtr.sv
rtl/dft_tap.sv
rtl/dft_dtr_reg.sv
rtl/dft_dtr.sv
rtl/dft_dtr_tm.sv
rtl/dft_mode_dec.sv
rtl/dft_scan_rtr.sv
rtl/dft_crg_ctl.sv
rtl/dft_sms_srv.sv
rtl/dft_sms_ports.sv
rtl/dft_ddr_tdr.sv

rtl/soc_dft.sv
