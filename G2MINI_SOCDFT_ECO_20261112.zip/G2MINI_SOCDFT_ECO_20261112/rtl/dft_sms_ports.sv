// Artifact identity: RTL
//
// dft_sms_ports -- the SMS wrapper ports of the port sheet (change C8,
// sheet "DFT Port list Block" and "SOC DFT To Block Port Connect"), between
// the delivered SMS shell (dft_sms_srv) and the block pins.
//
// What is done here, and only this: the sheet names and directions for the
// wrappers the sheet gives to one block alone. Those are TopGucc_1 and
// TopGucc_2 of g2muc (block sheet rows 64-77, connect sheet rows 78-91).
// Every output is held at 0, the same idle state the delivered stub drives
// (ACT-SMS-IDLE) and the sheet's own tie-off example for TopGucc_2 shows; each
// WSO goes to one deliberate sink.
//
// What is not done, by name:
//   OPEN K15: the G2 reference SMS server is not in this copy, so nothing here
//     drives a wrapper; the shell's packed g2muc_sms_in is sunk, and the shell
//     is given a tie-off 0 for g2muc_sms_out (which WSO returns to the server
//     is in the reference).
//   OPEN S1: the sheet's names TopG2mPci_1/_2, TopG2mL4g_1 and TopG2mArc_1 do
//     not tell pcia from pcib, l4ga from l4gb or scc from hic, so those six
//     blocks keep their delivered <blk>_sms_in / <blk>_sms_out ports.
//   OPEN K16: ahb keeps its delivered ahb_sms_in[4:0] / ahb_sms_out; the
//     connect sheet names ahb_sms_in[4:0] / ahb_sms_out[4:0] beside single-bit
//     WSI / WSO.

module dft_sms_ports (
    // from the delivered shell
    input  logic [4:0] g2muc_sms_in,
    output logic       g2muc_sms_out,
    // TopGucc_1 (block sheet rows 64-70)
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair,
    // TopGucc_2 (block sheet rows 71-77)
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair
);

  // Idle: every WSP control, WSI and repair control at 0 (OPEN K15).
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI                = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR           = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR          = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR            = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR          = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI                = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR           = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR          = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR            = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR          = 1'b0;
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair = 1'b0;

  // OPEN K15: which WSO returns to the server is in the G2 reference; the
  // delivered shell reads nothing from this port.
  assign g2muc_sms_out = 1'b0;

  // The inputs nothing reads until the reference server arrives, taken to one
  // deliberate sink, as the delivered shell does for its own (rtl/dft_sms_srv.sv).
  logic unused_sms_ports_inputs;
  assign unused_sms_ports_inputs = ^{1'b0, g2muc_sms_in,
                                     vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO,
                                     vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO};

endmodule
