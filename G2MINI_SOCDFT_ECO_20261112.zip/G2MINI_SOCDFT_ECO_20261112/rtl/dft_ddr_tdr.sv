// Artifact identity: RTL
//
// dft_ddr_tdr -- the LPDDR phy0 and phy1 TDR bridge: the TDRCLK gate, WRSTN,
// the twelve capture/shift/update enables and the WSI path.
//
// The twelve enables are registered, not combinational decodes of the TAP
// state, because the PHY samples them on TDRCLK and a decode would change
// while TDRCLK is high. The launch edge is P_TDR_EN_EDGE (CONF-25).
//
// Actions implemented: ACT-TDR-CLK, ACT-TDR-GATE, ACT-TDR-WRSTN,
// ACT-TDR-WRSTN-OFF, ACT-TDR-CAP0, ACT-TDR-CAP1, ACT-TDR-SHIFT0,
// ACT-TDR-SHIFT1, ACT-TDR-UPD0, ACT-TDR-UPD1.
// Crossing: CR-02, TRSTN1 into TDRCLK through dft_reset_sync.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   configuration write protection in test: REQ-10, REQ-11, REQ-24, REQ-35
//   LPDDR TDR bridge: REQ-24, REQ-35
// end REQUIREMENTS

module dft_ddr_tdr #(
    parameter bit P_TDR_EN_EDGE = 1'b1  // 1 = launch on falling TCK1
) (
    input  logic       tck1,
    input  logic       trstn1,
    input  logic       tdi,
    input  logic       tm,
    input  logic [3:0] tap_state,
    input  logic [4:0] ir,
    input  logic       ddr_tdr_en,
    // returns from the PHYs, into the TAP's DR multiplexer
    input  logic [1:0] lpddr_cmd_tdr_tdo,
    input  logic [1:0] lpddr_rd_tdr_tdo,
    output logic       dr_tdo_ddr,
    // the TDR interface
    output logic       lpddr_tdrclk,
    output logic       lpddr_wrstn,
    output logic [1:0] lpddr_cmd_tdr_capture_en,
    output logic [1:0] lpddr_cmd_tdr_shift_en,
    output logic [1:0] lpddr_cmd_tdr_update_en,
    output logic [1:0] lpddr_rd_tdr_capture_en,
    output logic [1:0] lpddr_rd_tdr_shift_en,
    output logic [1:0] lpddr_rd_tdr_update_en,
    output logic [1:0] lpddr_wsi
);
  // ---------------------------------------------------------------------
  // Which TDR the loaded instruction addresses. There are four codes, one per
  // PHY per register (Table 46), and exactly one register is in the TDI-to-TDO
  // path at a time: the command and read-data TDRs of a PHY are separate
  // instructions, not one.
  // ---------------------------------------------------------------------
  logic ddr0_cmd_sel;
  logic ddr0_rd_sel;
  logic ddr1_cmd_sel;
  logic ddr1_rd_sel;

  assign ddr0_cmd_sel = (ir == dft_part_map_pkg::IR_DDR0_CMD);
  assign ddr0_rd_sel  = (ir == dft_part_map_pkg::IR_DDR0_RD);
  assign ddr1_cmd_sel = (ir == dft_part_map_pkg::IR_DDR1_CMD);
  assign ddr1_rd_sel  = (ir == dft_part_map_pkg::IR_DDR1_RD);

  // ---------------------------------------------------------------------
  // The twelve enables. Every one is gated with ~tm (ACT-TDR-GATE): a scan
  // session forces a TMS = 1 walk that passes through Capture-DR, Shift-DR and
  // Update-DR, and without that term the walk would pulse the PHY's TDR
  // enables in the middle of a scan pattern (8.1, 15.4).
  // ---------------------------------------------------------------------
  logic [11:0] tdr_en_d;
  logic [11:0] tdr_en_q;

  logic in_capture;
  logic in_shift;
  logic in_update;

  assign in_capture = (tap_state == dft_part_map_pkg::CAPTURE_DR);
  assign in_shift   = (tap_state == dft_part_map_pkg::SHIFT_DR);
  assign in_update  = (tap_state == dft_part_map_pkg::UPDATE_DR);

  always_comb begin
    tdr_en_d = '0;
    if (!tm && ddr_tdr_en) begin
      // bits 1:0 command capture, 3:2 command shift, 5:4 command update,
      // 7:6 read capture, 9:8 read shift, 11:10 read update; within each
      // pair bit 0 is phy0 and bit 1 is phy1.
      tdr_en_d[0]  = in_capture & ddr0_cmd_sel;
      tdr_en_d[1]  = in_capture & ddr1_cmd_sel;
      tdr_en_d[2]  = in_shift   & ddr0_cmd_sel;
      tdr_en_d[3]  = in_shift   & ddr1_cmd_sel;
      tdr_en_d[4]  = in_update  & ddr0_cmd_sel;
      tdr_en_d[5]  = in_update  & ddr1_cmd_sel;
      tdr_en_d[6]  = in_capture & ddr0_rd_sel;
      tdr_en_d[7]  = in_capture & ddr1_rd_sel;
      tdr_en_d[8]  = in_shift   & ddr0_rd_sel;
      tdr_en_d[9]  = in_shift   & ddr1_rd_sel;
      tdr_en_d[10] = in_update  & ddr0_rd_sel;
      tdr_en_d[11] = in_update  & ddr1_rd_sel;
    end
  end

  // The launch edge is a build-time choice, so both edges are written and one
  // is elaborated. Writing it as a clock expression instead would put a
  // parameter on a clock, which no lint flow accepts.
  if (P_TDR_EN_EDGE) begin : g_fall
    always_ff @(negedge tck1 or negedge trstn1) begin
      if (!trstn1) tdr_en_q <= '0;
      else         tdr_en_q <= tdr_en_d;
    end
  end else begin : g_rise
    always_ff @(posedge tck1 or negedge trstn1) begin
      if (!trstn1) tdr_en_q <= '0;
      else         tdr_en_q <= tdr_en_d;
    end
  end

  assign lpddr_cmd_tdr_capture_en = tdr_en_q[1:0];
  assign lpddr_cmd_tdr_shift_en   = tdr_en_q[3:2];
  assign lpddr_cmd_tdr_update_en  = tdr_en_q[5:4];
  assign lpddr_rd_tdr_capture_en  = tdr_en_q[7:6];
  assign lpddr_rd_tdr_shift_en    = tdr_en_q[9:8];
  assign lpddr_rd_tdr_update_en   = tdr_en_q[11:10];

  // ---------------------------------------------------------------------
  // The WSI path: TDI reaches the addressed PHY while its code is loaded.
  // ---------------------------------------------------------------------
  assign lpddr_wsi[0] = (!tm && ddr_tdr_en && (ddr0_cmd_sel || ddr0_rd_sel))
                      ? tdi : 1'b0;
  assign lpddr_wsi[1] = (!tm && ddr_tdr_en && (ddr1_cmd_sel || ddr1_rd_sel))
                      ? tdi : 1'b0;

  // The return into the TAP's DR multiplexer: the one addressed TDR, or 0 when
  // no DDRx code is loaded. Written as a continuous assignment rather than a
  // process, because a process that bit-selects an input vector is sensitive
  // to every bit of it, which is both wasteful and a thing one of the flow's
  // front ends declines to model.
  assign dr_tdo_ddr = ddr0_cmd_sel ? lpddr_cmd_tdr_tdo[0]
                    : ddr1_cmd_sel ? lpddr_cmd_tdr_tdo[1]
                    : ddr0_rd_sel  ? lpddr_rd_tdr_tdo[0]
                    : ddr1_rd_sel  ? lpddr_rd_tdr_tdo[1]
                    : 1'b0;

  // ---------------------------------------------------------------------
  // ACT-TDR-CLK: TDRCLK is TCK1 gated by the DTR enable, through the library
  // ICG so the gated clock never shows a partial pulse.
  // ---------------------------------------------------------------------
  dft_icg u_dft_icg_tdrclk_dont_touch (
      .clk (tck1),
      .en  (ddr_tdr_en),
      .gclk(lpddr_tdrclk)
  );

  // ---------------------------------------------------------------------
  // CR-02, ACT-TDR-WRSTN and ACT-TDR-WRSTN-OFF: WRSTN asserts whenever the
  // TDR interface is disabled or TRSTN1 is low, and is released only over two
  // TDRCLK edges. TDRCLK stops when the interface is disabled, so the
  // synchroniser's asynchronous assert is what clears it.
  // ---------------------------------------------------------------------
  logic wrstn_src;
  assign wrstn_src = trstn1 & ddr_tdr_en;

  dft_reset_sync u_dft_reset_sync_wrstn_dont_touch (
      .clk   (lpddr_tdrclk),
      .arst_n(wrstn_src),
      .rst_n (lpddr_wrstn)
  );

endmodule
