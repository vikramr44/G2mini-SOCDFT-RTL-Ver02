// Artifact identity: RTL
//
// dft_part_map_pkg -- the partition map, the DeMuxSel scan-mode lane table
// and the DTR field layouts of soc_dft. Every module reads its counts from here; no count
// is written into module code (specification 12.4).
//
// Nothing here is a new decision. The names are the names of the source's own
// package (12.4); the values are transcriptions:
//   - NBLK, NCH, NPART, NTOP and TMW: 12.4, with NCH and TMW changed by the
//     change round of 12 Nov 2026 (C3/C11, C0a); the scan-mode lane table:
//     that change file, part 4.1.
//   - PART_MAP_SEL and the pin allocation: declarations/mkm.json#partition_map,
//     which ADM-T1-08 derived from Table 59 and the rule beneath it. Table 59
//     numbers its INTEST rows from 0 while the PART field numbers them from 1
//     (PART 0 is EXTEST), so Table 59 row m is PART m + 1 -- ADM-T1-05.
//   - PIN_BASE, SO_VALID, SO_BLK and SO_CH: computed here from PART_MAP_SEL and
//     NCH by the generator's own rule, so they cannot disagree with it. Since
//     the change round of 12 Nov 2026 nothing routes by them (C6); soc_dft
//     checks the lane table against its literals at elaboration instead.
//   - the DTR_CFG, DTR_LPDDR and DTR_STS field positions: 10.2, 10.3 and
//     Table 52.
//
// The source writes these arrays as unpacked int arrays and allows an
// implementation to hold the same values in another form where a tool lacks
// unpacked-array parameter support (12.4, "Representation"). This package
// holds them as functions over packed values: the values, the indices and the
// rule are identical.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   partition select and scan routing: REQ-14, REQ-16, REQ-17, REQ-37
// end REQUIREMENTS

package dft_part_map_pkg;

  // ---------------------------------------------------------------------
  // 12.4 counts
  // ---------------------------------------------------------------------
  localparam int unsigned NBLK  = 13;  // 11 scanned blocks, lpddr, top
  localparam int unsigned NPART = 6;   // the delivered PART count; DTR_STS still reports it (C6: PART no longer routes)
  localparam int unsigned NTOP  = 3;   // TOP chains, pins 11..13 in EXTEST
  localparam int unsigned TMW   = 2;   // <blk>_test_mode width, every block (C0a)
  localparam int unsigned NPIN  = 20;  // DFTSI/DFTSO pin pairs (CONF-28)

  // Block index positions. 11 is the LPDDR hard IP, which holds its index for
  // clock gating and takes no channel of the block bus (DeMuxSel mode 0
  // routes it on its own twenty lanes, ASSUMED K17); 12 is the TOP glue
  // position.
  localparam int unsigned BLK_SCC   = 0;
  localparam int unsigned BLK_HIC   = 1;
  localparam int unsigned BLK_G2MUC = 2;
  localparam int unsigned BLK_L4GA  = 3;
  localparam int unsigned BLK_L4GB  = 4;
  localparam int unsigned BLK_PCIA  = 5;
  localparam int unsigned BLK_PCIB  = 6;
  localparam int unsigned BLK_AHB   = 7;
  localparam int unsigned BLK_APB   = 8;
  localparam int unsigned BLK_AXIS  = 9;
  localparam int unsigned BLK_AXIM  = 10;
  localparam int unsigned BLK_LPDDR = 11;
  localparam int unsigned BLK_TOP   = 12;

  // NCH by block index (C3/C11, change file part 4.2; K1 = 8, K2 = 4, K3 = 12):
  // '{6,6,8,8,8,12,12,4,4,8,4,0,3}
  function automatic int unsigned nch(input int unsigned b);
    case (b)
      BLK_SCC:   nch = 6;
      BLK_HIC:   nch = 6;
      BLK_G2MUC: nch = 8;
      BLK_L4GA:  nch = 8;
      BLK_L4GB:  nch = 8;
      BLK_PCIA:  nch = 12;
      BLK_PCIB:  nch = 12;
      BLK_AHB:   nch = 4;
      BLK_APB:   nch = 4;
      BLK_AXIS:  nch = 8;
      BLK_AXIM:  nch = 4;
      BLK_LPDDR: nch = 0;   // hard IP, not on the block bus (mode 0 lanes: ASSUMED K17)
      BLK_TOP:   nch = 3;
      default:   nch = 0;
    endcase
  endfunction

  // ---------------------------------------------------------------------
  // PART_MAP_SEL: bit b is 1 when block b belongs to INTEST partition p.
  // PART 0 is EXTEST and PART 15 is loopback; both are routed by their own
  // branch and select no block here. PART 5..14 are legal codes that select
  // nothing (ADM-T1-06 escalates that P_CFG_RST resets PART to 5).
  // ---------------------------------------------------------------------
  localparam logic [NBLK-1:0] PART_MAP_SEL_1 = (1 << BLK_PCIA);
  localparam logic [NBLK-1:0] PART_MAP_SEL_2 = (1 << BLK_PCIB);
  localparam logic [NBLK-1:0] PART_MAP_SEL_3 = (1 << BLK_SCC) | (1 << BLK_G2MUC)
                                             | (1 << BLK_AHB) | (1 << BLK_AXIS);
  localparam logic [NBLK-1:0] PART_MAP_SEL_4 = (1 << BLK_HIC) | (1 << BLK_L4GA)
                                             | (1 << BLK_L4GB) | (1 << BLK_APB)
                                             | (1 << BLK_AXIM);

  function automatic logic [NBLK-1:0] part_map_sel(input logic [3:0] part);
    case (part)
      4'd1:    part_map_sel = PART_MAP_SEL_1;
      4'd2:    part_map_sel = PART_MAP_SEL_2;
      4'd3:    part_map_sel = PART_MAP_SEL_3;
      4'd4:    part_map_sel = PART_MAP_SEL_4;
      default: part_map_sel = '0;
    endcase
  endfunction

  // The eleven blocks the EXTEST partition exercises through their wrappers.
  localparam logic [NBLK-1:0] P0_MEMBER = PART_MAP_SEL_1 | PART_MAP_SEL_2
                                        | PART_MAP_SEL_3 | PART_MAP_SEL_4;

  // ---------------------------------------------------------------------
  // The channel bus inside soc_dft. The eleven scanned blocks are indices 0
  // to 10; their channels sum to NCHAN, and block b owns NCH[b] of them from
  // CHAN_BASE[b]. This is the packing of the block-side buses between
  // dft_scan_rtr and the block ports: every bit of the bus is a channel the
  // design has, so there is no padding to leave undriven.
  // ---------------------------------------------------------------------
  localparam int unsigned NSCAN = 11;
  localparam int unsigned NCHAN = 80;  // the channel sum of the NCH above (C3/C11)

  function automatic int unsigned chan_base(input int unsigned b);
    int unsigned acc;
    acc = 0;
    for (int unsigned k = 0; k < b; k++) begin
      acc += nch(k);
    end
    chan_base = acc;
  endfunction

  // PIN_BASE by the generator's rule (12.4): within a partition, member blocks
  // take pins in ascending block index, contiguously from pin 0, NCH[b] each.
  function automatic int unsigned pin_base(input logic [3:0] part,
                                           input int unsigned b);
    logic [NBLK-1:0] mask;
    int unsigned     acc;
    mask = part_map_sel(part);
    acc  = 0;
    for (int unsigned k = 0; k < b; k++) begin
      if (mask[k]) acc += nch(k);
    end
    pin_base = acc;
  endfunction

  // In EXTEST each block takes one pin pair, equal to its block index, and TOP
  // chain t takes pin 11 + t (12.5). Pins 14 to 19 are unmapped.
  localparam int unsigned EXTEST_TOP_PIN0  = 11;
  localparam int unsigned EXTEST_PINS_USED = 14;

  // ---------------------------------------------------------------------
  // C5/C6: the eight DeMuxSel scan modes (sheet DFT_SCAN_Test_Mode, change
  // file part 4.1). Modes 1-6 are INTEST of the blocks scan_mode_sel names,
  // block b on NCH[b] lanes from lane_lo(mode, b); mode 0 is LPDDR alone on
  // all twenty lanes (ASSUMED K17); mode 7 is EXTEST by the EXTEST_* rule
  // above (C9, ASSUMED K8). This is the one lane table: dft_scan_rtr routes
  // from it and the dv_eco bench reads it. A later answer to K12 changes this
  // table, the g_map_check literals in soc_dft.sv and the literal slices of the
  // dv_eco bench (LIT_SLICES in dv_eco/gen_tb_soc_dft_eco.py), which are kept
  // apart on purpose so that a wrong table is caught.
  // ---------------------------------------------------------------------
  localparam logic [2:0]  SMODE_LPDDR  = 3'd0;
  localparam logic [2:0]  SMODE_EXTEST = 3'd7;

  function automatic logic [NBLK-1:0] scan_mode_sel(input logic [2:0] mode);
    scan_mode_sel = '0;
    case (mode)
      3'd1: begin scan_mode_sel[BLK_PCIA]  = 1'b1; scan_mode_sel[BLK_AXIS] = 1'b1; end
      3'd2: begin scan_mode_sel[BLK_PCIB]  = 1'b1; scan_mode_sel[BLK_AXIS] = 1'b1; end
      3'd3: begin scan_mode_sel[BLK_G2MUC] = 1'b1; scan_mode_sel[BLK_AXIM] = 1'b1;
                  scan_mode_sel[BLK_AXIS]  = 1'b1; end
      3'd4: begin scan_mode_sel[BLK_L4GA]  = 1'b1; scan_mode_sel[BLK_AHB]  = 1'b1;
                  scan_mode_sel[BLK_AXIS]  = 1'b1; end
      3'd5: begin scan_mode_sel[BLK_L4GB]  = 1'b1; scan_mode_sel[BLK_APB]  = 1'b1;
                  scan_mode_sel[BLK_AXIS]  = 1'b1; end
      3'd6: begin scan_mode_sel[BLK_SCC]   = 1'b1; scan_mode_sel[BLK_HIC]  = 1'b1;
                  scan_mode_sel[BLK_AXIS]  = 1'b1; end
      default: scan_mode_sel = '0;
    endcase
  endfunction

  // The lowest lane of block b in mode 1-6. Modes 1 and 6 are as the
  // customer drew them; modes 2-5 take the same shape, big block on the top
  // lanes, middle block next, Axis on lanes 7:0 (ASSUMED K12). Axis is on
  // lanes 7:0 in all six, so the 6:1 Axis mux of the drawing is this one
  // table entry: its six inputs are the same lanes (ASSUMED K13).
  function automatic int unsigned lane_lo(input logic [2:0] mode,
                                          input int unsigned b);
    lane_lo = 0;
    case (mode)
      3'd1: if (b == BLK_PCIA)  lane_lo = 8;
      3'd2: if (b == BLK_PCIB)  lane_lo = 8;
      3'd3: if (b == BLK_G2MUC) lane_lo = 12; else if (b == BLK_AXIM) lane_lo = 8;
      3'd4: if (b == BLK_L4GA)  lane_lo = 12; else if (b == BLK_AHB)  lane_lo = 8;
      3'd5: if (b == BLK_L4GB)  lane_lo = 12; else if (b == BLK_APB)  lane_lo = 8;
      3'd6: if (b == BLK_SCC)   lane_lo = 14; else if (b == BLK_HIC)  lane_lo = 8;
      default: lane_lo = 0;
    endcase
  endfunction

  // The source also lists three derived arrays, SO_VALID, SO_BLK and SO_CH,
  // emitted as literals by the generator: pin k of INTEST partition p carries
  // channel k - PIN_BASE[p][b] of block b when PART_MAP_SEL[p][b] is 1 and
  // PIN_BASE[p][b] <= k < PIN_BASE[p][b] + NCH[b], and SO_VALID is 0 for
  // PART 0 and PART 15, which have their own routing branches.
  //
  // They are not functions here, and since the change round of 12 Nov 2026 no
  // module routes by them or by PIN_BASE: dft_scan_rtr builds one named slice
  // per block and mode from scan_mode_sel, lane_lo, nch and chan_base above.

  // ---------------------------------------------------------------------
  // TAP instruction codes (9.4, Table 48)
  // ---------------------------------------------------------------------
  localparam int unsigned IRW = 5;
  localparam logic [IRW-1:0] IR_IDCODE    = 5'b00001;
  localparam logic [IRW-1:0] IR_DTR_CFG   = 5'b00010;
  localparam logic [IRW-1:0] IR_DTR_LPDDR = 5'b00011;
  localparam logic [IRW-1:0] IR_DTR_STS   = 5'b00100;
  localparam logic [IRW-1:0] IR_DDR0_CMD  = 5'b00101;
  localparam logic [IRW-1:0] IR_DDR0_RD   = 5'b00110;
  localparam logic [IRW-1:0] IR_DDR1_CMD  = 5'b00111;
  localparam logic [IRW-1:0] IR_DDR1_RD   = 5'b01000;
  localparam logic [IRW-1:0] IR_DTR_TM    = 5'b01001;  // C0a; ASSUMED: the first code Table 46 leaves free
  localparam logic [IRW-1:0] IR_BYPASS    = 5'b11111;

  // ---------------------------------------------------------------------
  // TAP state codes (9.3). The four-bit state register uses all sixteen
  // codes, so no code is unreachable by encoding.
  // ---------------------------------------------------------------------
  localparam logic [3:0] TEST_LOGIC_RESET    = 4'hF;
  localparam logic [3:0] RUN_TEST_IDLE    = 4'hC;
  localparam logic [3:0] SELECT_DR_SCAN = 4'h7;
  localparam logic [3:0] CAPTURE_DR = 4'h6;
  localparam logic [3:0] SHIFT_DR  = 4'h2;
  localparam logic [3:0] EXIT1_DR = 4'h1;
  localparam logic [3:0] PAUSE_DR = 4'h3;
  localparam logic [3:0] EXIT2_DR = 4'h0;
  localparam logic [3:0] UPDATE_DR = 4'h5;
  localparam logic [3:0] SELECT_IR_SCAN = 4'h4;
  localparam logic [3:0] CAPTURE_IR = 4'hE;
  localparam logic [3:0] SHIFT_IR  = 4'hA;
  localparam logic [3:0] EXIT1_IR = 4'h9;
  localparam logic [3:0] PAUSE_IR = 4'hB;
  localparam logic [3:0] EXIT2_IR = 4'h8;
  localparam logic [3:0] UPDATE_IR = 4'hD;

  // ---------------------------------------------------------------------
  // DTR_CFG fields (10.2). CLR is bit 31 and is read from the shift stage at
  // Update-DR, never from the shadow: the shadow holds 0 in bits 31:23, which
  // is why DTR_CFG.CLR always reads back 0 (INV-08).
  // ---------------------------------------------------------------------
  // PART (bits 3:0) is kept as delivered and still reads back, in DTR_CFG and
  // in DTR_STS.PART. Since the change round of 12 Nov 2026 it no longer
  // drives the scan routing or any shift enable: DeMuxSel selects the scan
  // mode (C5/C6).
  localparam int unsigned CFG_PART_LO       = 0;
  localparam int unsigned CFG_PART_HI       = 3;
  localparam int unsigned CFG_BURNIN        = 4;
  localparam int unsigned CFG_PLL_BYP       = 5;
  localparam int unsigned CFG_RST_OVR       = 6;
  localparam int unsigned CFG_RST_VAL       = 7;
  localparam int unsigned CFG_BLK_CLK_EN_LO = 8;
  localparam int unsigned CFG_BLK_CLK_EN_HI = 20;
  // bit 21 (SE_GATE) stays in the register and reads back, but nothing reads
  // it since the shift enables come straight from DFTSE (C1). It is kept as
  // delivered (change round of 12 Nov 2026) and no longer gates any shift
  // enable; it never took part in the scan routing.
  localparam int unsigned CFG_DDR_TDR_EN    = 22;
  localparam int unsigned CFG_CLR           = 31;
  localparam logic [31:0] CFG_SHADOW_MASK   = 32'h007F_FFFF;  // bits 31:23 read 0

  // ---------------------------------------------------------------------
  // DTR_LPDDR fields (10.3). Bits 31:18 read 0.
  // ---------------------------------------------------------------------
  localparam int unsigned LP_ATPG_MODE_OVR     = 0;
  localparam int unsigned LP_ATPG_MODE_VAL     = 1;
  localparam int unsigned LP_COMP_OVR          = 2;
  localparam int unsigned LP_COMP_VAL          = 3;
  localparam int unsigned LP_PHY0_BURNIN       = 4;
  localparam int unsigned LP_PHY1_BURNIN       = 5;
  localparam int unsigned LP_SFP_DFT_MODE      = 6;
  localparam int unsigned LP_RING_BYPASS_LO    = 7;
  localparam int unsigned LP_RING_BYPASS_HI    = 13;
  localparam int unsigned LP_SMS_DM_LO         = 14;
  localparam int unsigned LP_SMS_DM_HI         = 16;
  localparam int unsigned LP_SCAN_SHIFT_CG_OVR = 17;
  localparam logic [31:0] LP_SHADOW_MASK       = 32'h0003_FFFF;

  // ---------------------------------------------------------------------
  // DTR_TM fields (C0a). Block b's two test_mode bits are bits 2b+1:2b, in the
  // block index order above (ASSUMED: no source gives the layout); bit 22 is
  // the pad loopback (C7, ASSUMED K7).
  // Bits 31:23 read 0.
  // ---------------------------------------------------------------------
  localparam int unsigned TM_MODE_LO     = 0;
  localparam int unsigned TM_MODE_HI     = NSCAN*TMW - 1;   // 21
  localparam int unsigned TM_LOOPBACK    = 22;
  localparam logic [31:0] TM_SHADOW_MASK = 32'h007F_FFFF;

  // ---------------------------------------------------------------------
  // DTR_STS fields (Table 52), capture only. Bit 24 is reserved because the
  // G2 SMS wrapper has no busy output, so no BIST interlock can be captured.
  // ---------------------------------------------------------------------
  localparam int unsigned STS_DFTTM        = 0;
  localparam int unsigned STS_DFTMAX_COMP  = 1;
  localparam int unsigned STS_TSEL1_LO     = 2;
  localparam int unsigned STS_TSEL1_HI     = 3;
  localparam int unsigned STS_PLL_RDY_LO   = 4;
  localparam int unsigned STS_PLL_RDY_HI   = 6;
  localparam int unsigned STS_PWROK        = 7;
  // PART (bits 11:8, a copy of DTR_CFG.PART) and NPART (bits 15:12, the
  // constant NPART) are kept as delivered and still read back. Since the
  // change round of 12 Nov 2026 neither drives the scan routing or any shift
  // enable.
  localparam int unsigned STS_PART_LO      = 8;
  localparam int unsigned STS_PART_HI      = 11;
  localparam int unsigned STS_NPART_LO     = 12;
  localparam int unsigned STS_NPART_HI     = 15;
  localparam int unsigned STS_RTL_REV_LO   = 16;
  localparam int unsigned STS_RTL_REV_HI   = 23;
  localparam int unsigned STS_SMS_BUSY_RSVD = 24;

  // The eight levels DTR_STS captures through two-flop synchronisers, in the
  // order they are packed into the synchroniser (Table 52).
  localparam int unsigned N_STS_SYNC = 8;

endpackage
