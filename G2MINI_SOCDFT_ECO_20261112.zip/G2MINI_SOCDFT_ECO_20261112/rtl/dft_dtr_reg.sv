// Artifact identity: RTL
//
// dft_dtr_reg -- the generic JTAG data-register engine of SOC_DFT. One shift
// stage on the rising TCK1 edge, one shadow stage loaded at Update-DR on the
// falling edge, and a capture of either the shadow (a configuration register)
// or a status input (a capture-only register).
//
// All three DFT test registers are instances of this one module, so the shift,
// capture and update behaviour cannot drift between them.
//
// Actions implemented: ACT-DTR-CAP, ACT-DTR-STS, ACT-DTR-SHIFT, ACT-DTR-HOLD,
// ACT-DTR-UPD, ACT-DTR-GATE, ACT-DTR-CLR, ACT-DTR-RST, ACT-DTR-TLRHOLD.
// Invariants: INV-11 (the shadows change only at Update-DR with DFTTM low, on
// rst_dtr_n, or on CLR), INV-08 (CLR reads back 0).

// REQUIREMENTS (derived from declarations/dispositions.json):
//   DFT test registers: REQ-10, REQ-11, REQ-12, REQ-13, REQ-23, REQ-35
//   configuration write protection in test: REQ-10, REQ-11, REQ-24, REQ-35
// end REQUIREMENTS

module dft_dtr_reg #(
    parameter int unsigned P_WIDTH   = 32,
    // 1 = the register has a shadow stage and captures it (DTR_CFG, DTR_LPDDR)
    // 0 = capture only, from capture_value (DTR_STS)
    parameter bit          P_HAS_SHADOW = 1'b1,
    parameter logic [31:0] P_RESET   = 32'h0000_0000,
    // the bits the shadow holds; the rest read 0, which is how a reserved
    // field and the self-clearing CLR bit return 0 (INV-08)
    parameter logic [31:0] P_MASK    = 32'hFFFF_FFFF
) (
    input  logic               tck1,
    input  logic               rst_dtr_n,
    input  logic               tdi,
    input  logic               tm,
    // decoded strobes from the TAP, already qualified with this register's
    // instruction match
    input  logic               sel,
    input  logic               capture_dr,
    input  logic               shift_dr,
    input  logic               update_dr,
    // the value a capture-only register loads
    input  logic [P_WIDTH-1:0] capture_value,
    // a synchronous clear request, taken from the shift stage at Update-DR
    input  logic               clr_req,
    output logic [P_WIDTH-1:0] shadow,
    // the shift stage itself, for the one bit that is acted on at Update-DR
    // from the written word rather than from the shadow (DTR_CFG.CLR)
    output logic [P_WIDTH-1:0] sr_value,
    output logic               dr_tdo
);

  logic [P_WIDTH-1:0] sr_q;
  logic [P_WIDTH-1:0] shadow_q;

  // ---------------------------------------------------------------------
  // The shift stage. Rising edge, LSB first toward TDO. It carries no reset:
  // it is loaded at Capture-DR before any shift can reach TDO, and the TAP's
  // TDO stage holds its value outside the shift states.
  // ---------------------------------------------------------------------
  always_ff @(posedge tck1) begin
    if (sel && capture_dr) begin
      sr_q <= P_HAS_SHADOW ? shadow_q : capture_value;
    end else if (sel && shift_dr) begin
      sr_q <= {tdi, sr_q[P_WIDTH-1:1]};
    end
  end

  assign dr_tdo   = sr_q[0];
  assign sr_value = sr_q;

  // ---------------------------------------------------------------------
  // The shadow stage. Falling edge at Update-DR, and only while DFTTM is low:
  // a scan session forces a TMS = 1 walk that passes through Update-DR, and
  // without the ~tm term that walk would overwrite the configuration the
  // session is running under (8.1, 10.6, 15.4).
  //
  // CLR is synchronous and returns both this register and its sibling to the
  // reset value; the sibling's instance receives the same clr_req.
  // ---------------------------------------------------------------------
  if (P_HAS_SHADOW) begin : g_shadow
    always_ff @(negedge tck1 or negedge rst_dtr_n) begin
      if (!rst_dtr_n) begin
        shadow_q <= P_RESET[P_WIDTH-1:0] & P_MASK[P_WIDTH-1:0];
      end else if (update_dr && !tm) begin
        if (clr_req) shadow_q <= P_RESET[P_WIDTH-1:0] & P_MASK[P_WIDTH-1:0];
        else if (sel) shadow_q <= sr_q & P_MASK[P_WIDTH-1:0];
      end
    end
  end else begin : g_no_shadow
    // A capture-only register has no shadow. Its output is tied to its reset
    // value so that every bit of the module's interface is defined; nothing
    // reads it.
    assign shadow_q = P_RESET[P_WIDTH-1:0] & P_MASK[P_WIDTH-1:0];

    // rst_dtr_n, tm, update_dr and clr_req are the four controls the shadow
    // stage above reads on every load. They are ports of this module
    // whichever way it is built -- the u_cfg and u_lpddr instances read all
    // four -- and in this elaboration the stage they belong to is gone, so
    // nothing reads them here. One deliberate sink reads them, named for
    // what it is: the same device the SMS shell uses for its contracted
    // inputs (rtl/dft_sms_srv.sv), and for the same reason. The sink is
    // combinational, drives nothing, and synthesises away; what it buys is
    // that an unread port of this module is a report worth keeping, because
    // the ports that are unread by construction are read here on purpose.
    logic unused_no_shadow_controls;
    assign unused_no_shadow_controls = ^{1'b0, rst_dtr_n, tm, update_dr,
                                         clr_req};
  end

  assign shadow = shadow_q;

endmodule
