// Artifact identity: RTL
//
// dft_crg_ctl -- the combinational clock and reset control SOC_DFT sends to the
// chip Clock and Reset Generator: test clock select, PLL bypass force, the
// per-block and LPDDR ICG enables, the reset bypass select and Rst_n_test.
//
// The multiplexers themselves are in the CRG, not here. What this module owns
// is their selects, and the two selects a tester depends on go through library
// mux cells carried with dont_touch so that synthesis cannot restructure them
// (D89-D91, 24.11).
//
// Actions implemented: ACT-M0-CRG, ACT-CRG-SEL, ACT-CRG-PLL, ACT-CRG-BLK,
// ACT-CRG-COMP, ACT-CRG-LPDDR, ACT-CRG-RST, ACT-CRG-RSTOVR.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   functional-mode safe state: REQ-01, REQ-02, REQ-20, REQ-22, REQ-23, REQ-24
//   test clock control: REQ-22
//   test reset control: REQ-22
// end REQUIREMENTS

module dft_crg_ctl (
    input  logic        tm,
    input  logic        dftmax_i,
    input  logic        rstn_pad,
    input  logic [31:0] dtr_cfg,
    input  logic [12:0] sel,
    input  logic [12:0] active,
    output logic        dft_crg_test_clk_sel,
    output logic [2:0]  dft_crg_pll_byp,
    output logic [12:0] dft_crg_blk_clk_en,
    output logic [12:0] dft_crg_comp_clk_en,
    output logic [4:0]  dft_crg_lpddr_clk_en,
    output logic        dft_crg_rst_byp,
    output logic        dft_crg_rst_n_test,
    output logic        lpddr_scan_rstn
);
  logic        pll_byp;
  logic        rst_ovr;
  logic        rst_val;
  logic [12:0] blk_clk_en;

  assign pll_byp    = dtr_cfg[dft_part_map_pkg::CFG_PLL_BYP];
  assign rst_ovr    = dtr_cfg[dft_part_map_pkg::CFG_RST_OVR];
  assign rst_val    = dtr_cfg[dft_part_map_pkg::CFG_RST_VAL];
  assign blk_clk_en = dtr_cfg[dft_part_map_pkg::CFG_BLK_CLK_EN_HI:dft_part_map_pkg::CFG_BLK_CLK_EN_LO];

  // ---------------------------------------------------------------------
  // ACT-CRG-SEL and ACT-M0-CRG. Both selects follow DFTTM: in functional mode
  // the CRG uses its functional roots and its own resets, and nothing SOC_DFT
  // drives can move them.
  // ---------------------------------------------------------------------
  assign dft_crg_test_clk_sel = tm;
  assign dft_crg_rst_byp      = tm;

  // ACT-CRG-PLL: the bypass force is the second bypass path, beside the PLLxk
  // pins; all three bits move together.
  assign dft_crg_pll_byp = {3{tm & pll_byp}};

  // ---------------------------------------------------------------------
  // The clock enables. A block's test clock runs only when the configuration
  // enables its bit and the partition exercises it, so an unselected block
  // holds its clock and burns no power and shifts nothing.
  //
  // The compression clock additionally needs DFTMAX and selection: a block
  // exercised through its wrapper in EXTEST has no codec to clock. Bits 3, 4,
  // 5, 6, 11 and 12 have no compression codec behind them and are left
  // unconnected at the CRG by design; they are driven here from the same rule
  // rather than tied, so the rule has one form.
  // ---------------------------------------------------------------------
  always_comb begin
    dft_crg_blk_clk_en  = '0;
    dft_crg_comp_clk_en = '0;
    if (tm) begin
      for (int unsigned b = 0; b < dft_part_map_pkg::NBLK; b++) begin
        dft_crg_blk_clk_en[b]  = blk_clk_en[b] & active[b];
        dft_crg_comp_clk_en[b] = blk_clk_en[b] & sel[b] & dftmax_i;
      end
    end else begin
      // ACT-M0-CRG: every test-clock gate is open in functional mode, which
      // is the value the CRG needs when SOC_DFT is not driving a session.
      dft_crg_blk_clk_en = 13'h1FFF;
    end
  end

  // ACT-CRG-LPDDR: the five LPDDR ATPG clocks share one enable condition.
  assign dft_crg_lpddr_clk_en = {5{tm & active[dft_part_map_pkg::BLK_LPDDR] & blk_clk_en[dft_part_map_pkg::BLK_LPDDR]}};

  // ---------------------------------------------------------------------
  // ACT-CRG-RST and ACT-CRG-RSTOVR. The test reset is the Rstn pad unless
  // DTR_CFG.RST_OVR substitutes RST_VAL. The select goes through a library mux
  // cell: this is the reset a whole scan session runs under, and a tester must
  // be able to point at the gate that chose it.
  // ---------------------------------------------------------------------
  dft_mux2 u_dft_mux2_rst_dont_touch (
      .d0(rstn_pad),
      .d1(rst_val),
      .s (rst_ovr),
      .y (dft_crg_rst_n_test)
  );

  // ACT-CRG-LPRST: the LPDDR scan reset is the test reset in test and 1
  // otherwise, so the PHY is never held in reset in functional mode. It is the
  // second select on the reset path a session depends on, so it is the second
  // library mux cell.
  dft_mux2 u_dft_mux2_scan_rstn_dont_touch (
      .d0(1'b1),
      .d1(dft_crg_rst_n_test),
      .s (tm),
      .y (lpddr_scan_rstn)
  );

endmodule
