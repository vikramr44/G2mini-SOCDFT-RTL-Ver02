// Artifact identity: RTL
//
// dft_scan_rtr -- the combinational scan router between the twenty DFTSI and
// DFTSO pin pairs and the block channels, the wrapper chains and the TOP
// chains.
//
// There is no retiming flop on any scan path: a flop here would add a cycle to
// every channel and the pattern set does not expect one (12.8).
//
// The block side is packed: block b owns NCH[b] channels of the channel bus
// from CHAN_BASE[b], low block first, and one wrapper-chain bit. A packed
// vector rather than an unpacked array, because an unpacked array port is not
// read by every front end the RTL checks run.
//
// Structure (change round of 12 Nov 2026, C5, C6), coded as the change
// file's diagram draws it, selected by DeMuxSel:
//
//   1. The 1:7 demux. Seven per-mode scan-in buses stm_si[0..6]: stm_si[m]
//      is DFTSI when DeMuxSel is m, else 0. Mode 0 is LPDDR, modes 1-6 are
//      INTEST. The demux is closed (all buses 0) when tm is 0 or the pin
//      loopback is on.
//   2. Named slices. Each block takes its lanes from the bus of its own
//      mode, as drawn (the lane numbers here and in the comments below are
//      today's table values; the code reads them from the package):
//        mode 0: lpddr_test_si = stm_si[0]
//        mode 1: pcia  = stm_si[1][19:8]
//        mode 2: pcib  = stm_si[2][19:8]
//        mode 3: g2muc = stm_si[3][19:12], axim = stm_si[3][11:8]
//        mode 4: l4ga  = stm_si[4][19:12], ahb  = stm_si[4][11:8]
//        mode 5: l4gb  = stm_si[5][19:12], apb  = stm_si[5][11:8]
//        mode 6: scc   = stm_si[6][19:14], hic  = stm_si[6][13:8]
//      Modes 2-5 follow the current lane table (ASSUMED K12). Every slice
//      position and width is read from dft_part_map_pkg (scan_mode_sel,
//      lane_lo, nch, chan_base), so soc_dft's g_map_check still checks
//      them and a later answer to K12 changes that table (and the checks
//      that hold it) and not this module's code.
//   3. The Axis 6:1 mux (the drawing's "Primary Addition to enable
//      DFT_Opt_8"). Axis takes its scan-in from stm_si[1..6][7:0], picked
//      by DeMuxSel. Its six inputs carry the same lanes, 7:0 in every mode
//      (ASSUMED K13).
//   4. The per-block feed enable. A block is fed, and its return is put on
//      its mode's scan-out bus, only when sel[b] is 1.
//   5. The 7:1 mux. Seven per-mode scan-out buses stm_so[0..6] are built
//      from the block returns as drawn (stm_so[0] is the LPDDR return), and
//      DFTSO is the 7:1 mux of stm_so by DeMuxSel.
//
// Mode 7 (EXTEST) and the pin loopback are routed beside this structure, as
// before: the loopback has priority over every mode, and EXTEST needs both
// DeMuxSel = 7 and the extest flag. Unmapped lanes drive 0, and every output
// is 0 when tm is 0.
//
// Actions implemented: the ACT-RTR-* family, ACT-RTR-UNMAPPED (an unmapped
// lane drives 0), ACT-RTR-LOOPBACK.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   functional-mode safe state: REQ-01, REQ-02, REQ-20, REQ-22, REQ-23, REQ-24
//   partition select and scan routing: REQ-14, REQ-16, REQ-17, REQ-37
//   EXTEST wrapper routing: REQ-14, REQ-16, REQ-18
//   pin loopback: REQ-19
// end REQUIREMENTS

module dft_scan_rtr (
    input  logic         tm,
    input  logic [2:0]   demux_sel,     // C4, C6: replaces the PART field
    input  logic [12:0]  sel,
    input  logic         extest,
    input  logic         loopback,
    input  logic [19:0]  dftsi,
    input  logic [dft_part_map_pkg::NCHAN-1:0] blk_test_so,   // 11 blocks, NCH[b] each
    input  logic [10:0]  blk_wrap_so,   // one wrapper chain per block (C3/C11)
    input  logic [2:0]   top_test_so,
    input  logic [19:0]  lpddr_test_so, // mode 0 (ASSUMED K17)
    output logic [dft_part_map_pkg::NCHAN-1:0] blk_test_si,
    output logic [10:0]  blk_wrap_si,
    output logic [2:0]   top_test_si,
    output logic [19:0]  lpddr_test_si, // mode 0 (ASSUMED K17)
    output logic [19:0]  dftso
);

  // ---------------------------------------------------------------------
  // Mode counts, read from the package's mode codes. The demux has one
  // output per mode below EXTEST (modes 0 to 6); the INTEST modes are the
  // ones between LPDDR and EXTEST (modes 1 to 6).
  // ---------------------------------------------------------------------
  localparam int unsigned NPIN    = dft_part_map_pkg::NPIN;
  localparam int unsigned NMODE   = 32'(dft_part_map_pkg::SMODE_EXTEST);     // 7 demux outputs
  localparam int unsigned M_FIRST = 32'(dft_part_map_pkg::SMODE_LPDDR) + 1;  // first INTEST mode
  localparam int unsigned M_LAST  = NMODE - 1;                               // last INTEST mode
  localparam int unsigned NAXM    = M_LAST - M_FIRST + 1;                    // 6 Axis mux inputs

  // The INTEST mode a block belongs to: the first mode 1-6 whose
  // scan_mode_sel names it. Axis is in all six and takes the 6:1 mux
  // instead, so this is not used for Axis.
  function automatic logic [2:0] home_mode(input int unsigned b);
    logic in_m;   // 1 when mode m names block b
    home_mode = dft_part_map_pkg::SMODE_LPDDR;
    for (int unsigned m = M_FIRST; m <= M_LAST; m++) begin
      in_m = 1'(dft_part_map_pkg::scan_mode_sel(3'(m)) >> b);
      if (in_m && (home_mode == dft_part_map_pkg::SMODE_LPDDR))
        home_mode = 3'(m);
    end
  endfunction

  // ---------------------------------------------------------------------
  // Per block: its mode (M_), its lowest lane in that mode (LO_), its
  // channel count (N_) and its base on the channel bus (CB_), all from the
  // package.
  // ---------------------------------------------------------------------
  localparam logic [2:0]  M_PCIA   = 3'd1;
  localparam int unsigned LO_PCIA  = 8;
  localparam int unsigned N_PCIA   = 12;
  localparam int unsigned CB_PCIA  = 36;

  localparam logic [2:0]  M_PCIB   = 3'd2;
  localparam int unsigned LO_PCIB  = 8;
  localparam int unsigned N_PCIB   = 12;
  localparam int unsigned CB_PCIB  = 48;

  localparam logic [2:0]  M_G2MUC  = 3'd3;
  localparam int unsigned LO_G2MUC = 12;
  localparam int unsigned N_G2MUC  = 8;
  localparam int unsigned CB_G2MUC = 12;

  localparam logic [2:0]  M_AXIM   = 3'd3;
  localparam int unsigned LO_AXIM  = 8;
  localparam int unsigned N_AXIM   = 4;
  localparam int unsigned CB_AXIM  = 76;

  localparam logic [2:0]  M_L4GA   = 3'd4;
  localparam int unsigned LO_L4GA  = 12;
  localparam int unsigned N_L4GA   = 8;
  localparam int unsigned CB_L4GA  = 20;

  localparam logic [2:0]  M_AHB    = 3'd4;
  localparam int unsigned LO_AHB   = 8;
  localparam int unsigned N_AHB    = 4;
  localparam int unsigned CB_AHB   = 60;

  localparam logic [2:0]  M_L4GB   = 3'd5;
  localparam int unsigned LO_L4GB  = 12;
  localparam int unsigned N_L4GB   = 8;
  localparam int unsigned CB_L4GB  = 28;

  localparam logic [2:0]  M_APB    = 3'd5;
  localparam int unsigned LO_APB   = 8;
  localparam int unsigned N_APB    = 4;
  localparam int unsigned CB_APB   = 64;

  localparam logic [2:0]  M_SCC    = 3'd6;
  localparam int unsigned LO_SCC   = 14;
  localparam int unsigned N_SCC    = 6;
  localparam int unsigned CB_SCC   = 0;

  localparam logic [2:0]  M_HIC    = 3'd6;
  localparam int unsigned LO_HIC   = 8;
  localparam int unsigned N_HIC    = 6;
  localparam int unsigned CB_HIC   = 6;

  // Axis: in every INTEST mode, through the 6:1 mux (ASSUMED K13).
  localparam int unsigned N_AXIS   = 8;
  localparam int unsigned CB_AXIS  = 68;

  // ---------------------------------------------------------------------
  // 1. The 1:7 demux: stm_si[m] = DFTSI when DeMuxSel == m, else 0.
  // ---------------------------------------------------------------------
  logic                       rt_en;    // test mode and no pin loopback
  logic [NMODE-1:0][NPIN-1:0] stm_si;   // per-mode scan-in buses, modes 0..6

  assign rt_en = tm & ~loopback;

  for (genvar m = 0; m < NMODE; m++) begin : g_demux
    assign stm_si[m] = (rt_en && (demux_sel == 3'(m))) ? dftsi : '0;
  end

  // Mode 0: LPDDR alone on all twenty lanes (ASSUMED K17).
  assign lpddr_test_si = stm_si[dft_part_map_pkg::SMODE_LPDDR];

  // ---------------------------------------------------------------------
  // 2. Named slices, each block from the bus of its own mode.
  // ---------------------------------------------------------------------
  logic [N_PCIA-1:0]  pcia_si;    // mode 1: stm_si[1][19:8]
  logic [N_PCIB-1:0]  pcib_si;    // mode 2: stm_si[2][19:8]
  logic [N_G2MUC-1:0] g2muc_si;   // mode 3: stm_si[3][19:12]
  logic [N_AXIM-1:0]  axim_si;    // mode 3: stm_si[3][11:8]
  logic [N_L4GA-1:0]  l4ga_si;    // mode 4: stm_si[4][19:12]
  logic [N_AHB-1:0]   ahb_si;     // mode 4: stm_si[4][11:8]
  logic [N_L4GB-1:0]  l4gb_si;    // mode 5: stm_si[5][19:12]
  logic [N_APB-1:0]   apb_si;     // mode 5: stm_si[5][11:8]
  logic [N_SCC-1:0]   scc_si;     // mode 6: stm_si[6][19:14]
  logic [N_HIC-1:0]   hic_si;     // mode 6: stm_si[6][13:8]

  assign pcia_si  = stm_si[M_PCIA][LO_PCIA +: N_PCIA];
  assign pcib_si  = stm_si[M_PCIB][LO_PCIB +: N_PCIB];
  assign g2muc_si = stm_si[M_G2MUC][LO_G2MUC +: N_G2MUC];
  assign axim_si  = stm_si[M_AXIM][LO_AXIM +: N_AXIM];
  assign l4ga_si  = stm_si[M_L4GA][LO_L4GA +: N_L4GA];
  assign ahb_si   = stm_si[M_AHB][LO_AHB +: N_AHB];
  assign l4gb_si  = stm_si[M_L4GB][LO_L4GB +: N_L4GB];
  assign apb_si   = stm_si[M_APB][LO_APB +: N_APB];
  assign scc_si   = stm_si[M_SCC][LO_SCC +: N_SCC];
  assign hic_si   = stm_si[M_HIC][LO_HIC +: N_HIC];

  // ---------------------------------------------------------------------
  // 3. The Axis 6:1 mux ("Primary Addition to enable DFT_Opt_8"). Input k
  // is the Axis lanes of mode k + 1. The six inputs carry the same lanes,
  // 7:0 in every mode (ASSUMED K13); a mode whose scan_mode_sel does not
  // name Axis gives that input 0.
  // ---------------------------------------------------------------------
  logic [NAXM-1:0][N_AXIS-1:0] axis_si_in;   // the six mux inputs
  logic [N_AXIS-1:0]           axis_si;      // the mux output

  for (genvar k = 0; k < NAXM; k++) begin : g_axis_in
    localparam logic [2:0] MK = 3'(k + M_FIRST);
    localparam logic [dft_part_map_pkg::NBLK-1:0] MSEL = dft_part_map_pkg::scan_mode_sel(MK);
    localparam int unsigned LO = dft_part_map_pkg::lane_lo(MK, dft_part_map_pkg::BLK_AXIS);
    if (MSEL[dft_part_map_pkg::BLK_AXIS]) begin : g_on
      assign axis_si_in[k] = stm_si[MK][LO +: N_AXIS];
    end else begin : g_off
      assign axis_si_in[k] = '0;
    end
  end

  always_comb begin
    axis_si = '0;
    for (int unsigned k = 0; k < NAXM; k++) begin
      if (demux_sel == 3'(k + M_FIRST)) axis_si = axis_si_in[k];
    end
  end

  // ---------------------------------------------------------------------
  // 4. The per-block feed enable: block b is fed only when sel[b] is 1.
  // ---------------------------------------------------------------------
  logic [N_PCIA-1:0]  pcia_fd;
  logic [N_PCIB-1:0]  pcib_fd;
  logic [N_G2MUC-1:0] g2muc_fd;
  logic [N_AXIM-1:0]  axim_fd;
  logic [N_L4GA-1:0]  l4ga_fd;
  logic [N_AHB-1:0]   ahb_fd;
  logic [N_L4GB-1:0]  l4gb_fd;
  logic [N_APB-1:0]   apb_fd;
  logic [N_SCC-1:0]   scc_fd;
  logic [N_HIC-1:0]   hic_fd;
  logic [N_AXIS-1:0]  axis_fd;

  assign pcia_fd  = sel[dft_part_map_pkg::BLK_PCIA]  ? pcia_si  : '0;
  assign pcib_fd  = sel[dft_part_map_pkg::BLK_PCIB]  ? pcib_si  : '0;
  assign g2muc_fd = sel[dft_part_map_pkg::BLK_G2MUC] ? g2muc_si : '0;
  assign axim_fd  = sel[dft_part_map_pkg::BLK_AXIM]  ? axim_si  : '0;
  assign l4ga_fd  = sel[dft_part_map_pkg::BLK_L4GA]  ? l4ga_si  : '0;
  assign ahb_fd   = sel[dft_part_map_pkg::BLK_AHB]   ? ahb_si   : '0;
  assign l4gb_fd  = sel[dft_part_map_pkg::BLK_L4GB]  ? l4gb_si  : '0;
  assign apb_fd   = sel[dft_part_map_pkg::BLK_APB]   ? apb_si   : '0;
  assign scc_fd   = sel[dft_part_map_pkg::BLK_SCC]   ? scc_si   : '0;
  assign hic_fd   = sel[dft_part_map_pkg::BLK_HIC]   ? hic_si   : '0;
  assign axis_fd  = sel[dft_part_map_pkg::BLK_AXIS]  ? axis_si  : '0;

  // each block's feed on its own channels of the channel bus
  always_comb begin
    blk_test_si = '0;
    blk_test_si[CB_PCIA  +: N_PCIA]  = pcia_fd;
    blk_test_si[CB_PCIB  +: N_PCIB]  = pcib_fd;
    blk_test_si[CB_G2MUC +: N_G2MUC] = g2muc_fd;
    blk_test_si[CB_AXIM  +: N_AXIM]  = axim_fd;
    blk_test_si[CB_L4GA  +: N_L4GA]  = l4ga_fd;
    blk_test_si[CB_AHB   +: N_AHB]   = ahb_fd;
    blk_test_si[CB_L4GB  +: N_L4GB]  = l4gb_fd;
    blk_test_si[CB_APB   +: N_APB]   = apb_fd;
    blk_test_si[CB_SCC   +: N_SCC]   = scc_fd;
    blk_test_si[CB_HIC   +: N_HIC]   = hic_fd;
    blk_test_si[CB_AXIS  +: N_AXIS]  = axis_fd;
  end

  // sel[11] (LPDDR) and sel[12] (TOP) select no channel of the block bus:
  // LPDDR is fed by stm_si[0] in mode 0 and the TOP chains only in EXTEST.
  // The name carries the `unused` mark the lint front ends recognise.
  logic unused_sel_no_channel;
  assign unused_sel_no_channel = ^{1'b0, sel[dft_part_map_pkg::BLK_LPDDR],
                                         sel[dft_part_map_pkg::BLK_TOP]};

  // ---------------------------------------------------------------------
  // 5. The block returns, gated by the same feed enable, and the seven
  // per-mode scan-out buses built from them as drawn. A lane no block of
  // the mode drives stays 0 (ACT-RTR-UNMAPPED, REQ-20).
  // ---------------------------------------------------------------------
  logic [N_PCIA-1:0]  pcia_so;
  logic [N_PCIB-1:0]  pcib_so;
  logic [N_G2MUC-1:0] g2muc_so;
  logic [N_AXIM-1:0]  axim_so;
  logic [N_L4GA-1:0]  l4ga_so;
  logic [N_AHB-1:0]   ahb_so;
  logic [N_L4GB-1:0]  l4gb_so;
  logic [N_APB-1:0]   apb_so;
  logic [N_SCC-1:0]   scc_so;
  logic [N_HIC-1:0]   hic_so;
  logic [N_AXIS-1:0]  axis_so;

  assign pcia_so  = sel[dft_part_map_pkg::BLK_PCIA]  ? blk_test_so[CB_PCIA  +: N_PCIA]  : '0;
  assign pcib_so  = sel[dft_part_map_pkg::BLK_PCIB]  ? blk_test_so[CB_PCIB  +: N_PCIB]  : '0;
  assign g2muc_so = sel[dft_part_map_pkg::BLK_G2MUC] ? blk_test_so[CB_G2MUC +: N_G2MUC] : '0;
  assign axim_so  = sel[dft_part_map_pkg::BLK_AXIM]  ? blk_test_so[CB_AXIM  +: N_AXIM]  : '0;
  assign l4ga_so  = sel[dft_part_map_pkg::BLK_L4GA]  ? blk_test_so[CB_L4GA  +: N_L4GA]  : '0;
  assign ahb_so   = sel[dft_part_map_pkg::BLK_AHB]   ? blk_test_so[CB_AHB   +: N_AHB]   : '0;
  assign l4gb_so  = sel[dft_part_map_pkg::BLK_L4GB]  ? blk_test_so[CB_L4GB  +: N_L4GB]  : '0;
  assign apb_so   = sel[dft_part_map_pkg::BLK_APB]   ? blk_test_so[CB_APB   +: N_APB]   : '0;
  assign scc_so   = sel[dft_part_map_pkg::BLK_SCC]   ? blk_test_so[CB_SCC   +: N_SCC]   : '0;
  assign hic_so   = sel[dft_part_map_pkg::BLK_HIC]   ? blk_test_so[CB_HIC   +: N_HIC]   : '0;
  assign axis_so  = sel[dft_part_map_pkg::BLK_AXIS]  ? blk_test_so[CB_AXIS  +: N_AXIS]  : '0;

  // The Axis return on its lanes of each INTEST mode that names it (7:0 in
  // all six, ASSUMED K13): the reverse of the 6:1 mux. Entry k is mode k + 1.
  logic [NAXM-1:0][NPIN-1:0] axis_so_lanes;

  for (genvar k = 0; k < NAXM; k++) begin : g_axis_out
    localparam logic [2:0] MK = 3'(k + M_FIRST);
    localparam logic [dft_part_map_pkg::NBLK-1:0] MSEL = dft_part_map_pkg::scan_mode_sel(MK);
    localparam int unsigned LO = dft_part_map_pkg::lane_lo(MK, dft_part_map_pkg::BLK_AXIS);
    logic [NPIN-1:0] lanes;
    always_comb begin
      lanes = '0;
      if (MSEL[dft_part_map_pkg::BLK_AXIS]) lanes[LO +: N_AXIS] = axis_so;
    end
    assign axis_so_lanes[k] = lanes;
  end

  logic [NMODE-1:0][NPIN-1:0] stm_so;   // per-mode scan-out buses, modes 0..6

  always_comb begin
    stm_so = '0;
    // mode 0: the LPDDR return on all twenty lanes (ASSUMED K17)
    stm_so[dft_part_map_pkg::SMODE_LPDDR] = lpddr_test_so;
    // modes 1-6: each block's return on its own lanes of its own mode
    stm_so[M_PCIA][LO_PCIA +: N_PCIA]    = pcia_so;    // mode 1: [19:8]
    stm_so[M_PCIB][LO_PCIB +: N_PCIB]    = pcib_so;    // mode 2: [19:8]
    stm_so[M_G2MUC][LO_G2MUC +: N_G2MUC] = g2muc_so;   // mode 3: [19:12]
    stm_so[M_AXIM][LO_AXIM +: N_AXIM]    = axim_so;    // mode 3: [11:8]
    stm_so[M_L4GA][LO_L4GA +: N_L4GA]    = l4ga_so;    // mode 4: [19:12]
    stm_so[M_AHB][LO_AHB +: N_AHB]       = ahb_so;     // mode 4: [11:8]
    stm_so[M_L4GB][LO_L4GB +: N_L4GB]    = l4gb_so;    // mode 5: [19:12]
    stm_so[M_APB][LO_APB +: N_APB]       = apb_so;     // mode 5: [11:8]
    stm_so[M_SCC][LO_SCC +: N_SCC]       = scc_so;     // mode 6: [19:14]
    stm_so[M_HIC][LO_HIC +: N_HIC]       = hic_so;     // mode 6: [13:8]
    // Axis: its return on its lanes of every mode that names it
    for (int unsigned k = 0; k < NAXM; k++) begin
      stm_so[3'(k + M_FIRST)] = stm_so[3'(k + M_FIRST)] | axis_so_lanes[k];
    end
  end

  // The 7:1 mux of the per-mode scan-out buses by DeMuxSel.
  logic [NPIN-1:0] stm_mux_so;

  always_comb begin
    stm_mux_so = '0;
    for (int unsigned m = 0; m < NMODE; m++) begin
      if (demux_sel == 3'(m)) stm_mux_so = stm_so[m];
    end
  end

  // ---------------------------------------------------------------------
  // Mode 7: EXTEST of all eleven blocks (C9), only with the extest flag.
  // Each block's one wrapper chain takes the pin pair at its own block
  // index; the three TOP chains take pins 11 to 13 (ASSUMED K8), and pins 14
  // to 19 carry nothing.
  // ---------------------------------------------------------------------
  logic            ext_en;
  logic [NPIN-1:0] ext_so;

  assign ext_en = rt_en & (demux_sel == dft_part_map_pkg::SMODE_EXTEST) & extest;

  always_comb begin
    blk_wrap_si = '0;
    top_test_si = '0;
    ext_so      = '0;
    if (ext_en) begin
      for (int unsigned b = 0; b < dft_part_map_pkg::NSCAN; b++) begin
        if (dft_part_map_pkg::P0_MEMBER[b]) begin
          blk_wrap_si[b] = dftsi[b];
          ext_so[b]      = blk_wrap_so[b];
        end
      end
      for (int unsigned t = 0; t < dft_part_map_pkg::NTOP; t++) begin
        top_test_si[t] = dftsi[dft_part_map_pkg::EXTEST_TOP_PIN0 + t];
        ext_so[dft_part_map_pkg::EXTEST_TOP_PIN0 + t] = top_test_so[t];
      end
    end
  end

  // ---------------------------------------------------------------------
  // DFTSO. C7: the pin loopback (DTR_TM.LOOPBACK, ASSUMED K7) has priority
  // over every mode: each scan-in returns on its own scan-out and no block
  // is fed (the demux is closed by rt_en). Otherwise mode 7 takes the
  // EXTEST return and modes 0-6 the 7:1 mux. All 0 when tm is 0.
  // ---------------------------------------------------------------------
  always_comb begin
    dftso = '0;
    if (tm) begin
      if (loopback)
        dftso = dftsi;
      else if (demux_sel == dft_part_map_pkg::SMODE_EXTEST)
        dftso = ext_so;
      else
        dftso = stm_mux_so;
    end
  end

endmodule
