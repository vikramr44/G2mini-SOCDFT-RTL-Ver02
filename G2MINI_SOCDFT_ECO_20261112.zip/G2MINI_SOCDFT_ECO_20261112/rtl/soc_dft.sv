// Artifact identity: RTL
//
// soc_dft -- the chip-top design-for-test controller of the G2mini SoC.
//
// It sits between the bonded DFT and JTAG1 pins (fifty, plus the three
// DeMuxSel pins of the change round of 12 Nov 2026) and every block test
// port, and it owns all static test configuration except the clock and reset
// multiplexers themselves, which stay in the Clock and Reset Generator and are
// steered by the outputs below.
//
// The top instantiates the eleven sub-modules and holds the internal nets of
// 6.6. It holds no sequential element of its own: every flop of SOC_DFT is
// inside a sub-module, so that no state hides at the boundary.
//
// Hierarchy: u_soc_dft is kept through synthesis, scan insertion and
// place-and-route, because the constraints, the equivalence check and the
// connectivity check all address instance paths (D85, 24.15).

module soc_dft #(
    parameter logic [31:0] P_IDCODE       = 32'h0000_0001,  // CONF-10, IN-15
    parameter bit          P_OE_GATED     = 1'b1,
    parameter bit          P_TM_OPEN      = 1'b1,
    parameter bit          P_DFTSO_HIZ_M0 = 1'b1,           // CONF-03
    parameter logic [31:0] P_CFG_RST      = 32'h003F_FFA5,  // CONF-06
    parameter logic [31:0] P_LPDDR_RST    = 32'h0000_0000,  // CONF-26
    parameter logic [7:0]  P_RTL_REV      = 8'h05,
    parameter bit          P_TDR_EN_EDGE  = 1'b1,           // CONF-25
    parameter bit          P_DFTMAX_COMP  = 1'b1,           // CONF-39
    parameter int unsigned P_SMS_IR_LEN   = 4,              // CONF-40
    parameter logic [31:0] P_SMS_IDCODE   = 32'h0001_0001,
    parameter int unsigned P_PARTITIONED  = 1               // CONF-38
) (
    // ---- pad mode ----------------------------------------------------
    input  logic        DFTTM,
    input  logic        DFTMAX,
    // C2: DFTMAX passed through for the chip (ASSUMED K9; OPEN K9: where it goes)
    output logic        dftmax_out,
    // ---- pad scan ----------------------------------------------------
    input  logic        DFTSE,
    // OPEN K11: which six of the twenty lanes are on GPIO, and whether that
    // pad mux is inside SOC_DFT; kept twenty lanes as delivered
    input  logic [19:0] DFTSI,
    output logic [19:0] DFTSO,
    output logic        DFTSO_OE,
    // C4: the scan-mode select from the pads (OPEN K10: which GPIOs, and
    // when it may change). Like DFTMAX below, it is taken from the port and
    // not through u_pad_if, so that dft_pad_if stays byte-identical.
    input  logic [2:0]  DeMuxSel,
    // ---- JTAG1 -------------------------------------------------------
    input  logic [1:0]  TSEL1,
    input  logic        TMS1,
    input  logic        TDI1,
    output logic        TDO1,
    output logic        TDO1_OE,
    // ---- clock and reset --------------------------------------------
    input  logic        TCK1,
    input  logic        TRSTN1,
    input  logic        PwrOk,
    input  logic        Rstn,
    // ---- JTAG targets ------------------------------------------------
    // OPEN K4: the sheet's pcia/pcib tms1/tdo1/tdo1_oe rows carry no
    // comment; these ports are kept as delivered (arc_* one set for scc/hic)
    output logic        arc_tms1,
    output logic        pcia_tms1,
    output logic        pcib_tms1,
    input  logic        arc_tdo1,
    input  logic        arc_tdo1_oe,
    input  logic        pcia_tdo1,
    input  logic        pcia_tdo1_oe,
    input  logic        pcib_tdo1,
    input  logic        pcib_tdo1_oe,
    // ---- block scc (block 0, 6 channels) -----------------------------
    output logic        scc_dfttm,
    output logic        scc_scan_shift_en,
    output logic        scc_wrap_shift_en,
    output logic [1:0]  scc_test_mode,
    output logic [5:0]  scc_test_si,
    input  logic [5:0]  scc_test_so,
    output logic        scc_wrap_si,
    input  logic        scc_wrap_so,
    // ---- block hic (block 1, 6 channels) -----------------------------
    output logic        hic_dfttm,
    output logic        hic_scan_shift_en,
    output logic        hic_wrap_shift_en,
    output logic [1:0]  hic_test_mode,
    output logic [5:0]  hic_test_si,
    input  logic [5:0]  hic_test_so,
    output logic        hic_wrap_si,
    input  logic        hic_wrap_so,
    // ---- block g2muc (block 2, 8 channels) ---------------------------
    output logic        g2muc_dfttm,
    output logic        g2muc_scan_shift_en,
    output logic        g2muc_wrap_shift_en,
    output logic [1:0]  g2muc_test_mode,
    output logic [7:0]  g2muc_test_si,
    input  logic [7:0]  g2muc_test_so,
    output logic        g2muc_wrap_si,
    input  logic        g2muc_wrap_so,
    // ---- block l4ga (block 3, 8 channels) ----------------------------
    output logic        l4ga_dfttm,
    output logic        l4ga_scan_shift_en,
    output logic        l4ga_wrap_shift_en,
    output logic [1:0]  l4ga_test_mode,
    output logic [7:0]  l4ga_test_si,
    input  logic [7:0]  l4ga_test_so,
    output logic        l4ga_wrap_si,
    input  logic        l4ga_wrap_so,
    // ---- block l4gb (block 4, 8 channels) ----------------------------
    output logic        l4gb_dfttm,
    output logic        l4gb_scan_shift_en,
    output logic        l4gb_wrap_shift_en,
    output logic [1:0]  l4gb_test_mode,
    output logic [7:0]  l4gb_test_si,
    input  logic [7:0]  l4gb_test_so,
    output logic        l4gb_wrap_si,
    input  logic        l4gb_wrap_so,
    // ---- block pcia (block 5, 12 channels) ---------------------------
    output logic        pcia_dfttm,
    output logic        pcia_scan_shift_en,
    output logic        pcia_wrap_shift_en,
    output logic [1:0]  pcia_test_mode,
    output logic [11:0] pcia_test_si,
    input  logic [11:0] pcia_test_so,
    output logic        pcia_wrap_si,
    input  logic        pcia_wrap_so,
    // ---- block pcib (block 6, 12 channels) ---------------------------
    output logic        pcib_dfttm,
    output logic        pcib_scan_shift_en,
    output logic        pcib_wrap_shift_en,
    output logic [1:0]  pcib_test_mode,
    output logic [11:0] pcib_test_si,
    input  logic [11:0] pcib_test_so,
    output logic        pcib_wrap_si,
    input  logic        pcib_wrap_so,
    // ---- block ahb (block 7, 4 channels) -----------------------------
    output logic        ahb_dfttm,
    output logic        ahb_scan_shift_en,
    output logic [1:0]  ahb_test_mode,
    output logic [3:0]  ahb_test_si,
    input  logic [3:0]  ahb_test_so,
    output logic        ahb_wrap_si,
    input  logic        ahb_wrap_so,
    // ---- block apb (block 8, 4 channels) -----------------------------
    output logic        apb_dfttm,
    output logic        apb_scan_shift_en,
    output logic        apb_wrap_shift_en,
    output logic [1:0]  apb_test_mode,
    output logic [3:0]  apb_test_si,
    input  logic [3:0]  apb_test_so,
    output logic        apb_wrap_si,
    input  logic        apb_wrap_so,
    // ---- block axis (block 9, 8 channels) ----------------------------
    output logic        axis_dfttm,
    output logic        axis_scan_shift_en,
    output logic        axis_wrap_shift_en,
    output logic [1:0]  axis_test_mode,
    output logic [7:0]  axis_test_si,
    input  logic [7:0]  axis_test_so,
    output logic        axis_wrap_si,
    input  logic        axis_wrap_so,
    // ---- block axim (block 10, 4 channels) ---------------------------
    output logic        axim_dfttm,
    output logic        axim_scan_shift_en,
    output logic        axim_wrap_shift_en,
    output logic [1:0]  axim_test_mode,
    output logic [3:0]  axim_test_si,
    input  logic [3:0]  axim_test_so,
    output logic        axim_wrap_si,
    input  logic        axim_wrap_so,
    // ---- top glue ----------------------------------------------------
    output logic        top_scan_shift_en,
    output logic [2:0]  top_test_si,
    input  logic [2:0]  top_test_so,
    // ---- SMS wrapper serial ports ------------------------------------
    output logic [4:0]  scc_sms_in,
    input  logic        scc_sms_out,
    output logic [4:0]  hic_sms_in,
    input  logic        hic_sms_out,
    // C8: g2muc's two wrappers by the port sheet (block sheet rows 64-77).
    // The other blocks keep their delivered ports: OPEN S1 (the sheet's
    // names do not tell the two instances apart) and OPEN K16 (ahb widths).
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair,
    output logic [4:0]  l4ga_sms_in,
    input  logic        l4ga_sms_out,
    output logic [4:0]  l4gb_sms_in,
    input  logic        l4gb_sms_out,
    output logic [4:0]  ahb_sms_in,
    input  logic        ahb_sms_out,
    output logic [4:0]  lpddr_sms_in,
    input  logic        lpddr_sms_out,
    output logic [9:0]  pcia_sms_in,
    input  logic [1:0]  pcia_sms_out,
    output logic [9:0]  pcib_sms_in,
    input  logic [1:0]  pcib_sms_out,
    // ---- LPDDR -------------------------------------------------------
    // C5/C6: LPDDR scan in DeMuxSel mode 0 on all twenty lanes (ASSUMED
    // K17; OPEN K17: port names, the sheets have no LPDDR row)
    output logic [19:0] lpddr_test_si,
    input  logic [19:0] lpddr_test_so,
    output logic        lpddr_atpg_mode,
    output logic        lpddr_compression_mode,
    output logic        lpddr_phy0_burnin,
    output logic        lpddr_phy1_burnin,
    output logic [15:0] lpddr_atpg_se,
    output logic [1:0]  lpddr_scan_ctl,
    output logic        lpddr_scan_shift_cg,
    output logic        lpddr_scan_rstn,
    output logic [2:0]  lpddr_sms_dm,
    output logic [6:0]  lpddr_ring_bypass,
    output logic        lpddr_sfp_dft_mode,
    output logic        lpddr_tdrclk,
    output logic        lpddr_wrstn,
    output logic [1:0]  lpddr_cmd_tdr_capture_en,
    output logic [1:0]  lpddr_cmd_tdr_shift_en,
    output logic [1:0]  lpddr_cmd_tdr_update_en,
    output logic [1:0]  lpddr_rd_tdr_capture_en,
    output logic [1:0]  lpddr_rd_tdr_shift_en,
    output logic [1:0]  lpddr_rd_tdr_update_en,
    output logic [1:0]  lpddr_wsi,
    input  logic [1:0]  lpddr_cmd_tdr_tdo,
    input  logic [1:0]  lpddr_rd_tdr_tdo,
    // ---- CRG ---------------------------------------------------------
    output logic        dft_crg_test_clk_sel,
    output logic [2:0]  dft_crg_pll_byp,
    output logic [12:0] dft_crg_blk_clk_en,
    output logic [12:0] dft_crg_comp_clk_en,
    output logic [4:0]  dft_crg_lpddr_clk_en,
    output logic        dft_crg_rst_byp,
    output logic        dft_crg_rst_n_test,
    input  logic [2:0]  crg_pll_ready
);

  // =====================================================================
  // Elaboration check: the scan-mode lane table against its literals (C6).
  //
  // dft_part_map_pkg holds the DeMuxSel lane table (scan_mode_sel, lane_lo,
  // NCH) the router reads. g_map_check below compares it with the lanes of
  // the change file's mode table, written out here, and checks that no block
  // passes lane 19 and no two blocks share a lane in one mode, so that a
  // wrong entry is caught where it is cheapest -- at elaboration -- and not
  // in a pattern. The two sides are independent: literals here, table there.
  // (Before the change round of 12 Nov 2026 this checked the PART map against
  // Table 59, as 12.4 asked.)
  // =====================================================================
  // Elaboration guards for the parameter rules. Generate-region elaboration
  // system tasks, so a configuration that cannot work is refused by every
  // front end that elaborates it: a generate-if whose condition is false is
  // never elaborated, so a legal build never meets them.
  if (P_IDCODE[0] !== 1'b1) begin : g_leg03_idcode_bit0
    $fatal(1, "LEG-03: P_IDCODE[0] = 1 and P_SMS_IDCODE[0] = 1");
  end
  if (P_SMS_IDCODE[0] !== 1'b1) begin : g_leg03_sms_idcode_bit0
    $fatal(1, "LEG-03: P_IDCODE[0] = 1 and P_SMS_IDCODE[0] = 1");
  end
  if (P_IDCODE === P_SMS_IDCODE) begin : g_leg04_idcodes_differ
    $fatal(1, "LEG-04: P_IDCODE != P_SMS_IDCODE");
  end
  if (P_SMS_IR_LEN < 1) begin : g_leg05_sms_ir_len
    $fatal(1, "LEG-05: P_SMS_IR_LEN >= 1");
  end
  // LEG-01: the only two builds are the partial build and the hierarchical
  // build. The parameter is `int unsigned` rather than `bit` so that this
  // guard can do something: declared `bit`, an integrator's override of 2
  // truncated silently to 0 and built the partial design, and the rule could
  // never fire because the type had already thrown the value away. It belongs
  // here, in the generate region with LEG-03 to LEG-05, and not in the
  // procedural block below: a $fatal inside an `initial` runs at the first
  // simulated cycle, which is not where a build that cannot work should be
  // refused.
  if ((P_PARTITIONED != 0) && (P_PARTITIONED != 1)) begin : g_leg01_partitioned
    $fatal(1, "LEG-01: P_PARTITIONED in {0, 1}");
  end

`ifndef YOSYS
  // LEG-06 and LEG-07, the two rules the declaration marks RUNTIME. They are
  // statements in a procedural block and not generate-ifs because each one
  // sums or masks across the whole partition map: the comparison is over
  // values a loop builds, not over a parameter the front end already has, so
  // there is no constant expression for a generate-if to test. The rules that
  // can be tested at elaboration are above, in the generate region. The yosys
  // front end has no elaboration system tasks, and it only ever reads a
  // configuration the other three front ends have already elaborated, so
  // these are excluded from it rather than weakened for it.

  initial begin : g_legality
    int unsigned       chan_sum;
    logic [dft_part_map_pkg::NBLK-1:0]   part_mask;



    // LEG-06: twenty pin pairs, one channel per pair per direction, so the
    // channel sum of one INTEST scan mode (DeMuxSel 1-6, C6) can never
    // exceed twenty.
    for (int unsigned p = 1; p <= 6; p++) begin
      chan_sum  = 0;
      part_mask = dft_part_map_pkg::scan_mode_sel(p[2:0]);
      for (int unsigned b = 0; b < dft_part_map_pkg::NBLK; b++) begin
        if (part_mask[b]) chan_sum += dft_part_map_pkg::nch(b);
      end
      if (chan_sum > dft_part_map_pkg::NPIN)
        $fatal(1, "LEG-06: sum of NCH over one INTEST partition <= 20");
    end

    // LEG-07: a one-in one-out codec has no X tolerance, so every block
    // scanned through the router has at least two channels; LPDDR is a hard IP
    // and takes none.
    for (int unsigned b = 0; b < dft_part_map_pkg::NBLK; b++) begin
      if (dft_part_map_pkg::P0_MEMBER[b] && (dft_part_map_pkg::nch(b) < 2))
        $fatal(1, "LEG-07: NCH[b] >= 2 for every routed block, NCH[11] = 0");
    end
    if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_LPDDR) != 0)
      $fatal(1, "LEG-07: NCH[b] >= 2 for every routed block, NCH[11] = 0");

    // LEG-06 at the EXTEST partition: eleven wrapper pin pairs and three TOP
    // chains, so fourteen of the twenty pins carry a chain and six do not.
    if (dft_part_map_pkg::EXTEST_PINS_USED > dft_part_map_pkg::NPIN)
      $fatal(1, "LEG-06: the EXTEST partition uses more pins than exist");
    if (dft_part_map_pkg::EXTEST_PINS_USED != (dft_part_map_pkg::EXTEST_TOP_PIN0 + dft_part_map_pkg::NTOP))
      $fatal(1, "LEG-06: the EXTEST pin count and the TOP pin base disagree");
  end

  // =====================================================================
  // The scan-mode lane table against its literals (C6). The package holds
  // the lane table the router reads; these are the lanes of the change
  // file's mode table (part 4.1, ASSUMED K12 for modes 2-5), written out
  // independently, so a wrong lane or width is caught at elaboration and
  // not in a pattern.
  // =====================================================================
  if (P_PARTITIONED == 1) begin : g_map_check
    initial begin
      // mode 1: pcia 19:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd1, dft_part_map_pkg::BLK_PCIA) != 8)
        $fatal(1, "LEG-06: mode 1 pcia lane base is not 8");
      // mode 2: pcib 19:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd2, dft_part_map_pkg::BLK_PCIB) != 8)
        $fatal(1, "LEG-06: mode 2 pcib lane base is not 8");
      // mode 3: g2muc 19:12, axim 11:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd3, dft_part_map_pkg::BLK_G2MUC) != 12)
        $fatal(1, "LEG-06: mode 3 g2muc lane base is not 12");
      if (dft_part_map_pkg::lane_lo(3'd3, dft_part_map_pkg::BLK_AXIM) != 8)
        $fatal(1, "LEG-06: mode 3 axim lane base is not 8");
      // mode 4: l4ga 19:12, ahb 11:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd4, dft_part_map_pkg::BLK_L4GA) != 12)
        $fatal(1, "LEG-06: mode 4 l4ga lane base is not 12");
      if (dft_part_map_pkg::lane_lo(3'd4, dft_part_map_pkg::BLK_AHB) != 8)
        $fatal(1, "LEG-06: mode 4 ahb lane base is not 8");
      // mode 5: l4gb 19:12, apb 11:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd5, dft_part_map_pkg::BLK_L4GB) != 12)
        $fatal(1, "LEG-06: mode 5 l4gb lane base is not 12");
      if (dft_part_map_pkg::lane_lo(3'd5, dft_part_map_pkg::BLK_APB) != 8)
        $fatal(1, "LEG-06: mode 5 apb lane base is not 8");
      // mode 6: scc 19:14, hic 13:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd6, dft_part_map_pkg::BLK_SCC) != 14)
        $fatal(1, "LEG-06: mode 6 scc lane base is not 14");
      if (dft_part_map_pkg::lane_lo(3'd6, dft_part_map_pkg::BLK_HIC) != 8)
        $fatal(1, "LEG-06: mode 6 hic lane base is not 8");
      // every mode 1-6: axis on lanes 7:0, and every member inside the
      // twenty lanes
      for (int unsigned m = 1; m <= 6; m++) begin
        if (dft_part_map_pkg::lane_lo(m[2:0], dft_part_map_pkg::BLK_AXIS) != 0)
          $fatal(1, "LEG-06: axis lane base is not 0 in a mode 1-6");
        for (int unsigned b = 0; b < dft_part_map_pkg::NSCAN; b++) begin
          if ((((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b) & 13'd1) != 13'd0) &&
              (dft_part_map_pkg::lane_lo(m[2:0], b) + dft_part_map_pkg::nch(b)
               > dft_part_map_pkg::NPIN))
            $fatal(1, "LEG-06: a block's lanes pass lane 19");
          // no two blocks of one mode share a lane
          for (int unsigned b2 = b + 1; b2 < dft_part_map_pkg::NSCAN; b2++) begin
            if ((((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b) & 13'd1) != 13'd0) &&
                (((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b2) & 13'd1) != 13'd0) &&
                (dft_part_map_pkg::lane_lo(m[2:0], b) < dft_part_map_pkg::lane_lo(m[2:0], b2) + dft_part_map_pkg::nch(b2)) &&
                (dft_part_map_pkg::lane_lo(m[2:0], b2) < dft_part_map_pkg::lane_lo(m[2:0], b) + dft_part_map_pkg::nch(b)))
              $fatal(1, "LEG-06: two blocks share a lane in one scan mode");
          end
        end
      end
      // every block but axis is in exactly one mode 1-6, and axis is in all
      // six: the router feeds a block from the bus of its one mode only, so a
      // block in two modes or in none would be routed wrong (review, phase C)
      for (int unsigned b = 0; b < dft_part_map_pkg::NSCAN; b++) begin
        int unsigned n_in;
        n_in = 0;
        for (int unsigned m = 1; m <= 6; m++)
          if ((((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b) & 13'd1) != 13'd0)) n_in++;
        if ((b == dft_part_map_pkg::BLK_AXIS) ? (n_in != 6) : (n_in != 1))
          $fatal(1, "LEG-06: a block is not in exactly one scan mode (axis: all six)");
      end
    end
  end
`endif


  // =====================================================================
  // Internal nets of 6.6
  // =====================================================================
  logic        tm;
  logic        dftmax_i;
  logic        dftse_i;
  logic        rst_dtr_n;

  logic        sms_tms1;
  logic        sms_tdo1;
  logic        sms_tdo1_oe;
  logic        tap_tdi;
  // The stub TAP's own TDO enable. The TSEL1 = 11 chain's pad enable is the
  // SOC_DFT TAP's, never the stub's (6.6), so the top reads this one nowhere;
  // the shell's port exists because the generated SMS IP's does (14.6). The
  // net's name carries the `unused` mark the lint front ends recognise, which
  // leaves no true report standing and claims nothing false: an unnamed open
  // port and a plainly named net each raise one.
  logic        unused_sms_tap_tdo_oe;

  logic [3:0]  tap_state;
  logic [4:0]  ir;
  logic        capture_dr;
  logic        shift_dr;
  logic        update_dr;

  logic        dr_tdo_cfg;
  logic        dr_tdo_lpddr;
  logic        dr_tdo_sts;
  logic        dr_tdo_ddr;

  logic [31:0] dtr_cfg;
  logic [31:0] dtr_lpddr;
  logic        ddr_tdr_en;

  logic [12:0] sel;
  logic [12:0] active;
  logic        extest;
  logic        loopback;
  // The mode decoder's outputs before DFTTM is applied (change order item 1)
  logic [12:0] sel_dec;
  logic [12:0] active_dec;
  logic        extest_dec;
  logic        loopback_dec;

  // C0a: DTR_TM and the eleven two-bit test_mode codes
  logic [31:0] dtr_tm;
  logic        dr_tdo_tm;
  logic [21:0] blk_test_mode;   // 11 slots of TMW = 2
  logic [21:0] blk_test_mode_dec;   // before DFTTM is applied

  // The router's block-side view: block b's channels occupy NCH[b] bits of
  // the channel bus from CHAN_BASE[b], so that one router serves blocks of
  // different widths without a per-block port list.
  logic [dft_part_map_pkg::NCHAN-1:0] blk_test_si;
  logic [dft_part_map_pkg::NCHAN-1:0] blk_test_so;
  logic [10:0]  blk_wrap_si;   // one wrapper chain per block (C3/C11)
  logic [10:0]  blk_wrap_so;

  // C8: the delivered shell's packed g2muc port, now read by u_sms_ports
  logic [4:0]  g2muc_sms_in;
  logic        g2muc_sms_out;

  assign ddr_tdr_en = dtr_cfg[dft_part_map_pkg::CFG_DDR_TDR_EN];

  // CR-03, the source side: the eight levels DTR_STS captures, in the bit
  // order of Table 52. This is wiring, not logic: each bit is a pad level or a
  // PLL-ready level, none of them has a source clock domain, and each reaches
  // the TCK1 domain only through the synchroniser cell inside u_dtr.
  logic [7:0] sts_levels;
  assign sts_levels = {crg_pll_ready, PwrOk, TSEL1, dftmax_i, DFTTM};

  // =====================================================================
  // u_pad_if
  // =====================================================================
  dft_pad_if #(
      .P_DFTSO_HIZ_M0(P_DFTSO_HIZ_M0),
      .P_DFTMAX_COMP (P_DFTMAX_COMP)
  ) u_pad_if (
      .dfttm_pad (DFTTM),
      .dftmax_pad(DFTMAX),
      .dftse_pad (DFTSE),
      .pwrok_pad (PwrOk),
      .tck1      (TCK1),
      .tm        (tm),
      .dftmax_i  (dftmax_i),
      .dftse_i   (dftse_i),
      .dftso_oe  (DFTSO_OE),
      .rst_dtr_n (rst_dtr_n)
  );

  // =====================================================================
  // u_jtag1_rtr
  // =====================================================================
  dft_jtag1_rtr #(
      .P_OE_GATED(P_OE_GATED),
      .P_TM_OPEN (P_TM_OPEN)
  ) u_jtag1_rtr (
      .tm          (tm),
      .tsel1       (TSEL1),
      .tms1        (TMS1),
      .arc_tdo1    (arc_tdo1),
      .arc_tdo1_oe (arc_tdo1_oe),
      .pcia_tdo1   (pcia_tdo1),
      .pcia_tdo1_oe(pcia_tdo1_oe),
      .pcib_tdo1   (pcib_tdo1),
      .pcib_tdo1_oe(pcib_tdo1_oe),
      .sms_tdo1    (sms_tdo1),
      .sms_tdo1_oe (sms_tdo1_oe),
      .arc_tms1    (arc_tms1),
      .pcia_tms1   (pcia_tms1),
      .pcib_tms1   (pcib_tms1),
      .sms_tms1    (sms_tms1),
      .tdo1        (TDO1),
      .tdo1_oe     (TDO1_OE)
  );

  // =====================================================================
  // u_sms_srv -- the SMS shell, device 1 of the TSEL1 = 11 chain
  // =====================================================================
  dft_sms_srv #(
      .P_SMS_IR_LEN(P_SMS_IR_LEN),
      .P_SMS_IDCODE(P_SMS_IDCODE)
  ) u_sms_srv (
      .tck1         (TCK1),
      .trstn1       (TRSTN1),
      .tdi1         (TDI1),
      .sms_tms1     (sms_tms1),
      .dfttm        (tm),
      .dftse        (dftse_i),
      .scc_sms_out  (scc_sms_out),
      .hic_sms_out  (hic_sms_out),
      .g2muc_sms_out(g2muc_sms_out),
      .l4ga_sms_out (l4ga_sms_out),
      .l4gb_sms_out (l4gb_sms_out),
      .ahb_sms_out  (ahb_sms_out),
      .lpddr_sms_out(lpddr_sms_out),
      .pcia_sms_out (pcia_sms_out),
      .pcib_sms_out (pcib_sms_out),
      .scc_sms_in   (scc_sms_in),
      .hic_sms_in   (hic_sms_in),
      .g2muc_sms_in (g2muc_sms_in),
      .l4ga_sms_in  (l4ga_sms_in),
      .l4gb_sms_in  (l4gb_sms_in),
      .ahb_sms_in   (ahb_sms_in),
      .lpddr_sms_in (lpddr_sms_in),
      .pcia_sms_in  (pcia_sms_in),
      .pcib_sms_in  (pcib_sms_in),
      .tap_tdi       (tap_tdi),
      .sms_tap_tdo_oe(unused_sms_tap_tdo_oe)
  );

  // =====================================================================
  // u_sms_ports -- the port sheet's g2muc wrapper ports (C8; OPEN K15)
  // =====================================================================
  dft_sms_ports u_sms_ports (
      .g2muc_sms_in(g2muc_sms_in),
      .g2muc_sms_out(g2muc_sms_out),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI               (vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO               (vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR          (vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR         (vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR           (vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR         (vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair(vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI               (vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO               (vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR          (vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR         (vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR           (vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR         (vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR),
      .vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair(vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair)
  );

  // =====================================================================
  // u_tap -- device 2 of the chain
  // =====================================================================
  dft_tap #(
      .P_IR_LEN    (5),
      .P_DR_CLIENTS(1'b1),
      .P_IDCODE    (P_IDCODE)
  ) u_tap (
      .tck1        (TCK1),
      .trstn1      (TRSTN1),
      .tms         (sms_tms1),
      .tdi         (tap_tdi),
      .dr_tdo_cfg  (dr_tdo_cfg),
      .dr_tdo_lpddr(dr_tdo_lpddr),
      .dr_tdo_sts  (dr_tdo_sts),
      .dr_tdo_ddr  (dr_tdo_ddr),
      .dr_tdo_tm   (dr_tdo_tm),
      .tap_state   (tap_state),
      .ir          (ir),
      .capture_dr  (capture_dr),
      .shift_dr    (shift_dr),
      .update_dr   (update_dr),
      // The SOC_DFT TAP is the last device in the chain, so its TDO and its
      // enable are the chain's, and the JTAG router puts them on the pad.
      .tdo         (sms_tdo1),
      .tdo_oe      (sms_tdo1_oe)
  );

  // =====================================================================
  // u_dtr
  // =====================================================================
  dft_dtr #(
      .P_CFG_RST  (P_CFG_RST),
      .P_LPDDR_RST(P_LPDDR_RST),
      .P_RTL_REV  (P_RTL_REV)
  ) u_dtr (
      .tck1              (TCK1),
      .rst_dtr_n         (rst_dtr_n),
      .tdi               (tap_tdi),
      .tm                (tm),
      .ir                (ir),
      .capture_dr        (capture_dr),
      .shift_dr          (shift_dr),
      .update_dr         (update_dr),
      .sts_levels        (sts_levels),
      .dtr_cfg           (dtr_cfg),
      .dtr_lpddr         (dtr_lpddr),
      .lpddr_sms_dm      (lpddr_sms_dm),
      .lpddr_ring_bypass (lpddr_ring_bypass),
      .lpddr_sfp_dft_mode(lpddr_sfp_dft_mode),
      .dr_tdo_cfg        (dr_tdo_cfg),
      .dr_tdo_lpddr      (dr_tdo_lpddr),
      .dr_tdo_sts        (dr_tdo_sts)
  );

  // =====================================================================
  // u_dtr_tm -- DTR_TM (C0a)
  // =====================================================================
  dft_dtr_tm u_dtr_tm (
      .tck1      (TCK1),
      .rst_dtr_n (rst_dtr_n),
      .tdi       (tap_tdi),
      .tm        (tm),
      .ir        (ir),
      .capture_dr(capture_dr),
      .shift_dr  (shift_dr),
      .update_dr (update_dr),
      .dtr_tm    (dtr_tm),
      .dr_tdo_tm (dr_tdo_tm)
  );

  // =====================================================================
  // u_mode_dec
  // =====================================================================
  dft_mode_dec u_mode_dec (
      .tm                    (tm),
      .dftse_i               (dftse_i),
      .dftmax_i              (dftmax_i),
      .dtr_cfg               (dtr_cfg),
      .dtr_lpddr             (dtr_lpddr),
      .demux_sel             (DeMuxSel),
      .dtr_tm                (dtr_tm),
      .sel                   (sel_dec),
      .active                (active_dec),
      .extest                (extest_dec),
      .loopback              (loopback_dec),
      .blk_test_mode         (blk_test_mode_dec),
      .lpddr_atpg_mode       (lpddr_atpg_mode),
      .lpddr_compression_mode(lpddr_compression_mode),
      .lpddr_atpg_se         (lpddr_atpg_se),
      .lpddr_scan_shift_cg   (lpddr_scan_shift_cg),
      .lpddr_phy0_burnin     (lpddr_phy0_burnin),
      .lpddr_phy1_burnin     (lpddr_phy1_burnin),
      .lpddr_scan_ctl        (lpddr_scan_ctl)
  );

  // Change order item 1: DFTTM is applied here, not in the decoder. sel,
  // active, extest and loopback keep their names and values, so every reader
  // (the router, the clock control, the top shift enable) sees what it saw
  // before, and nothing moves while DFTTM is low (INV-05).
  assign sel      = {13{tm}} & sel_dec;
  assign active   = {13{tm}} & active_dec;
  assign extest   = tm & extest_dec;
  assign loopback = tm & loopback_dec;
  // The per-block test_mode codes are held at 00 while DFTTM is low
  // (INV-05, ASSUMED N13).
  assign blk_test_mode = tm ? blk_test_mode_dec : '0;

  // =====================================================================
  // u_scan_rtr -- instantiated only in the hierarchical build (P_PARTITIONED)
  //
  // In the partial build the router does not exist and the partition-dependent
  // outputs take the fixed values of 11.3: no channel is routed and every
  // DFTSO lane drives 0. The partial build is what the project ran before the
  // map was signed off (CONF-38), and it is still a legal build.
  // =====================================================================
  if (P_PARTITIONED == 1) begin : g_router
    dft_scan_rtr u_scan_rtr (
        .tm           (tm),
        .demux_sel    (DeMuxSel),
        .sel          (sel),
        .extest       (extest),
        .loopback     (loopback),
        .dftsi        (DFTSI),
        .blk_test_so  (blk_test_so),
        .blk_wrap_so  (blk_wrap_so),
        .top_test_so  (top_test_so),
        .lpddr_test_so(lpddr_test_so),
        .blk_test_si  (blk_test_si),
        .blk_wrap_si  (blk_wrap_si),
        .top_test_si  (top_test_si),
        .lpddr_test_si(lpddr_test_si),
        .dftso        (DFTSO)
    );
  end else begin : g_no_router
    always_comb begin
      blk_test_si   = '0;
      blk_wrap_si   = '0;
      top_test_si   = '0;
      lpddr_test_si = '0;
      DFTSO         = '0;
    end

    // Eight nets the router reads in the hierarchical build and nothing
    // reads here: the scan-in pad, the DeMuxSel scan-mode select (C4) and
    // its two decoded flags, the two scan-out bundles coming back from the
    // blocks, the top glue's scan-out and the LPDDR scan-out (C5, ASSUMED
    // K17). They are the design's whichever way it is
    // built, and in this build 11.3 is why they go nowhere -- no channel
    // is routed. One deliberate sink reads them, named for what it is,
    // the same device rtl/dft_sms_srv.sv uses for its contracted inputs
    // and rtl/dft_dtr_reg.sv for its capture-only elaboration.
    //
    // Without it the partial build reports seven unread nets, and the
    // parameter sweep is the only thing that builds it: the sweep would
    // have carried seven findings for a build that is behaving exactly as
    // the specification says it should.
    logic unused_no_router;
    assign unused_no_router = ^{1'b0, DFTSI, top_test_so, DeMuxSel, extest,
                                loopback, blk_test_so, blk_wrap_so,
                                lpddr_test_so};
  end

  // =====================================================================
  // u_crg_ctl
  // =====================================================================
  dft_crg_ctl u_crg_ctl (
      .tm                  (tm),
      .dftmax_i            (dftmax_i),
      .rstn_pad            (Rstn),
      .dtr_cfg             (dtr_cfg),
      .sel                 (sel),
      .active              (active),
      .dft_crg_test_clk_sel(dft_crg_test_clk_sel),
      .dft_crg_pll_byp     (dft_crg_pll_byp),
      .dft_crg_blk_clk_en  (dft_crg_blk_clk_en),
      .dft_crg_comp_clk_en (dft_crg_comp_clk_en),
      .dft_crg_lpddr_clk_en(dft_crg_lpddr_clk_en),
      .dft_crg_rst_byp     (dft_crg_rst_byp),
      .dft_crg_rst_n_test  (dft_crg_rst_n_test),
      .lpddr_scan_rstn     (lpddr_scan_rstn)
  );

  // =====================================================================
  // u_ddr_tdr
  // =====================================================================
  dft_ddr_tdr #(
      .P_TDR_EN_EDGE(P_TDR_EN_EDGE)
  ) u_ddr_tdr (
      .tck1                    (TCK1),
      .trstn1                  (TRSTN1),
      .tdi                     (tap_tdi),
      .tm                      (tm),
      .tap_state               (tap_state),
      .ir                      (ir),
      .ddr_tdr_en              (ddr_tdr_en),
      .lpddr_cmd_tdr_tdo       (lpddr_cmd_tdr_tdo),
      .lpddr_rd_tdr_tdo        (lpddr_rd_tdr_tdo),
      .dr_tdo_ddr              (dr_tdo_ddr),
      .lpddr_tdrclk            (lpddr_tdrclk),
      .lpddr_wrstn             (lpddr_wrstn),
      .lpddr_cmd_tdr_capture_en(lpddr_cmd_tdr_capture_en),
      .lpddr_cmd_tdr_shift_en  (lpddr_cmd_tdr_shift_en),
      .lpddr_cmd_tdr_update_en (lpddr_cmd_tdr_update_en),
      .lpddr_rd_tdr_capture_en (lpddr_rd_tdr_capture_en),
      .lpddr_rd_tdr_shift_en   (lpddr_rd_tdr_shift_en),
      .lpddr_rd_tdr_update_en  (lpddr_rd_tdr_update_en),
      .lpddr_wsi               (lpddr_wsi)
  );

  // =====================================================================
  // Block-side fan-out. Each block's own ports are slices of the router's
  // twenty-bit slots and bits of the decoder's per-block vectors, so the
  // per-block wiring is in one place and a block's width appears once.
  //
  // C1: each block's DFTTM and DFTSE are the pads, through the pad buffer
  // only (u_pad_if re-drives them and decides nothing); no decode, no gate.
  // The ten wrapper shift enables the change file does not remove follow
  // DFTSE too (ASSUMED N4: "same as DFTSE", connect sheet row 73).
  // =====================================================================
  // ACT-MODE-TOP-SE: the three top-level glue chains shift only in mode 7
  // (C1 moves it here from the decoder; ASSUMED K8).
  assign top_scan_shift_en = dftse_i & extest;

  // C2: DFTMAX decodes nothing; the pad is passed through for the chip
  // (ASSUMED K9; OPEN K9: where it goes). The raw pad level, not dftmax_i
  // (which u_pad_if compares with P_DFTMAX_COMP) and not through u_pad_if,
  // so that dft_pad_if stays byte-identical.
  assign dftmax_out = DFTMAX;

  assign scc_dfttm         = tm;
  assign scc_scan_shift_en = dftse_i;
  assign scc_wrap_shift_en = dftse_i;
  assign scc_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_SCC*2 +: 2];
  assign scc_test_si       = blk_test_si[0 +: 6];
  assign scc_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_SCC];

  assign hic_dfttm         = tm;
  assign hic_scan_shift_en = dftse_i;
  assign hic_wrap_shift_en = dftse_i;
  assign hic_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_HIC*2 +: 2];
  assign hic_test_si       = blk_test_si[6 +: 6];
  assign hic_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_HIC];

  assign g2muc_dfttm         = tm;
  assign g2muc_scan_shift_en = dftse_i;
  assign g2muc_wrap_shift_en = dftse_i;
  assign g2muc_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_G2MUC*2 +: 2];
  assign g2muc_test_si       = blk_test_si[12 +: 8];
  assign g2muc_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_G2MUC];

  assign l4ga_dfttm         = tm;
  assign l4ga_scan_shift_en = dftse_i;
  assign l4ga_wrap_shift_en = dftse_i;
  assign l4ga_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_L4GA*2 +: 2];
  assign l4ga_test_si       = blk_test_si[20 +: 8];
  assign l4ga_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_L4GA];

  assign l4gb_dfttm         = tm;
  assign l4gb_scan_shift_en = dftse_i;
  assign l4gb_wrap_shift_en = dftse_i;
  assign l4gb_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_L4GB*2 +: 2];
  assign l4gb_test_si       = blk_test_si[28 +: 8];
  assign l4gb_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_L4GB];

  assign pcia_dfttm         = tm;
  assign pcia_scan_shift_en = dftse_i;
  assign pcia_wrap_shift_en = dftse_i;
  assign pcia_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_PCIA*2 +: 2];
  assign pcia_test_si       = blk_test_si[36 +: 12];
  assign pcia_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_PCIA];

  assign pcib_dfttm         = tm;
  assign pcib_scan_shift_en = dftse_i;
  assign pcib_wrap_shift_en = dftse_i;
  assign pcib_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_PCIB*2 +: 2];
  assign pcib_test_si       = blk_test_si[48 +: 12];
  assign pcib_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_PCIB];

  assign ahb_dfttm         = tm;
  assign ahb_scan_shift_en = dftse_i;
  assign ahb_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_AHB*2 +: 2];
  assign ahb_test_si       = blk_test_si[60 +: 4];
  assign ahb_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_AHB];

  assign apb_dfttm         = tm;
  assign apb_scan_shift_en = dftse_i;
  assign apb_wrap_shift_en = dftse_i;
  assign apb_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_APB*2 +: 2];
  assign apb_test_si       = blk_test_si[64 +: 4];
  assign apb_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_APB];

  assign axis_dfttm         = tm;
  assign axis_scan_shift_en = dftse_i;
  assign axis_wrap_shift_en = dftse_i;
  assign axis_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_AXIS*2 +: 2];
  assign axis_test_si       = blk_test_si[68 +: 8];
  assign axis_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_AXIS];

  assign axim_dfttm         = tm;
  assign axim_scan_shift_en = dftse_i;
  assign axim_wrap_shift_en = dftse_i;
  assign axim_test_mode     = blk_test_mode[dft_part_map_pkg::BLK_AXIM*2 +: 2];
  assign axim_test_si       = blk_test_si[76 +: 4];
  assign axim_wrap_si       = blk_wrap_si[dft_part_map_pkg::BLK_AXIM];

  // The block-side returns, packed into the router's slots. A block's
  // channels occupy the low NCH[b] bits; the rest of the slot is 0 so that an
  // unmapped bit cannot carry a value into a lane.
  always_comb begin
    blk_test_so = '0;
    blk_wrap_so = '0;
    blk_test_so[0 +: 6]    = scc_test_so;
    blk_test_so[6 +: 6]    = hic_test_so;
    blk_test_so[12 +: 8]  = g2muc_test_so;
    blk_test_so[20 +: 8]   = l4ga_test_so;
    blk_test_so[28 +: 8]   = l4gb_test_so;
    blk_test_so[36 +: 12]  = pcia_test_so;
    blk_test_so[48 +: 12]  = pcib_test_so;
    blk_test_so[60 +: 4]    = ahb_test_so;
    blk_test_so[64 +: 4]    = apb_test_so;
    blk_test_so[68 +: 8]   = axis_test_so;
    blk_test_so[76 +: 4]   = axim_test_so;

    blk_wrap_so[dft_part_map_pkg::BLK_SCC]   = scc_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_HIC]   = hic_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_G2MUC] = g2muc_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_L4GA]  = l4ga_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_L4GB]  = l4gb_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_PCIA]  = pcia_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_PCIB]  = pcib_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_AHB]   = ahb_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_APB]   = apb_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_AXIS]  = axis_wrap_so;
    blk_wrap_so[dft_part_map_pkg::BLK_AXIM]  = axim_wrap_so;
  end

endmodule
