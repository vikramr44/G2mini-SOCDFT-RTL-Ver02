// Artifact identity: RTL
//
// dft_reset_sync -- reset synchroniser cell: asynchronous assert, release
// shifted in over two flops of the destination clock. Every reset crossing of
// soc_dft goes through an instance of this cell (CR-01, CR-02), so that no
// reset release is ever taken straight into a clock domain.
//
// Instances are named u_dft_reset_sync_<instance>_dont_touch.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   LPDDR TDR bridge: REQ-24, REQ-35
//   DTR reset release on TCK1: REQ-03, REQ-29
// end REQUIREMENTS

module dft_reset_sync (
    input  logic clk,     // destination clock
    input  logic arst_n,  // asynchronous active-low reset source
    output logic rst_n    // released on the second clk edge after arst_n = 1
);

  // Two named flops rather than a two-bit shift, so that the release path is
  // one flop to the next and can be read as such: the count from the
  // asynchronous release to rst_n is two destination-clock edges, and that
  // count is what the latency record states.
  logic stage0_q;
  logic stage1_q;

  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) begin
      stage0_q <= 1'b0;
      stage1_q <= 1'b0;
    end else begin
      stage0_q <= 1'b1;
      stage1_q <= stage0_q;
    end
  end

  assign rst_n = stage1_q;

endmodule
