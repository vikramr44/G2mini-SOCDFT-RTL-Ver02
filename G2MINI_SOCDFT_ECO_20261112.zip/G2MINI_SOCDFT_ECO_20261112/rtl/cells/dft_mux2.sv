// Artifact identity: RTL
//
// dft_mux2 -- behavioural 2:1 multiplexer, bound at synthesis to a library mux
// cell carried with dont_touch. Every test-control multiplexer of soc_dft is an
// instance of this cell, so that a mux a tester depends on cannot be optimised
// away or restructured (D89-D91, specification 24.11).
//
// Combinational. Instances are named u_dft_mux2_<instance>_dont_touch.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   test reset control: REQ-22
// end REQUIREMENTS

module dft_mux2 (
    input  logic d0,  // selected when s = 0
    input  logic d1,  // selected when s = 1
    input  logic s,
    output logic y
);

  assign y = s ? d1 : d0;

endmodule
