// Artifact identity: RTL
//
// dft_icg -- behavioural integrated clock gate, bound at synthesis to the
// library ICG cell carried with dont_touch. It gates TCK1 into TDRCLK.
//
// The library cell latches its enable while the clock is low, so the gated
// clock never shows a partial pulse, and the cell is what is built: this
// module carries dont_touch and is swapped for it.
//
// The model is a plain AND rather than a latch, which is sound HERE and not in
// general. The only instance in this design gates TCK1 with DTR_CFG.DDR_TDR_EN,
// and that bit comes from a shadow stage loaded at Update-DR on the FALLING
// edge of TCK1 -- that is, the enable can only move while the clock is low,
// which is exactly the window the library cell's latch exists to cover. A
// latch here would therefore model nothing this design can do, and it would
// put a level-sensitive element into the synthesised result of a block whose
// inventory says it has none.
//
// If a later instance ever gated a clock with an enable that can move while
// that clock is high, this model would have to become the latch again, and the
// cell inventory of the MKM would have to say so.
//
// Instances are named u_dft_icg_<instance>_dont_touch.

// REQUIREMENTS (derived from declarations/dispositions.json):
//   LPDDR TDR bridge: REQ-24, REQ-35
// end REQUIREMENTS

module dft_icg (
    input  logic clk,
    input  logic en,
    output logic gclk
);

  assign gclk = clk & en;

endmodule
