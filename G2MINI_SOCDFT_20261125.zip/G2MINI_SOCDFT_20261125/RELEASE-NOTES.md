# G2mini SOC_DFT, release of 25 Nov 2026

This release brings `soc_dft` in line with the architect workbook of 25 Nov 2026 (sheets "SOC DFT to Block level Connect", "Scan Test Modes", "JTAG1 Logic" and "DFT clock architecture") and with the architect's decisions of 25 Nov 2026 listed below. It replaces the release of 18 Nov 2026.

## What is in this folder

| Path | What it is |
|---|---|
| `rtl/` | The RTL. `rtl/soc_dft.f` is the compile file list, in compile order. |
| `constraints/soc_dft.sdc` | The block-level timing constraints. |
| `dv_dir/` | The directed self-checking bench (`tb_dir.sv`, written by `gen_tb_dir.py`), the port-list check, the coverage summary and the run scripts. |
| `RELEASE-NOTES.md` | This file. |
| `FILELIST.txt` | Every file in this release, with its size and SHA-256. |

The 18 Nov release also carried a second bench (`dv_eco/`), which compared the design against its earlier version. That bench belongs to the 18 Nov port list and is not carried forward; `dv_dir/` covers the whole design.

## Architect decisions

The architect made these decisions on 25 Nov 2026. The design follows them.

- The SMS and SOC_DFT TAP chain is usable while DFTTM is high: with TSEL1 = 11 it follows TMS1 at either DFTTM value.
- DTR_CFG, DTR_LPDDR and DTR_TM are writable and readable at any DFTTM value: a write loads at Update-DR and drives its outputs at once, in functional and in test mode.
- DTR_CFG.CLR clears DTR_CFG, DTR_LPDDR and DTR_TM to their reset values, at any DFTTM value.
- The DDR PHY TDR access works at any DFTTM value. The DDR0 and DDR1 CMD and RD capture, shift and update enables and `phy0_WSI` / `phy1_WSI` follow the TAP whenever DTR_CFG.DDR_TDR_EN is set and a DDRx instruction is loaded; with DDR_TDR_EN clear they stay 0.
- The LPDDR reset override acts in test only: `rst_n = DFTTM ? (RST_OVR ? RST_VAL : Rstn) : Rstn`.
- DTR_TM has instruction code 5'b01010.
- TRST1_n clears DTR_TM, DTR_CFG and DTR_LPDDR to their reset values, as PwrOk does.
- Any lane order within a scan mode is acceptable; ATPG reads it from the RTL.
- TDO1_OE is the selected target's own enable. This is accepted in place of the OR of all four enables that the sheet draws.
- The LPDDR TDRCLK is TCK1. The PHY TDR enables keep the PHY quiet outside a DDR TDR access: they are 0 unless DDR_TDR_EN is set and a DDRx instruction is loaded.
- The IDCODE values (SOC_DFT TAP 32'h0000_0001, SMS TAP 32'h0001_0001) are placeholders until the customer gives the real ones; they are the parameters `P_IDCODE` and `P_SMS_IDCODE` of `soc_dft`.
- The SMS server in this release is a stub: it has the SMS TAP (IDCODE and BYPASS) and drives every wrapper control 0. The generated SMS server comes in the next release.
- G2mini has no memory repair, so every `*_index_based_repair` output is tied 0.
- Sheet "SOC DFT to Block level Connect" row 127 names TRST1_n. It is the TRSTN1 net.
- The design's readings of the sheet text are correct:
  - row 52 is `TopG2mPcia_2_index_based_repair`;
  - TSEL1 is [1:0], as drawn;
  - rows 248-249 name the HIC block's port;
  - leading spaces in some names are not part of the name.
- These are kept as they are:
  - `dftmax_out` stays removed;
  - DTR_STS.PLL_RDY reads 0;
  - the DTR_CFG and DTR_LPDDR bits that drive nothing are kept and read back;
  - the ports `PwrOk`, `Rstn`, `DFTSO_OE` and `top_scan_shift_en` are kept.
- The three LPDDR clocks `atpg_DlyTestClk`, `atpg_RDQSClk` and `atpg_TxDllClk` stay out of `soc_dft` until the customer answers (see "Open item").

## Test rules

- **During scan keep TSEL1 != 11 (or TMS1 and TCK1 quiet), so that neither the DTRs nor the DDR PHY TDRs are accessed.** The DTRs and the PHY TDR access work at any DFTTM value, so a TAP walk during scan would rewrite the configuration the scan runs under, or pulse the PHY TDR enables.
- **Change TSEL1 only with the selected TAP in Run-Test/Idle or Test-Logic-Reset; do not use TRST1_n for this, because TRST1_n low also clears the DTRs.**
- **Keep TRST1_n high during scan, or the test-mode bits are cleared.** TRST1_n low clears DTR_TM (every block's test_mode and the pad loopback), DTR_CFG and DTR_LPDDR at once. The clear is released on the second rising TCK1 edge after both PwrOk and TRST1_n are high; write the DTRs after that.
- **DTR_STS** captures its live levels at any DFTTM value, so DTR_STS.DFTTM reads 1 in test.
- **Load DTR_TM with instruction 5'b01010.** 5'b01001 selects BYPASS. Update the BSDL and any pattern that loads 5'b01001.
- **A DTR_CFG.CLR write also clears DTR_TM**: every block's test_mode returns to 00 and the pad loopback turns off.

## Build parameters

Keep the defaults. P_TM_OPEN = 0, P_OE_GATED = 1 and P_PARTITIONED = 1 are the architect-agreed behaviour; other values are kept only as build options and are not verified.

## How to run the bench

You need:
- Verilator 5;
- Icarus Verilog 13 or later (Icarus Verilog 12 cannot evaluate the `chan_base` constant function);
- Python 3.

Run from this folder:
- **Windows (PowerShell):** `powershell -ExecutionPolicy Bypass -File dv_dir\run_dir.ps1 [-Jobs 4] [-Sheet <workbook.xlsx>]`
- **Linux / sh:** `sh dv_dir/run_dir.sh [<workbook.xlsx>]`

**What a run does:**
- Generates `dv_dir/tb_dir.sv` from `dv_dir/gen_tb_dir.py`.
- Runs it on Verilator (with line and toggle coverage) and on Icarus Verilog (4-state, so an unknown value shows up as X).
- Runs the port-list check `dv_dir/check_ports.py`. Give it the architect workbook to also compare the port list against the sheet; without the workbook that part is skipped and says so.

Everything a run writes goes to `dv_dir/run/`; on Windows the compiler's scratch goes to `tmp/` in this folder. dv_dir/run/ and tmp/ are build output and must not be checked in.

## Changes since the 18 Nov release

### Ports

`soc_dft` has 192 ports, 57 of them inputs; the appendix lists them all.

- **LPDDR control nets.** The LPDDR's `atpg_mode`, `atpg_se[9:0]`, `scan_shift_cg`, `compression_mode`, `TDRCLK` and `WRSTN` are the DFTTM, DFTSE, DFTMAX, TCK1 and TRSTN1 pad nets, joined at the chip top. These `soc_dft` outputs are removed:
  - `lpddr_atpg_mode`, `lpddr_atpg_se[15:0]`, `lpddr_scan_shift_cg`, `lpddr_compression_mode`
  - `lpddr_tdrclk`, `lpddr_wrstn`
- **LPDDR port names.** The LPDDR ports take the sheet's names:
  - `ddr_test_si/so[19:0]` replaces `lpddr_test_si/so`.
  - The twelve `phy0_/phy1_DdrPhyCsr*Tdr*En` enables, `phy0_WSI`, `phy1_WSI` and the four `*_Tdo` returns replace the packed `lpddr_*_tdr_*` and `lpddr_wsi` buses.
  - `sms_dm0..2`, `scan_ctl[1:0]`, `phy0_BurnIn`, `phy1_BurnIn`, `rst_n` and `scan_resetn` are new names.
  - The LPDDR SMS sub-server ports `vl_srv_u_sms_sub_server_snps_ddr_subsystem_*` (8 ports, including `ring_bypass[6:0]` and `sfp_dft_mode`) are new.
- **Clock control removed.** No sheet routes a clock or PLL control through SOC_DFT. These are removed:
  - the outputs `dft_crg_test_clk_sel`, `dft_crg_pll_byp`, `dft_crg_blk_clk_en`, `dft_crg_comp_clk_en`, `dft_crg_lpddr_clk_en`, `dft_crg_rst_byp` and `dft_crg_rst_n_test`;
  - the input `crg_pll_ready[2:0]`.
- **Other removals.** The three TOP scan chains (`top_test_si/so[2:0]`) and `dftmax_out` are removed.
- **Lane widths.**
  - `ahb_test_si/so` widen from 4 to 6 bits.
  - `l4ga_test_si/so` and `l4gb_test_si/so` narrow from 8 to 2 bits.
  - `pcia_test_si/so` and `pcib_test_si/so` stay at 12 bits.
- **test_mode names.** These follow the sheet: `pciea_test_mode`, `pcieb_test_mode`, `L4ga_test_mode` and `L4gb_test_mode` (18 Nov: `pcia_`, `pcib_`, `l4ga_`, `l4gb_test_mode`). `scc_test_mode`, `hic_test_mode` and `g2muc_test_mode` keep their 18 Nov names.
- **SMS ports.** The SMS memory wrappers have one port set per block instance, named as the sheet names them: 75 `vl_sms_u_1_sms_sram_proc_*` ports for Pcia_1/2, Pcib_1/2, Gucc_1/2, L4ga_1, L4gb_1, Scc_1, Hic_1 and Ahb_1. These replace the packed buses of 18 Nov (`<blk>_sms_in`, `<blk>_sms_out`).
- **JTAG1 and ARC ports.** The JTAG1 ports (`arc_tms1`, `pcia_tms1`, `pcib_tms1` and the six returns `arc/pcia/pcib_tdo1`, `_tdo1_oe`) and the SCC and HIC scan ports keep their 18 Nov names and widths.

### Function

- **JTAG1 TMS.** An unselected ARC, PCIA or PCIB TAP sees TMS = 1 at any DFTTM value (`P_TM_OPEN` default 0); on 18 Nov all three followed TMS1 while DFTTM was high. With TSEL1 = 11 the SMS and SOC_DFT TAPs follow TMS1 at either DFTTM value; on 18 Nov they were held in Test-Logic-Reset while DFTTM was high.
- **TDO return.** TDO1 and TDO1_OE take the selected target's return from the six `*_tdo1`, `*_tdo1_oe` inputs.
- **LPDDR reset override in test only.** DTR_CFG.RST_OVR substitutes RST_VAL on the LPDDR `rst_n` only while DFTTM is high; while DFTTM is low `rst_n` is the Rstn pad. `scan_resetn` (DFTTM ? `rst_n` : 1) is unchanged.
- **DTR_TM instruction code.** 5'b01010 (18 Nov: 5'b01001).
- **DTR reset.** TRST1_n low clears DTR_TM, DTR_CFG and DTR_LPDDR, as PwrOk low does. The AND of PwrOk and TRST1_n is a library mux cell (`u_pad_if/u_dft_mux2_dtr_arst_dont_touch`) in front of the DTR reset synchroniser. DTR_STS has no shadow and is unaffected.
- **DTR writes at any DFTTM value.** DTR_CFG, DTR_LPDDR and DTR_TM load at Update-DR at either DFTTM value; on 18 Nov a write with DFTTM high was not loaded.
- **DTR_CFG.CLR.** CLR clears DTR_TM as well as DTR_CFG and DTR_LPDDR, at either DFTTM value; on 18 Nov it left DTR_TM alone and acted only with DFTTM low.
- **DDR PHY TDR access at any DFTTM value.** The twelve PHY TDR enables and `phy0_WSI` / `phy1_WSI` follow the TAP whenever DTR_CFG.DDR_TDR_EN is set; on 18 Nov they were also held at 0 while DFTTM was high.
- **DTR_STS.** PLL_RDY (bits 6:4) reads 0, because no PLL-ready signal comes into SOC_DFT. The RTL revision (DTR_STS.RTL_REV) is 8'h06.
- **Unused fields.** DTR_CFG.PLL_BYP, BLK_CLK_EN and SE_GATE, and DTR_LPDDR bits 3:0 and 17, write and read back but drive nothing.
- **LPDDR TDR path.** SOC_DFT has no TDRCLK clock gate and no WRSTN synchroniser; the LPDDR takes TCK1 and TRSTN1 directly.
- **Scan modes.** The scan-mode table follows sheet "Scan Test Modes"; see the table below.
- **EXTEST router.** The router's EXTEST path is built in two processes, one per direction. The logic is unchanged; it no longer looks like a combinational loop to lint and simulation tools.
- **Parameter messages.** The parameter legality messages of the `$fatal` calls start with "illegal parameters:".
- **Package.** The unused partition functions `part_map_sel` and `pin_base` are removed from `dft_part_map_pkg`; nothing called them.
- **Files.** `rtl/cells/dft_icg.sv` is removed: nothing instantiated it.

### Constraints

- TCK1 is 50 ns (20 MHz) by default. There is no generated clock.
- For the 10 MHz DDR TDR mode, set `TCK1_PERIOD_NS` to 100 (`$TCK1_TDR_PERIOD_NS`) before reading `constraints/soc_dft.sdc`.
- `set_max_delay` covers the JTAG1 paths through SOC_DFT:
  - TMS1 to `arc/pcia/pcib_tms1`: a quarter TCK1 period;
  - the block TDO returns to TDO1 and TDO1_OE: a quarter TCK1 period;
  - DFTSE to `top_scan_shift_en`: half a TCK1 period.
- `set_dont_touch` is added for the new cell `u_pad_if/u_dft_mux2_dtr_arst_dont_touch`.
- `set_dont_touch` on the `u_soc_dft` instance moves to the chip-top SDC, where the instance exists.

### Bench

- The expected port, lane and test_mode tables are written from the 25 Nov sheet and the decisions above, with the sheet row for each.
- The bench starts with PwrOk, Rstn and TRSTN1 low.
- It runs on Icarus Verilog as well as Verilator, and both must agree.
- The port-list check takes the workbook as an argument.
- `run_dir.sh` runs both simulators.

## Scan modes and lanes

DeMuxSel selects the mode, and DFTTM must be high. "Lanes" are DFTSI/DFTSO pin pairs 19..0.

- The sheet gives the number of lanes per block; the lane positions are this design's, and ATPG reads them from the RTL.
- Lanes no block uses drive 0 on DFTSO.
- With DTR_TM bit 22 (loopback) set, DFTSO = DFTSI in every mode and no block is fed.

| Mode | Sheet ("Scan Test Modes" row) | Blocks and lanes | Unused lanes |
|---|---|---|---|
| 0 | LPDDR 20, Intest (row 4) | LPDDR `ddr_test_si/so[19:0]` on 19:0 | none |
| 1 | Pciea + Axis 12, 8 (row 5) | PCIA 19:8, Axis 7:0 | none |
| 2 | Pcieb + Axis 12, 8 (row 6) | PCIB 19:8, Axis 7:0 | none |
| 3 | Mcp + Axim + Axis 8, 4, 8 (row 7) | G2MUC 19:12, AXIM 11:8, Axis 7:0 | none |
| 4 | L4ga + Ahb + Axis 2, 6, 8 (row 8) | L4GA 15:14, AHB 13:8, Axis 7:0 | 19:16 |
| 5 | L4gb + Apb + Axis 2, 4, 8 (row 9) | L4GB 13:12, APB 11:8, Axis 7:0 | 19:14 |
| 6 | Scc + Hic + Axis 6, 6, 8 (row 10) | SCC 19:14, HIC 13:8, Axis 7:0 | none |
| 7 | all 11 blocks, 11, Extest (row 11) | one wrapper chain per block, lane = block index: SCC 0, HIC 1, G2MUC 2, L4GA 3, L4GB 4, PCIA 5, PCIB 6, AHB 7, APB 8, AXIS 9, AXIM 10 | 19:11 |

**Per-block test_mode (DTR_TM, instruction 5'b01010, sheet "Scan Test Modes" rows 17-31):**

| DTR_TM bits | Field |
|---|---|
| [1:0] | scc |
| [3:2] | hic |
| [5:4] | g2muc |
| [7:6] | l4ga |
| [9:8] | l4gb |
| [11:10] | pciea |
| [13:12] | pcieb |
| [15:14] | ahb |
| [17:16] | apb |
| [19:18] | axis |
| [21:20] | axim |
| [22] | pad loopback |
| [31:23] | reserved; reads 0 |

- Each block's two bits go out unchanged on its `*_test_mode` port while DFTTM is high, and read 00 while DFTTM is low.
- DTR_TM is written over JTAG1 at either DFTTM value. It is cleared by PwrOk low, TRST1_n low, or a DTR_CFG.CLR write.

## JTAG1

TSEL1[1:0] selects the target (sheet "JTAG1 Logic"):

| TSEL1 | Target |
|---|---|
| 00 | ARC daisy chain: GUCC, then SCC, then HIC |
| 01 | PCIA |
| 10 | PCIB |
| 11 | SMS, then the SOC_DFT TAP |

- **TMS.** The selected target's TMS follows TMS1. Each unselected one (`arc_tms1`, `pcia_tms1`, `pcib_tms1`, and the SMS and SOC_DFT chain) is held at 1, so its TAP stays in Test-Logic-Reset. This holds at either DFTTM value.
- **TDO1 and TDO1_OE.** These come from the selected target:
  - `arc_tdo1`/`arc_tdo1_oe`, the end of the GUCC to SCC to HIC chain, wired at the chip top;
  - `pcia_tdo1`/`_oe`;
  - `pcib_tdo1`/`_oe`;
  - the SOC_DFT TAP.

  The enable is the selected target's own; it equals the OR the sheet draws while the unselected TAPs are parked, which the TMS rule ensures.
- **Not soc_dft ports.** The sheet lists `gucc_tdo1` and `scc_tdo1` in its SOC_DFT column. They are the wires between the ARC blocks, at the chip top, and are not `soc_dft` ports.

## Tests and coverage

The run checks against the 25 Nov sheet, the architect decisions of 25 Nov 2026 and the block specification. Both simulators give the same result line for line:

| Run | Tests | Checks | Failed checks |
|---|---|---|---|
| Verilator 5.051 | 22 of 22 pass | 2267 | 0 |
| Icarus Verilog 14.0 (devel) | 22 of 22 pass | 2267 | 0 |
| Port-list check against the workbook | 1 of 1 pass | 661 | 0 |

Each test with its check count:

| Test | Checks |
|---|---|
| `t_power_on` | 141 |
| `t_modes_lanes` | 280 |
| `t_mode7_extest` | 40 |
| `t_unmapped_returns` | 8 |
| `t_dfttm_low_quiet` | 32 |
| `t_tap_reset_idcode_bypass` | 8 |
| `t_tap_pause_states` | 6 |
| `t_dtr_tm_bitmap` | 115 |
| `t_loopback` | 64 |
| `t_top_scan_shift_en` | 32 |
| `t_jtag1_tms_park` | 52 |
| `t_jtag1_tdo_return` | 13 |
| `t_ddr_tdr` | 283 |
| `t_lpddr_statics` | 50 |
| `t_dtr_cfg_clr_guard_pwrok` | 7 |
| `t_clr_clears_dtr_tm` | 38 |
| `t_dtr_sts` | 18 |
| `t_lpddr_resets` | 32 |
| `t_dtr_tm_ir_code` | 4 |
| `t_sms_tap_dfttm` | 41 |
| `t_trst_clears_dtrs` | 30 |
| `t_sms_ports_25nov` | 973 |

**Coverage.** Verilator, the files under `rtl/` only:

| Kind | Covered | Total | % |
|---|---|---|---|
| Line (statements + branches) | 379 | 400 | 94.75 |
| Toggle, raw | 5569 | 7432 | 74.93 |
| Toggle, constant-tied bits excluded | 5569 | 5569 | 100.00 |
| Expression | 365 | 420 | 86.90 |

**The constant-tied bits.** 1863 toggle points are tied to a constant in the RTL, so no test can toggle them. Each group is named, with its reason, in `dv_dir/cov_summary.py`, and `coverage.txt` lists them under `CONST`. A named point that does toggle is reported as `RULE_WRONG`; there are none.

**Lint.** Verilator `-Wall` reports no warning.

## Open item

The three LPDDR clocks `atpg_DlyTestClk`, `atpg_RDQSClk` and `atpg_TxDllClk` (sheet "Need clarity from LPDDR team") have no `soc_dft` port. They stay out until the customer answers.

### Port names that carry the vendor abbreviation

The sheet itself names the LPDDR SMS sub-server ports (rows 158-165). This release keeps those names:
- `vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSI`, `_WSO`, `_SelectWIR`, `_ShiftWR`, `_CaptureWR`, `_UpdateWR`, `_ring_bypass[6:0]` and `_sfp_dft_mode`.

## Appendix: soc_dft port list

All 192 ports of `rtl/soc_dft.sv` in declaration order, with the row of sheet "SOC DFT to Block level Connect" that names each one (or the other sheet that does).

| # | Port | Dir | Width | Sheet "SOC DFT to Block level Connect" row |
|---|---|---|---|---|
| 1 | `DFTTM` | input | 1 | 156 |
| 2 | `DFTMAX` | input | 1 | 153 |
| 3 | `DFTSE` | input | 1 | 157, 186 |
| 4 | `DFTSI[19:0]` | input | 20 | sheet "SOC_DFT r0.62" drawing |
| 5 | `DFTSO[19:0]` | output | 20 | sheet "SOC_DFT r0.62" drawing |
| 6 | `DFTSO_OE` | output | 1 | none; kept by architect decision 25 Nov 2026 |
| 7 | `DeMuxSel[2:0]` | input | 3 | sheet "SOC_DFT r0.62" rows 119-123 |
| 8 | `TSEL1[1:0]` | input | 2 | sheet "JTAG1 Logic" |
| 9 | `TMS1` | input | 1 | sheet "JTAG1 Logic" |
| 10 | `TDI1` | input | 1 | 56, 85, 224 |
| 11 | `TDO1` | output | 1 | sheet "JTAG1 Logic" |
| 12 | `TDO1_OE` | output | 1 | sheet "JTAG1 Logic" |
| 13 | `TCK1` | input | 1 | 53, 82, 103, 121, 145, 166, 221, 244, 266 |
| 14 | `TRSTN1` | input | 1 | 55, 84, 104, 123, 146, 167, 223, 246, 267 |
| 15 | `PwrOk` | input | 1 | none; kept by architect decision 25 Nov 2026 |
| 16 | `Rstn` | input | 1 | none; kept by architect decision 25 Nov 2026 |
| 17 | `pcia_tms1` | output | 1 | 54 |
| 18 | `pcib_tms1` | output | 1 | 222 |
| 19 | `arc_tms1` | output | 1 | 83, 122, 245 |
| 20 | `arc_tdo1` | input | 1 | 248 |
| 21 | `arc_tdo1_oe` | input | 1 | 249 |
| 22 | `pcia_tdo1` | input | 1 | 57 |
| 23 | `pcia_tdo1_oe` | input | 1 | 58 |
| 24 | `pcib_tdo1` | input | 1 | 225 |
| 25 | `pcib_tdo1_oe` | input | 1 | 226 |
| 26 | `axis_test_si[7:0]` | output | 8 | 5 |
| 27 | `axis_test_so[7:0]` | input | 8 | 6 |
| 28 | `axis_test_mode[1:0]` | output | 2 | 9 |
| 29 | `axis_wrap_si` | output | 1 | 10 |
| 30 | `axis_wrap_so` | input | 1 | 11 |
| 31 | `axim_test_si[3:0]` | output | 4 | 14 |
| 32 | `axim_test_so[3:0]` | input | 4 | 15 |
| 33 | `axim_test_mode[1:0]` | output | 2 | 18 |
| 34 | `axim_wrap_si` | output | 1 | 19 |
| 35 | `axim_wrap_so` | input | 1 | 20 |
| 36 | `apb_test_si[3:0]` | output | 4 | 23 |
| 37 | `apb_test_so[3:0]` | input | 4 | 24 |
| 38 | `apb_test_mode[1:0]` | output | 2 | 27 |
| 39 | `apb_wrap_si` | output | 1 | 28 |
| 40 | `apb_wrap_so` | input | 1 | 29 |
| 41 | `pcia_test_si[11:0]` | output | 12 | 32 |
| 42 | `pcia_test_so[11:0]` | input | 12 | 33 |
| 43 | `pcib_test_si[11:0]` | output | 12 | 200 |
| 44 | `pcib_test_so[11:0]` | input | 12 | 201 |
| 45 | `pciea_test_mode[1:0]` | output | 2 | 36 |
| 46 | `pcia_wrap_si` | output | 1 | 37 |
| 47 | `pcia_wrap_so` | input | 1 | 38 |
| 48 | `pcieb_test_mode[1:0]` | output | 2 | 204 |
| 49 | `pcib_wrap_si` | output | 1 | 205 |
| 50 | `pcib_wrap_so` | input | 1 | 206 |
| 51 | `g2muc_test_si[7:0]` | output | 8 | 61 |
| 52 | `g2muc_test_so[7:0]` | input | 8 | 62 |
| 53 | `g2muc_test_mode[1:0]` | output | 2 | 65 |
| 54 | `g2muc_wrap_si` | output | 1 | 66 |
| 55 | `g2muc_wrap_so` | input | 1 | 67 |
| 56 | `l4ga_test_si[1:0]` | output | 2 | 90 |
| 57 | `l4ga_test_so[1:0]` | input | 2 | 91 |
| 58 | `L4ga_test_mode[1:0]` | output | 2 | 94 |
| 59 | `l4ga_wrap_si` | output | 1 | 95 |
| 60 | `l4ga_wrap_so` | input | 1 | 96 |
| 61 | `l4gb_test_si[1:0]` | output | 2 | 253 |
| 62 | `l4gb_test_so[1:0]` | input | 2 | 254 |
| 63 | `L4gb_test_mode[1:0]` | output | 2 | 257 |
| 64 | `l4gb_wrap_si` | output | 1 | 258 |
| 65 | `l4gb_wrap_so` | input | 1 | 259 |
| 66 | `scc_test_si[5:0]` | output | 6 | 107 |
| 67 | `scc_test_so[5:0]` | input | 6 | 108 |
| 68 | `scc_test_mode[1:0]` | output | 2 | 111 |
| 69 | `scc_wrap_si` | output | 1 | 112 |
| 70 | `scc_wrap_so` | input | 1 | 113 |
| 71 | `hic_test_si[5:0]` | output | 6 | 230 |
| 72 | `hic_test_so[5:0]` | input | 6 | 231 |
| 73 | `hic_test_mode[1:0]` | output | 2 | 234 |
| 74 | `hic_wrap_si` | output | 1 | 235 |
| 75 | `hic_wrap_so` | input | 1 | 236 |
| 76 | `ahb_test_si[5:0]` | output | 6 | 131 |
| 77 | `ahb_test_so[5:0]` | input | 6 | 132 |
| 78 | `ahb_test_mode[1:0]` | output | 2 | 135 |
| 79 | `ahb_wrap_si` | output | 1 | 136 |
| 80 | `ahb_wrap_so` | input | 1 | 137 |
| 81 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSI` | output | 1 | 39 |
| 82 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSO` | input | 1 | 40 |
| 83 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_SelectWIR` | output | 1 | 41 |
| 84 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_ShiftWR` | output | 1 | 42 |
| 85 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_CaptureWR` | output | 1 | 43 |
| 86 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_UpdateWR` | output | 1 | 44 |
| 87 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_index_based_repair` | output | 1 | 45 |
| 88 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSI` | output | 1 | 46 |
| 89 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSO` | input | 1 | 47 |
| 90 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_SelectWIR` | output | 1 | 48 |
| 91 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_ShiftWR` | output | 1 | 49 |
| 92 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_CaptureWR` | output | 1 | 50 |
| 93 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_UpdateWR` | output | 1 | 51 |
| 94 | `vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_index_based_repair` | output | 1 | 52 |
| 95 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSI` | output | 1 | 207 |
| 96 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSO` | input | 1 | 208 |
| 97 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_SelectWIR` | output | 1 | 209 |
| 98 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_ShiftWR` | output | 1 | 210 |
| 99 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_CaptureWR` | output | 1 | 211 |
| 100 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_UpdateWR` | output | 1 | 212 |
| 101 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_index_based_repair` | output | 1 | 213 |
| 102 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSI` | output | 1 | 214 |
| 103 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSO` | input | 1 | 215 |
| 104 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_SelectWIR` | output | 1 | 216 |
| 105 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_ShiftWR` | output | 1 | 217 |
| 106 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_CaptureWR` | output | 1 | 218 |
| 107 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_UpdateWR` | output | 1 | 219 |
| 108 | `vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_index_based_repair` | output | 1 | 220 |
| 109 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI` | output | 1 | 68 |
| 110 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO` | input | 1 | 69 |
| 111 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR` | output | 1 | 70 |
| 112 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR` | output | 1 | 71 |
| 113 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR` | output | 1 | 72 |
| 114 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR` | output | 1 | 73 |
| 115 | `vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair` | output | 1 | 74 |
| 116 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI` | output | 1 | 75 |
| 117 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO` | input | 1 | 76 |
| 118 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR` | output | 1 | 77 |
| 119 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR` | output | 1 | 78 |
| 120 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR` | output | 1 | 79 |
| 121 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR` | output | 1 | 80 |
| 122 | `vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair` | output | 1 | 81 |
| 123 | `vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSI` | output | 1 | 97 |
| 124 | `vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSO` | input | 1 | 98 |
| 125 | `vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_SelectWIR` | output | 1 | 99 |
| 126 | `vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_ShiftWR` | output | 1 | 100 |
| 127 | `vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_CaptureWR` | output | 1 | 101 |
| 128 | `vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_UpdateWR` | output | 1 | 102 |
| 129 | `vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSI` | output | 1 | 260 |
| 130 | `vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSO` | input | 1 | 261 |
| 131 | `vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_SelectWIR` | output | 1 | 262 |
| 132 | `vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_ShiftWR` | output | 1 | 263 |
| 133 | `vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_CaptureWR` | output | 1 | 264 |
| 134 | `vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_UpdateWR` | output | 1 | 265 |
| 135 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSI` | output | 1 | 114 |
| 136 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSO` | input | 1 | 115 |
| 137 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_UpdateWR` | output | 1 | 116 |
| 138 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_SelectWIR` | output | 1 | 117 |
| 139 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_ShiftWR` | output | 1 | 118 |
| 140 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_CaptureWR` | output | 1 | 119 |
| 141 | `vl_sms_u_1_sms_sram_proc_TopG2mScc_1_index_based_repair` | output | 1 | 120 |
| 142 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSI` | output | 1 | 237 |
| 143 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSO` | input | 1 | 238 |
| 144 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_UpdateWR` | output | 1 | 239 |
| 145 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_SelectWIR` | output | 1 | 240 |
| 146 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_ShiftWR` | output | 1 | 241 |
| 147 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_CaptureWR` | output | 1 | 242 |
| 148 | `vl_sms_u_1_sms_sram_proc_TopG2mHic_1_index_based_repair` | output | 1 | 243 |
| 149 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSI` | output | 1 | 138 |
| 150 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSO` | input | 1 | 139 |
| 151 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_UpdateWR` | output | 1 | 140 |
| 152 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_SelectWIR` | output | 1 | 141 |
| 153 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_ShiftWR` | output | 1 | 142 |
| 154 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_CaptureWR` | output | 1 | 143 |
| 155 | `vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_index_based_repair` | output | 1 | 144 |
| 156 | `top_scan_shift_en` | output | 1 | none; kept by architect decision 25 Nov 2026 |
| 157 | `sms_dm0` | output | 1 | 150 |
| 158 | `sms_dm1` | output | 1 | 151 |
| 159 | `sms_dm2` | output | 1 | 152 |
| 160 | `rst_n` | output | 1 | 154 |
| 161 | `scan_resetn` | output | 1 | 155 |
| 162 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSI` | output | 1 | 158 |
| 163 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_SelectWIR` | output | 1 | 159 |
| 164 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_CaptureWR` | output | 1 | 160 |
| 165 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_ShiftWR` | output | 1 | 161 |
| 166 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_UpdateWR` | output | 1 | 162 |
| 167 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSO` | input | 1 | 163 |
| 168 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_ring_bypass[6:0]` | output | 7 | 164 |
| 169 | `vl_srv_u_sms_sub_server_snps_ddr_subsystem_sfp_dft_mode` | output | 1 | 165 |
| 170 | `phy0_DdrPhyCsrCmdTdrCaptureEn` | output | 1 | 168 |
| 171 | `phy0_DdrPhyCsrCmdTdrShiftEn` | output | 1 | 169 |
| 172 | `phy0_DdrPhyCsrCmdTdrUpdateEn` | output | 1 | 170 |
| 173 | `phy0_DdrPhyCsrRdDataTdrCaptureEn` | output | 1 | 171 |
| 174 | `phy0_DdrPhyCsrRdDataTdrShiftEn` | output | 1 | 172 |
| 175 | `phy0_DdrPhyCsrRdDataTdrUpdateEn` | output | 1 | 173 |
| 176 | `phy0_WSI` | output | 1 | 174 |
| 177 | `phy0_DdrPhyCsrCmdTdr_Tdo` | input | 1 | 175 |
| 178 | `phy0_DdrPhyCsrRdDataTdr_Tdo` | input | 1 | 176 |
| 179 | `scan_ctl[1:0]` | output | 2 | 177 |
| 180 | `phy0_BurnIn` | output | 1 | 178 |
| 181 | `ddr_test_si[19:0]` | output | 20 | 179 |
| 182 | `ddr_test_so[19:0]` | input | 20 | 180 |
| 183 | `phy1_DdrPhyCsrCmdTdrCaptureEn` | output | 1 | 187 |
| 184 | `phy1_DdrPhyCsrCmdTdrShiftEn` | output | 1 | 188 |
| 185 | `phy1_DdrPhyCsrCmdTdrUpdateEn` | output | 1 | 189 |
| 186 | `phy1_DdrPhyCsrRdDataTdrCaptureEn` | output | 1 | 190 |
| 187 | `phy1_DdrPhyCsrRdDataTdrShiftEn` | output | 1 | 191 |
| 188 | `phy1_DdrPhyCsrRdDataTdrUpdateEn` | output | 1 | 192 |
| 189 | `phy1_WSI` | output | 1 | 193 |
| 190 | `phy1_DdrPhyCsrCmdTdr_Tdo` | input | 1 | 194 |
| 191 | `phy1_DdrPhyCsrRdDataTdr_Tdo` | input | 1 | 195 |
| 192 | `phy1_BurnIn` | output | 1 | 196 |
