// dft_pad_if -- pad-side buffering, the one DFTSO output-enable net, and the
// PwrOk / TRSTN1 reset for the DTR shadow stages.
//
// Crossing: PwrOk and TRSTN1 into TCK1 through dft_reset_sync.

module dft_pad_if #(
    parameter bit P_DFTSO_HIZ_M0 = 1'b1,
    parameter bit P_DFTMAX_COMP  = 1'b1
) (
    // pads
    input  logic dfttm_pad,
    input  logic dftmax_pad,
    input  logic dftse_pad,
    input  logic pwrok_pad,
    input  logic trstn1,
    input  logic tck1,
    // buffered mode levels
    output logic tm,
    output logic dftmax_i,
    output logic dftse_i,
    // DFTSO output enable, one net for all twenty pads
    output logic dftso_oe,
    // the DTR reset, released on TCK1
    output logic rst_dtr_n
);

  // The three buffered levels. These are re-drives, not decisions: every
  // consumer inside soc_dft takes its mode from here and never from the pad,
  // so that one buffer carries the whole test session.
  assign tm       = dfttm_pad;
  assign dftse_i  = dftse_pad;
  assign dftmax_i = (dftmax_pad == P_DFTMAX_COMP);

  // The DFTSO output enable. With P_DFTSO_HIZ_M0 = 1 the twenty DFTSO pads
  // are Hi-Z in functional mode and driven in test; with 0 they are always
  // driven and the data is 0 in functional mode (the scan router holds the
  // data side of that).
  assign dftso_oe = P_DFTSO_HIZ_M0 ? tm : 1'b1;

  // PwrOk or TRSTN1 low asserts the DTR reset asynchronously (TRSTN1 since
  // the architect decision of 25 Nov 2026), and it is released on the second
  // rising TCK1 after both are high. The AND of the two is a library mux
  // cell (d0 = 0, d1 = TRSTN1, select PwrOk), like every other reset select.
  logic dtr_arst_n;

  dft_mux2 u_dft_mux2_dtr_arst_dont_touch (
      .d0(1'b0),
      .d1(trstn1),
      .s (pwrok_pad),
      .y (dtr_arst_n)
  );

  dft_reset_sync u_dft_reset_sync_rst_dtr_dont_touch (
      .clk   (tck1),
      .arst_n(dtr_arst_n),
      .rst_n (rst_dtr_n)
  );

endmodule
