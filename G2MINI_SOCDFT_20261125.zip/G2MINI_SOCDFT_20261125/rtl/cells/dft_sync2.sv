// dft_sync2 -- two-flop data synchroniser cell. This is the only path by which
// a pad level reaches the TCK1 domain: the eight
// levels DTR_STS captures are sampled twice before they reach a capture value.
//
// One instance carries W bits, each with its own pair of flops; the cell does
// not synchronise a bus as a word, and nothing in soc_dft requires it to,
// because every captured level is independent.
//
// Instances are named u_dft_sync2_<instance>_dont_touch.
//
// The cell keeps an rst_n port that its one instance in this design ties
// high, and the port stays for a reason rather than by neglect. A data
// synchroniser on an observation path must not have a reset: resetting it
// makes a reader see zero where the pin carries something else, which is a
// falsifier and not a safety measure, and 18.4 says so twice -- "2-flop
// synchroniser on TCK1, no reset" for exactly these levels, and "every
// other reset crossing is an error". So the one instance ties rst_n high.
//
// The port is not removed because the cell is a technology cell
// and its interface is the one the standard cell library offers, not one
// this design gets to shorten; a synchroniser whose release must be
// sequenced -- which this one's is not -- needs it. What a reader needs to
// know is which kind this instance is, and the instance says so at its
// connection in rtl/dft_dtr.sv.

module dft_sync2 #(
    parameter int unsigned W = 1
) (
    input  logic         clk,
    input  logic         rst_n,
    input  logic [W-1:0] d,
    output logic [W-1:0] q
);

  logic [W-1:0] stage0_q;
  logic [W-1:0] stage1_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stage0_q <= '0;
      stage1_q <= '0;
    end else begin
      stage0_q <= d;
      stage1_q <= stage0_q;
    end
  end

  assign q = stage1_q;

endmodule
