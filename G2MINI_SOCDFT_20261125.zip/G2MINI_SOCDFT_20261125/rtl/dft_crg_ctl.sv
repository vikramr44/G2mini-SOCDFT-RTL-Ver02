// dft_crg_ctl -- the test reset control of SOC_DFT: the test reset Rst_n_test
// and the LPDDR scan reset.
//
// This module holds no clock control: sheet "DFT clock architecture" draws
// the PLL bypass muxes selected by the PLLgk, PLLuk and PLLdk pads and every
// block clock straight from them, with no SOC_DFT control, and sheet "SOC DFT
// to Block level Connect" lists no dft_crg_* port; soc_dft holds no clock mux
// or PLL logic. DTR_CFG bits 5 and 20:8 (PLL_BYP, BLK_CLK_EN) read back and
// drive nothing.
//
// It holds the reset path: two library mux cells carried with dont_touch
// (24.11). Rst_n_test is the LPDDR rst_n (sheet row 154) and the LPDDR scan
// reset is its scan_resetn (sheet row 155).
//

module dft_crg_ctl (
    input  logic        tm,
    input  logic        rstn_pad,
    input  logic [31:0] dtr_cfg,
    output logic        dft_crg_rst_n_test,
    output logic        lpddr_scan_rstn
);
  logic rst_ovr;
  logic rst_val;

  // The override acts in test only (architect decision of 25 Nov 2026):
  // rst_n = DFTTM ? (RST_OVR ? RST_VAL : Rstn) : Rstn.
  assign rst_ovr = tm & dtr_cfg[dft_part_map_pkg::CFG_RST_OVR];
  assign rst_val = dtr_cfg[dft_part_map_pkg::CFG_RST_VAL];

  // DTR_CFG.PLL_BYP and DTR_CFG.BLK_CLK_EN read back and drive nothing (no
  // clock control in soc_dft); one deliberate sink.
  logic unused_cfg_clock_fields;
  assign unused_cfg_clock_fields = ^{1'b0, dtr_cfg[dft_part_map_pkg::CFG_PLL_BYP],
      dtr_cfg[dft_part_map_pkg::CFG_BLK_CLK_EN_HI:dft_part_map_pkg::CFG_BLK_CLK_EN_LO]};

  // ---------------------------------------------------------------------
  // The test reset is the Rstn pad unless, in test,
  // DTR_CFG.RST_OVR substitutes RST_VAL. The select goes through a library mux
  // cell: this is the reset a whole scan session runs under, and a tester must
  // be able to point at the gate that chose it.
  // ---------------------------------------------------------------------
  dft_mux2 u_dft_mux2_rst_dont_touch (
      .d0(rstn_pad),
      .d1(rst_val),
      .s (rst_ovr),
      .y (dft_crg_rst_n_test)
  );

  // the LPDDR scan reset is the test reset in test and 1
  // otherwise, so the PHY is never held in reset in functional mode. It is the
  // second select on the reset path a session depends on, so it is the second
  // library mux cell.
  dft_mux2 u_dft_mux2_scan_rstn_dont_touch (
      .d0(1'b1),
      .d1(dft_crg_rst_n_test),
      .s (tm),
      .y (lpddr_scan_rstn)
  );

endmodule
