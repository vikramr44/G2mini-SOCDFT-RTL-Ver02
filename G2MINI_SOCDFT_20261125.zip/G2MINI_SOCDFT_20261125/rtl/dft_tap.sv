// dft_tap -- the IEEE 1149.1 TAP of SOC_DFT: the sixteen-state FSM, the
// instruction register, IDCODE, BYPASS, the data-register multiplexer and the
// TDO retiming. It is device 2 of the TSEL1 = 11 chain.
//
// The same module is instantiated as the SMS TAP stub with P_DR_CLIENTS = 0,
// which leaves only IDCODE and BYPASS (specification 15.2).
//
// Invariants: (tap_state is always one of the sixteen codes of 9.3).

module dft_tap #(
    parameter int unsigned   P_IR_LEN    = 5,
    parameter bit            P_DR_CLIENTS = 1'b1,
    parameter logic [31:0]   P_IDCODE    = 32'h0000_0001
) (
    input  logic                  tck1,
    input  logic                  trstn1,
    input  logic                  tms,
    input  logic                  tdi,
    // data-register returns, read only when P_DR_CLIENTS = 1
    input  logic                  dr_tdo_cfg,
    input  logic                  dr_tdo_lpddr,
    input  logic                  dr_tdo_sts,
    input  logic                  dr_tdo_ddr,
    input  logic                  dr_tdo_tm,   // DTR_TM
    // state and instruction, for the data registers and the TDR bridge
    output logic [3:0]            tap_state,
    output logic [P_IR_LEN-1:0]   ir,
    output logic                  capture_dr,
    output logic                  shift_dr,
    output logic                  update_dr,
    // pad side
    output logic                  tdo,
    output logic                  tdo_oe
);
  // the DTR and DDRx instruction codes of Table 46 are five bits
  // wide, so an instance that decodes them needs a five-bit IR. The stub
  // instance sets P_DR_CLIENTS = 0 and is free to be shorter.
  // An instance built with a short instruction register and the
  // data-register clients enabled cannot decode the five-bit codes of
  // Table 46. A generate-region task, so the build is refused.
  if (P_DR_CLIENTS && (P_IR_LEN != 5)) begin : g_leg02_ir_len
    $fatal(1, "illegal parameters: P_IR_LEN = 5 whenever P_DR_CLIENTS = 1");
  end

  // The IR length is at least 1, checked here at the site that uses the
  // length: an instruction register of no
  // bits cannot hold BYPASS, so neither instance of this module can be built
  // with one. The rule is stated at the top as well, against the parameter the
  // integrator sets; this is the one the shift register itself depends on.
  if (P_IR_LEN < 1) begin : g_leg05_ir_len_nonzero
    $fatal(1, "illegal parameters: P_SMS_IR_LEN >= 1");
  end

  // 9.4: an instance is no wider than the instruction codes it
  // decodes. Every code in dft_part_map_pkg is IRW bits, and the decode below
  // reads each one as `CODE[P_IR_LEN-1:0]`, so an instance built wider than
  // IRW slices past the end of every constant: the out-of-range bits are x,
  // each comparison is unknown rather than false, and IDCODE becomes
  // undecodable. The all-ones BYPASS code goes the same way, which is what
  // 9.4 asks about - but BYPASS survives it, because the decode reaches
  // BYPASS by default rather than by matching the code, and IDCODE does not.
  //
  // A check written as `IR_BYPASS[P_IR_LEN-1:0] != all ones` could never
  // fire: at P_IR_LEN <= IRW the slice of 5'b11111 is all ones and the
  // comparison is false, and at P_IR_LEN > IRW it is x and the `if` does not
  // fire either. So the rule states the relation the design depends on, and
  // an eight-bit instance is illegal.
  //
  // It is a generate-if, not a statement in an `initial`: it is an
  // elaboration rule and it compares two constants.
  if (P_IR_LEN > dft_part_map_pkg::IRW) begin : g_leg08_ir_len_within_codes
    $fatal(1, "illegal parameters: P_IR_LEN <= dft_part_map_pkg::IRW");
  end
  // The second clause, and the one that carries 9.4 itself: the all-ones
  // code must not also be a decoded instruction at this width. The decode
  // below reaches BYPASS by default, so an instruction that matches a decoded
  // code selects that code and never BYPASS - and the codes are sliced to the
  // instance width, so two that differ at IRW bits can coincide at fewer.
  // Without it P_IR_LEN = 1 would be legal, where IR_IDCODE[0:0] is 1'b1 and
  // so is the all-ones code: a one-bit instance would answer the BYPASS
  // instruction with IDCODE. The first clause above is what makes IR_BYPASS sliced to
  // P_IR_LEN all ones, so this comparison is against the constant 9.4 names
  // and not against a literal written again here.
  //
  // Every decoded code is listed, including the two inside the DDR range.
  // Listing only the range ends would be wrong: all-ones-ness is bitwise and
  // not ordinal, so IR_DDR1_CMD (5'b00111) slices to 3'b111 at three bits
  // while both ends slice to something else, and a code between two listed
  // codes can collide where neither of them does. The rule above pins the
  // width at five whenever these codes are decoded, which is what makes the
  // branch unreachable today; the list is still complete here so that this
  // rule does not depend on that one.
  if ((dft_part_map_pkg::IR_IDCODE[P_IR_LEN-1:0]
         == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
      || (P_DR_CLIENTS
          && ((dft_part_map_pkg::IR_DTR_CFG[P_IR_LEN-1:0]
                 == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
              || (dft_part_map_pkg::IR_DTR_LPDDR[P_IR_LEN-1:0]
                    == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
              || (dft_part_map_pkg::IR_DTR_STS[P_IR_LEN-1:0]
                    == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
              || (dft_part_map_pkg::IR_DDR0_CMD[P_IR_LEN-1:0]
                    == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
              || (dft_part_map_pkg::IR_DDR0_RD[P_IR_LEN-1:0]
                    == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
              || (dft_part_map_pkg::IR_DDR1_CMD[P_IR_LEN-1:0]
                    == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0])
              || (dft_part_map_pkg::IR_DDR1_RD[P_IR_LEN-1:0]
                    == dft_part_map_pkg::IR_BYPASS[P_IR_LEN-1:0]))))
      begin : g_leg08_bypass_code_distinct
    $fatal(1, "illegal parameters: the all-ones instruction is also a decoded code at this length");
  end

  // ---------------------------------------------------------------------
  // The state register. Four bits in the explicit encoding of 9.3, which
  // uses all sixteen codes, so no code is unreachable.
  // ---------------------------------------------------------------------
  logic [3:0] state_q;
  logic [3:0] state_d;

  always_comb begin
    // The next-state arm is written for every one of the sixteen states, so
    // the default below is unreachable by encoding. It still assigns, rather
    // than holding, so that a state register corrupted in silicon walks back
    // to Test-Logic-Reset instead of sitting in an undefined code.
    case (state_q)
      dft_part_map_pkg::TEST_LOGIC_RESET:    state_d = tms ? dft_part_map_pkg::TEST_LOGIC_RESET    : dft_part_map_pkg::RUN_TEST_IDLE;
      dft_part_map_pkg::RUN_TEST_IDLE:    state_d = tms ? dft_part_map_pkg::SELECT_DR_SCAN : dft_part_map_pkg::RUN_TEST_IDLE;
      dft_part_map_pkg::SELECT_DR_SCAN: state_d = tms ? dft_part_map_pkg::SELECT_IR_SCAN : dft_part_map_pkg::CAPTURE_DR;
      dft_part_map_pkg::CAPTURE_DR: state_d = tms ? dft_part_map_pkg::EXIT1_DR : dft_part_map_pkg::SHIFT_DR;
      dft_part_map_pkg::SHIFT_DR:  state_d = tms ? dft_part_map_pkg::EXIT1_DR : dft_part_map_pkg::SHIFT_DR;
      dft_part_map_pkg::EXIT1_DR: state_d = tms ? dft_part_map_pkg::UPDATE_DR : dft_part_map_pkg::PAUSE_DR;
      dft_part_map_pkg::PAUSE_DR: state_d = tms ? dft_part_map_pkg::EXIT2_DR : dft_part_map_pkg::PAUSE_DR;
      dft_part_map_pkg::EXIT2_DR: state_d = tms ? dft_part_map_pkg::UPDATE_DR : dft_part_map_pkg::SHIFT_DR;
      dft_part_map_pkg::UPDATE_DR: state_d = tms ? dft_part_map_pkg::SELECT_DR_SCAN : dft_part_map_pkg::RUN_TEST_IDLE;
      dft_part_map_pkg::SELECT_IR_SCAN: state_d = tms ? dft_part_map_pkg::TEST_LOGIC_RESET    : dft_part_map_pkg::CAPTURE_IR;
      dft_part_map_pkg::CAPTURE_IR: state_d = tms ? dft_part_map_pkg::EXIT1_IR : dft_part_map_pkg::SHIFT_IR;
      dft_part_map_pkg::SHIFT_IR:  state_d = tms ? dft_part_map_pkg::EXIT1_IR : dft_part_map_pkg::SHIFT_IR;
      dft_part_map_pkg::EXIT1_IR: state_d = tms ? dft_part_map_pkg::UPDATE_IR : dft_part_map_pkg::PAUSE_IR;
      dft_part_map_pkg::PAUSE_IR: state_d = tms ? dft_part_map_pkg::EXIT2_IR : dft_part_map_pkg::PAUSE_IR;
      dft_part_map_pkg::EXIT2_IR: state_d = tms ? dft_part_map_pkg::UPDATE_IR : dft_part_map_pkg::SHIFT_IR;
      dft_part_map_pkg::UPDATE_IR: state_d = tms ? dft_part_map_pkg::SELECT_DR_SCAN : dft_part_map_pkg::RUN_TEST_IDLE;
      default:    state_d = dft_part_map_pkg::TEST_LOGIC_RESET;
    endcase
  end

  // TRSTN1 is asynchronous in both directions, as 1149.1
  // specifies for a TAP reset, so it is not synchronised.
  always_ff @(posedge tck1 or negedge trstn1) begin
    if (!trstn1) state_q <= dft_part_map_pkg::TEST_LOGIC_RESET;
    else         state_q <= state_d;
  end

  assign tap_state = state_q;

  // Decoded strobes the data registers use. They are decodes of the state
  // register, not separate state, so they cannot disagree with it.
  assign capture_dr = (state_q == dft_part_map_pkg::CAPTURE_DR);
  assign shift_dr   = (state_q == dft_part_map_pkg::SHIFT_DR);
  assign update_dr  = (state_q == dft_part_map_pkg::UPDATE_DR);

  // ---------------------------------------------------------------------
  // Instruction register: a shift stage on the rising edge and an update
  // stage on the falling edge.
  // ---------------------------------------------------------------------
  localparam logic [P_IR_LEN-1:0] IR_RESET = {{(P_IR_LEN-1){1'b0}}, 1'b1};

  logic [P_IR_LEN-1:0] ir_sr_q;
  logic [P_IR_LEN-1:0] ir_q;

  always_ff @(posedge tck1 or negedge trstn1) begin
    if (!trstn1)                        ir_sr_q <= IR_RESET;
    else if (state_q == dft_part_map_pkg::CAPTURE_IR)     ir_sr_q <= IR_RESET;
    else if (state_q == dft_part_map_pkg::SHIFT_IR)      ir_sr_q <= {tdi, ir_sr_q[P_IR_LEN-1:1]};
  end

  // The instruction update stage, on the falling edge at Update-IR. It also
  // reloads IDCODE in Test-Logic-Reset,
  // so a TMS = 1 walk returns the TAP to its reset instruction without a
  // TRSTN1 pulse.
  always_ff @(negedge tck1 or negedge trstn1) begin
    if (!trstn1)                        ir_q <= IR_RESET;
    else if (state_q == dft_part_map_pkg::TEST_LOGIC_RESET)        ir_q <= IR_RESET;
    else if (state_q == dft_part_map_pkg::UPDATE_IR)     ir_q <= ir_sr_q;
  end

  assign ir = ir_q;

  // ---------------------------------------------------------------------
  // Instruction decode. Every undecoded instruction selects BYPASS, which is
  // what 1149.1 requires of an unimplemented code.
  // ---------------------------------------------------------------------
  logic sel_idcode;
  logic sel_cfg;
  logic sel_lpddr;
  logic sel_sts;
  logic sel_ddr_any;
  logic sel_tm;
  logic sel_byp;

  assign sel_idcode  = (ir_q == dft_part_map_pkg::IR_IDCODE[P_IR_LEN-1:0]);
  assign sel_cfg     = P_DR_CLIENTS && (ir_q == dft_part_map_pkg::IR_DTR_CFG[P_IR_LEN-1:0]);
  assign sel_lpddr   = P_DR_CLIENTS && (ir_q == dft_part_map_pkg::IR_DTR_LPDDR[P_IR_LEN-1:0]);
  assign sel_sts     = P_DR_CLIENTS && (ir_q == dft_part_map_pkg::IR_DTR_STS[P_IR_LEN-1:0]);
  // The four DDRx codes are contiguous (Table 46: 5'b00101 to 5'b01000), and
  // the specification's own decode is this range test.
  assign sel_ddr_any = P_DR_CLIENTS && (ir_q >= dft_part_map_pkg::IR_DDR0_CMD[P_IR_LEN-1:0])
                                    && (ir_q <= dft_part_map_pkg::IR_DDR1_RD[P_IR_LEN-1:0]);
  assign sel_tm      = P_DR_CLIENTS && (ir_q == dft_part_map_pkg::IR_DTR_TM[P_IR_LEN-1:0]);
  assign sel_byp     = ~(sel_idcode | sel_cfg | sel_lpddr | sel_sts | sel_ddr_any | sel_tm);

  // ---------------------------------------------------------------------
  // IDCODE and BYPASS, the two registers the TAP owns itself.
  // ---------------------------------------------------------------------
  logic [31:0] idcode_sr_q;
  logic        byp_sr_q;

  // The IDCODE shift register carries no reset: it is loaded
  // at Capture-DR before it can be shifted, and its output reaches TDO only
  // through the retiming stage, which is reset (see below).
  always_ff @(posedge tck1) begin
    if (sel_idcode && (state_q == dft_part_map_pkg::CAPTURE_DR))     idcode_sr_q <= P_IDCODE;
    else if (sel_idcode && (state_q == dft_part_map_pkg::SHIFT_DR)) idcode_sr_q <= {tdi, idcode_sr_q[31:1]};
  end

  // BYPASS captures 0 and delays TDI by one TCK1 (IEEE 1149.1).
  always_ff @(posedge tck1 or negedge trstn1) begin
    if (!trstn1)                               byp_sr_q <= 1'b0;
    else if (sel_byp && (state_q == dft_part_map_pkg::CAPTURE_DR)) byp_sr_q <= 1'b0;
    else if (sel_byp && (state_q == dft_part_map_pkg::SHIFT_DR))  byp_sr_q <= tdi;
  end

  // ---------------------------------------------------------------------
  // The data-register multiplexer.
  // ---------------------------------------------------------------------
  logic dr_tdo;

  // A continuous assignment rather than a process: a process that bit-selects
  // a vector is sensitive to every bit of it, which one of the flow's front
  // ends declines to model, and this is a multiplexer in any case.
  assign dr_tdo = sel_idcode  ? idcode_sr_q[0]
                : sel_cfg     ? dr_tdo_cfg
                : sel_lpddr   ? dr_tdo_lpddr
                : sel_sts     ? dr_tdo_sts
                : sel_ddr_any ? dr_tdo_ddr
                : sel_tm      ? dr_tdo_tm
                : byp_sr_q;

  // ---------------------------------------------------------------------
  // TDO retiming. Launched on the falling edge, as 1149.1 requires. The data
  // stage updates only in Shift-IR and Shift-DR and holds everywhere else,
  // so the unreset IDCODE stage cannot put an X on TDO1:
  // in every other state TDO carries the last shifted value, and the enable
  // is low.
  // ---------------------------------------------------------------------
  logic tdo_q;
  logic tdo_oe_q;

  always_ff @(negedge tck1 or negedge trstn1) begin
    if (!trstn1) begin
      tdo_q    <= 1'b0;
      tdo_oe_q <= 1'b0;
    end else begin
      if (state_q == dft_part_map_pkg::SHIFT_IR)      tdo_q <= ir_sr_q[0];
      else if (state_q == dft_part_map_pkg::SHIFT_DR) tdo_q <= dr_tdo;
      // The enable is asserted only in the two shift states (IEEE 1149.1).
      tdo_oe_q <= (state_q == dft_part_map_pkg::SHIFT_IR) || (state_q == dft_part_map_pkg::SHIFT_DR);
    end
  end

  assign tdo    = tdo_q;
  assign tdo_oe = tdo_oe_q;

endmodule
