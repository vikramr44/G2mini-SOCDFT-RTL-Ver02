// dft_jtag1_rtr -- TSEL1 decode, per-target TMS gating, and the TDO1 and
// TDO1_OE multiplexing of the JTAG1 pin group. Combinational throughout: it
// holds no state, so a target change takes effect as soon as TSEL1 settles.
// TSEL1 is static for a session. Change TSEL1 only with the selected TAP in
// Run-Test/Idle or Test-Logic-Reset; do not use TRST1_n for this, because
// TRST1_n low also clears the DTRs.
//

module dft_jtag1_rtr #(
    parameter bit P_OE_GATED = 1'b1,  // 1 gates each target's OE with its select
    parameter bit P_TM_OPEN  = 1'b0   // 0 (agreed): an unselected TAP sees TMS = 1; 1 (unverified build option) opens the external TAPs' TMS in test
) (
    input  logic       tm,
    input  logic [1:0] tsel1,
    input  logic       tms1,
    // returns from the three external targets
    input  logic       arc_tdo1,
    input  logic       arc_tdo1_oe,
    input  logic       pcia_tdo1,
    input  logic       pcia_tdo1_oe,
    input  logic       pcib_tdo1,
    input  logic       pcib_tdo1_oe,
    // the SOC_DFT chain (device 2 of the TSEL1 = 11 chain)
    input  logic       sms_tdo1,
    input  logic       sms_tdo1_oe,
    // gated TMS to each target
    output logic       arc_tms1,
    output logic       pcia_tms1,
    output logic       pcib_tms1,
    output logic       sms_tms1,
    // the pad side
    output logic       tdo1,
    output logic       tdo1_oe
);

  // TSEL1 decode (8.4). One select per target, and they are mutually
  // exclusive by construction because they decode the same two bits.
  logic arc_sel;
  logic pcia_sel;
  logic pcib_sel;
  logic sms_sel;

  assign arc_sel  = ~tsel1[1] & ~tsel1[0];
  assign pcia_sel = ~tsel1[1] &  tsel1[0];
  assign pcib_sel =  tsel1[1] & ~tsel1[0];
  assign sms_sel  =  tsel1[1] &  tsel1[0];

  // The opening term: in test, with P_TM_OPEN = 1, the three external TAPs
  // follow TMS1 whether or not they are selected, so a tester can walk them
  // all to Test-Logic-Reset at once.
  logic tm_o;
  assign tm_o = tm & P_TM_OPEN;

  // Per-target TMS. A target that is neither selected nor opened sees TMS = 1,
  // which parks it in Test-Logic-Reset (five TCK1 edges with TMS = 1 reach
  // it from any state, IEEE 1149.1).
  assign arc_tms1  = (arc_sel  | tm_o) ? tms1 : 1'b1;
  assign pcia_tms1 = (pcia_sel | tm_o) ? tms1 : 1'b1;
  assign pcib_tms1 = (pcib_sel | tm_o) ? tms1 : 1'b1;

  // The SOC_DFT TAP follows TMS1 whenever TSEL1 = 11, in test as well as in
  // functional mode (architect decision of 25 Nov 2026), and the DTRs it
  // reaches load at any DFTTM value (dft_dtr_reg). So during scan the test
  // program keeps TSEL1 != 11 (or TMS1 and TCK1 quiet) and keeps TRST1_n
  // high, and changes TSEL1 only as the header says.
  assign sms_tms1 = sms_sel ? tms1 : 1'b1;

  // TDO1 and its enable. The data mux follows the select; the enable is
  // the selected target's own (P_OE_GATED = 1, the agreed behaviour) or, as an
  // unverified build option, the ungated OR of the four.
  always_comb begin
    case (tsel1)
      2'b00:   tdo1 = arc_tdo1;
      2'b01:   tdo1 = pcia_tdo1;
      2'b10:   tdo1 = pcib_tdo1;
      default: tdo1 = sms_tdo1;
    endcase
  end

  always_comb begin
    if (P_OE_GATED) begin
      case (tsel1)
        2'b00:   tdo1_oe = arc_tdo1_oe;
        2'b01:   tdo1_oe = pcia_tdo1_oe;
        2'b10:   tdo1_oe = pcib_tdo1_oe;
        default: tdo1_oe = sms_tdo1_oe;
      endcase
    end else begin
      tdo1_oe = arc_tdo1_oe | pcia_tdo1_oe | pcib_tdo1_oe | sms_tdo1_oe;
    end
  end

endmodule
