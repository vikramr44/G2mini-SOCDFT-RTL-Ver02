// dft_dtr_tm -- DTR_TM, the 32-bit test-mode register. It holds the two
// test_mode bits of each of the eleven blocks (bits 21:0, block b at bits
// 2b+1:2b, in the block index order of dft_part_map_pkg) and the pad-loopback
// bit (bit 22), as sheet "Scan Test Modes" rows 17-31 lay them out.
// Bits 31:23 read 0.
//
// It is one more instance of dft_dtr_reg, built like DTR_CFG and DTR_LPDDR:
// shifted on TCK1, its shadow loaded at Update-DR at any DFTTM value, and
// reset by rst_dtr_n. It is a module of its own rather than a fourth register
// inside dft_dtr.
//
// It is selected by IR_DTR_TM (code 5'b01010, assigned by the architect on
// 25 Nov 2026; 5'b01001 is undecoded and selects BYPASS).
//
// DTR_CFG.CLR also clears DTR_TM to its reset value (architect decision of
// 25 Nov 2026), at the same Update-DR as it clears DTR_CFG and DTR_LPDDR, and
// like them at any DFTTM value; dft_dtr supplies the request.

module dft_dtr_tm #(
    parameter logic [31:0] P_TM_RST = 32'h0000_0000  // every test_mode 00, loopback off
) (
    input  logic        tck1,
    input  logic        rst_dtr_n,
    input  logic        tdi,
    input  logic [4:0]  ir,
    input  logic        capture_dr,
    input  logic        shift_dr,
    input  logic        update_dr,
    // the DTR_CFG.CLR request from dft_dtr
    input  logic        clr_req,
    // the shadow the decoder reads
    output logic [31:0] dtr_tm,
    // serial return into the TAP's DR multiplexer
    output logic        dr_tdo_tm
);

  logic        sel_tm;
  logic [31:0] tm_sr_unused;

  assign sel_tm = (ir == dft_part_map_pkg::IR_DTR_TM);

  dft_dtr_reg #(
      .P_WIDTH     (32),
      .P_HAS_SHADOW(1'b1),
      .P_RESET     (P_TM_RST),
      .P_MASK      (dft_part_map_pkg::TM_SHADOW_MASK)
  ) u_tm (
      .tck1         (tck1),
      .rst_dtr_n    (rst_dtr_n),
      .tdi          (tdi),
      .sel          (sel_tm),
      .capture_dr   (capture_dr),
      .shift_dr     (shift_dr),
      .update_dr    (update_dr),
      .capture_value(32'h0000_0000),
      .clr_req      (clr_req),
      .shadow       (dtr_tm),
      .sr_value     (tm_sr_unused),
      .dr_tdo       (dr_tdo_tm)
  );

endmodule
