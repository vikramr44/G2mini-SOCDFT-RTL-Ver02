// soc_dft -- the chip-top design-for-test controller of the G2mini SoC.
//
// It sits between the bonded DFT and JTAG1 pins and every block test port. The
// block-side port names and widths are those of the "SOC DFT PORT NAME"
// column of sheet "SOC DFT to Block level Connect" of
// the architect workbook of 25 Nov 2026; the scan modes, lane widths and the DTR_TM bit map
// are those of sheet "Scan Test Modes", the JTAG1 routing that of sheet "JTAG1
// Logic", and the clocking is that of sheet "DFT
// clock architecture": TCK1, TRSTN1, TMS1, DFTTM, DFTSE and DFTMAX come in
// from the pads, and soc_dft holds no clock multiplexer and no PLL logic.
//
// The top instantiates the sub-modules and holds the internal nets of 6.6. It
// holds no sequential element of its own: every flop of SOC_DFT is inside a
// sub-module, so that no state hides at the boundary.
//
// Signals the sheet connects to a pad net rather than to soc_dft (block DFTTM
// and DFTSE, "Driven from the PAD"; the LPDDR's atpg_mode, atpg_se[9:0],
// scan_shift_cg, compression_mode, TDRCLK and WRSTN, which the sheet ties to
// DFTTM, DFTSE, DFTMAX, TCK1 and TRSTN1; every block's TCK1 and TRST1_n) are
// joined at the chip top: they are the same nets as soc_dft's inputs of those
// names, not soc_dft outputs.
//
// Hierarchy: u_soc_dft is kept through synthesis, scan insertion and
// place-and-route, because the constraints, the equivalence check and the
// connectivity check all address instance paths (24.15).

module soc_dft #(
    parameter logic [31:0] P_IDCODE       = 32'h0000_0001,
    parameter bit          P_OE_GATED     = 1'b1,
    parameter bit          P_TM_OPEN      = 1'b0,           // sheet "JTAG1 Logic": unselected TAPs see TMS = 1
    parameter bit          P_DFTSO_HIZ_M0 = 1'b1,
    parameter logic [31:0] P_CFG_RST      = 32'h003F_FFA5,
    parameter logic [31:0] P_LPDDR_RST    = 32'h0000_0000,
    parameter logic [7:0]  P_RTL_REV      = 8'h06,
    parameter bit          P_TDR_EN_EDGE  = 1'b1,
    parameter bit          P_DFTMAX_COMP  = 1'b1,
    parameter int unsigned P_SMS_IR_LEN   = 4,
    parameter logic [31:0] P_SMS_IDCODE   = 32'h0001_0001,
    parameter int unsigned P_PARTITIONED  = 1
) (
    // ---- pad mode (sheet "DFT clock architecture": DFTTM, DFTSE, DFTMAX) --
    input  logic        DFTTM,
    input  logic        DFTMAX,
    input  logic        DFTSE,
    // ---- pad scan: the primary SI/SO the router steers (sheet "SOC_DFT
    // r0.62": DFTSI/DFTSO) ------------------------------------------------
    input  logic [19:0] DFTSI,
    output logic [19:0] DFTSO,
    output logic        DFTSO_OE,
    // the scan-mode select 0-7 (sheet "SOC_DFT r0.62": GPIO[14:12])
    input  logic [2:0]  DeMuxSel,
    // ---- JTAG1 (sheet "JTAG1 Logic": TSEL1[1:0], TMS1, TDI1, TDO1, TDO1_OE;
    // TCK1, TRSTN1) --------------------------------------------------------
    input  logic [1:0]  TSEL1,
    input  logic        TMS1,
    input  logic        TDI1,
    output logic        TDO1,
    output logic        TDO1_OE,
    input  logic        TCK1,
    input  logic        TRSTN1,
    input  logic        PwrOk,
    input  logic        Rstn,
    // ---- JTAG targets (sheet "JTAG1 Logic"; connect rows 54, 83, 122, 222,
    // 245): TMS to each external TAP, and each TAP's TDO and TDO enable back
    // (rows 57-58, 225-226, 248-249) ------------------------------------------
    output logic        pcia_tms1,
    output logic        pcib_tms1,
    output logic        arc_tms1,
    input  logic        arc_tdo1,
    input  logic        arc_tdo1_oe,
    input  logic        pcia_tdo1,
    input  logic        pcia_tdo1_oe,
    input  logic        pcib_tdo1,
    input  logic        pcib_tdo1_oe,
    // ---- TopG2mAxis (rows 5-11) ----------------------------------------
    output logic [7:0]  axis_test_si,
    input  logic [7:0]  axis_test_so,
    output logic [1:0]  axis_test_mode,
    output logic        axis_wrap_si,
    input  logic        axis_wrap_so,
    // ---- TopG2mAxim (rows 14-20) ---------------------------------------
    output logic [3:0]  axim_test_si,
    input  logic [3:0]  axim_test_so,
    output logic [1:0]  axim_test_mode,
    output logic        axim_wrap_si,
    input  logic        axim_wrap_so,
    // ---- TopG2mApb (rows 23-29) ----------------------------------------
    output logic [3:0]  apb_test_si,
    input  logic [3:0]  apb_test_so,
    output logic [1:0]  apb_test_mode,
    output logic        apb_wrap_si,
    input  logic        apb_wrap_so,
    // ---- TopG2PciA (rows 32-38) and TopG2PciB (rows 200-206) ----------
    output logic [11:0] pcia_test_si,
    input  logic [11:0] pcia_test_so,
    output logic [11:0] pcib_test_si,
    input  logic [11:0] pcib_test_so,
    output logic [1:0]  pciea_test_mode,
    output logic        pcia_wrap_si,
    input  logic        pcia_wrap_so,
    output logic [1:0]  pcieb_test_mode,
    output logic        pcib_wrap_si,
    input  logic        pcib_wrap_so,
    // ---- TopG2mcp (rows 61-67) -----------------------------------------
    output logic [7:0]  g2muc_test_si,
    input  logic [7:0]  g2muc_test_so,
    output logic [1:0]  g2muc_test_mode,
    output logic        g2muc_wrap_si,
    input  logic        g2muc_wrap_so,
    // ---- TopG2mL4ga (rows 90-96) and TopG2mL4gb (rows 253-259) ---------
    output logic [1:0]  l4ga_test_si,
    input  logic [1:0]  l4ga_test_so,
    output logic [1:0]  L4ga_test_mode,
    output logic        l4ga_wrap_si,
    input  logic        l4ga_wrap_so,
    output logic [1:0]  l4gb_test_si,
    input  logic [1:0]  l4gb_test_so,
    output logic [1:0]  L4gb_test_mode,
    output logic        l4gb_wrap_si,
    input  logic        l4gb_wrap_so,
    // ---- TopG2mArc (SCC) (rows 107-113) and TopG2mArc (HIC) (rows 230-236)
    output logic [5:0]  scc_test_si,
    input  logic [5:0]  scc_test_so,
    output logic [1:0]  scc_test_mode,
    output logic        scc_wrap_si,
    input  logic        scc_wrap_so,
    output logic [5:0]  hic_test_si,
    input  logic [5:0]  hic_test_so,
    output logic [1:0]  hic_test_mode,
    output logic        hic_wrap_si,
    input  logic        hic_wrap_so,
    // ---- TopG2mAhb (rows 131-137) --------------------------------------
    output logic [5:0]  ahb_test_si,
    input  logic [5:0]  ahb_test_so,
    output logic [1:0]  ahb_test_mode,
    output logic        ahb_wrap_si,
    input  logic        ahb_wrap_so,
    // ---- SMS wrapper serial ports, one set per instance (rows 39-52,
    // 68-81, 97-102, 114-120, 138-144, 207-220, 237-243, 260-265) ----------
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_index_based_repair,  // row 52 (sheet: "Pci_2a")
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mScc_1_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mHic_1_index_based_repair,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSI,
    input  logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSO,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_UpdateWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_SelectWIR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_ShiftWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_CaptureWR,
    output logic        vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_index_based_repair,
    // ---- top glue: kept by architect decision of 18 Nov 2026; no sheet lists it
    output logic        top_scan_shift_en,
    // ---- LPDDR (rows 150-196) ------------------------------------------
    output logic        sms_dm0,
    output logic        sms_dm1,
    output logic        sms_dm2,
    output logic        rst_n,
    output logic        scan_resetn,
    output logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSI,
    output logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_SelectWIR,
    output logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_CaptureWR,
    output logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_ShiftWR,
    output logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_UpdateWR,
    input  logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSO,
    output logic [6:0]  vl_srv_u_sms_sub_server_snps_ddr_subsystem_ring_bypass,
    output logic        vl_srv_u_sms_sub_server_snps_ddr_subsystem_sfp_dft_mode,
    output logic        phy0_DdrPhyCsrCmdTdrCaptureEn,
    output logic        phy0_DdrPhyCsrCmdTdrShiftEn,
    output logic        phy0_DdrPhyCsrCmdTdrUpdateEn,
    output logic        phy0_DdrPhyCsrRdDataTdrCaptureEn,
    output logic        phy0_DdrPhyCsrRdDataTdrShiftEn,
    output logic        phy0_DdrPhyCsrRdDataTdrUpdateEn,
    output logic        phy0_WSI,
    input  logic        phy0_DdrPhyCsrCmdTdr_Tdo,
    input  logic        phy0_DdrPhyCsrRdDataTdr_Tdo,
    output logic [1:0]  scan_ctl,
    output logic        phy0_BurnIn,
    output logic [19:0] ddr_test_si,
    input  logic [19:0] ddr_test_so,
    output logic        phy1_DdrPhyCsrCmdTdrCaptureEn,
    output logic        phy1_DdrPhyCsrCmdTdrShiftEn,
    output logic        phy1_DdrPhyCsrCmdTdrUpdateEn,
    output logic        phy1_DdrPhyCsrRdDataTdrCaptureEn,
    output logic        phy1_DdrPhyCsrRdDataTdrShiftEn,
    output logic        phy1_DdrPhyCsrRdDataTdrUpdateEn,
    output logic        phy1_WSI,
    input  logic        phy1_DdrPhyCsrCmdTdr_Tdo,
    input  logic        phy1_DdrPhyCsrRdDataTdr_Tdo,
    output logic        phy1_BurnIn
);

  // =====================================================================
  // Elaboration guards for the parameter rules. Generate-region elaboration
  // system tasks, so a configuration that cannot work is refused by every
  // front end that elaborates it: a generate-if whose condition is false is
  // never elaborated, so a legal build never meets them.
  // =====================================================================
  if (P_IDCODE[0] !== 1'b1) begin : g_leg03_idcode_bit0
    $fatal(1, "illegal parameters: P_IDCODE[0] = 1 and P_SMS_IDCODE[0] = 1");
  end
  if (P_SMS_IDCODE[0] !== 1'b1) begin : g_leg03_sms_idcode_bit0
    $fatal(1, "illegal parameters: P_IDCODE[0] = 1 and P_SMS_IDCODE[0] = 1");
  end
  if (P_IDCODE === P_SMS_IDCODE) begin : g_leg04_idcodes_differ
    $fatal(1, "illegal parameters: P_IDCODE != P_SMS_IDCODE");
  end
  if (P_SMS_IR_LEN < 1) begin : g_leg05_sms_ir_len
    $fatal(1, "illegal parameters: P_SMS_IR_LEN >= 1");
  end
  // The only two builds are the partial build and the hierarchical
  // build. The parameter is `int unsigned` rather than `bit` so that an
  // integrator's override of 2 is refused here instead of truncating to 0.
  if ((P_PARTITIONED != 0) && (P_PARTITIONED != 1)) begin : g_leg01_partitioned
    $fatal(1, "illegal parameters: P_PARTITIONED in {0, 1}");
  end

`ifndef YOSYS
  // The two lane-table rules are checked at time 0: each sums or masks
  // across the whole lane table, so they are statements in a
  // procedural block, not generate-ifs. The yosys front end has no elaboration
  // system tasks and only reads a configuration the other front ends have
  // already elaborated, so these are excluded from it rather than weakened.
  initial begin : g_legality
    int unsigned chan_sum;
    logic [dft_part_map_pkg::NBLK-1:0] part_mask;

    // Twenty pin pairs, one channel per pair per direction, so the
    // channel sum of one INTEST scan mode (DeMuxSel 1-6) can never exceed 20.
    for (int unsigned p = 1; p <= 6; p++) begin
      chan_sum  = 0;
      part_mask = dft_part_map_pkg::scan_mode_sel(p[2:0]);
      for (int unsigned b = 0; b < dft_part_map_pkg::NBLK; b++) begin
        if (part_mask[b]) chan_sum += dft_part_map_pkg::nch(b);
      end
      if (chan_sum > dft_part_map_pkg::NPIN)
        $fatal(1, "illegal parameters: sum of NCH over one INTEST scan mode <= 20");
    end

    // A one-in one-out codec has no X tolerance, so every block
    // scanned through the router has at least two channels; LPDDR is a hard IP
    // and takes none of the block bus.
    for (int unsigned b = 0; b < dft_part_map_pkg::NBLK; b++) begin
      if (dft_part_map_pkg::P0_MEMBER[b] && (dft_part_map_pkg::nch(b) < 2))
        $fatal(1, "illegal parameters: NCH[b] >= 2 for every routed block, NCH[11] = 0");
    end
    if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_LPDDR) != 0)
      $fatal(1, "illegal parameters: NCH[b] >= 2 for every routed block, NCH[11] = 0");

    // EXTEST (mode 7) uses one wrapper pin pair per block, eleven
    // blocks on eleven of the twenty pins (sheet "Scan Test Modes" row 11).
    if (dft_part_map_pkg::EXTEST_PINS_USED != dft_part_map_pkg::NSCAN)
      $fatal(1, "illegal parameters: the EXTEST scan mode uses eleven pins, one per block");
  end

  // =====================================================================
  // The scan-mode lane table against its literals. The package holds the
  // lane table the router reads; these are the counts of sheet "Scan Test
  // Modes" rows 4-11 and 14 and the lanes of a design decision,
  // written out independently, so a wrong lane or width is caught at
  // elaboration and not in a pattern.
  // =====================================================================
  if (P_PARTITIONED == 1) begin : g_map_check
    initial begin
      // the lane widths of the sheet (rows 5-10, 14)
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_PCIA)  != 12) $fatal(1, "illegal parameters: PCIA is not 12 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_PCIB)  != 12) $fatal(1, "illegal parameters: PCIB is not 12 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_G2MUC) != 8)  $fatal(1, "illegal parameters: MCP is not 8 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_AXIM)  != 4)  $fatal(1, "illegal parameters: AXIM is not 4 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_L4GA)  != 2)  $fatal(1, "illegal parameters: L4GA is not 2 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_AHB)   != 6)  $fatal(1, "illegal parameters: AHB is not 6 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_L4GB)  != 2)  $fatal(1, "illegal parameters: L4GB is not 2 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_APB)   != 4)  $fatal(1, "illegal parameters: APB is not 4 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_SCC)   != 6)  $fatal(1, "illegal parameters: SCC is not 6 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_HIC)   != 6)  $fatal(1, "illegal parameters: HIC is not 6 lanes");
      if (dft_part_map_pkg::nch(dft_part_map_pkg::BLK_AXIS)  != 8)  $fatal(1, "illegal parameters: AXIS is not 8 lanes");
      // mode 1: pcia 19:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd1, dft_part_map_pkg::BLK_PCIA) != 8)
        $fatal(1, "illegal parameters: mode 1 pcia lane base is not 8");
      // mode 2: pcib 19:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd2, dft_part_map_pkg::BLK_PCIB) != 8)
        $fatal(1, "illegal parameters: mode 2 pcib lane base is not 8");
      // mode 3: g2muc 19:12, axim 11:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd3, dft_part_map_pkg::BLK_G2MUC) != 12)
        $fatal(1, "illegal parameters: mode 3 g2muc lane base is not 12");
      if (dft_part_map_pkg::lane_lo(3'd3, dft_part_map_pkg::BLK_AXIM) != 8)
        $fatal(1, "illegal parameters: mode 3 axim lane base is not 8");
      // mode 4: l4ga 15:14, ahb 13:8, axis 7:0, lanes 19:16 unused
      if (dft_part_map_pkg::lane_lo(3'd4, dft_part_map_pkg::BLK_L4GA) != 14)
        $fatal(1, "illegal parameters: mode 4 l4ga lane base is not 14");
      if (dft_part_map_pkg::lane_lo(3'd4, dft_part_map_pkg::BLK_AHB) != 8)
        $fatal(1, "illegal parameters: mode 4 ahb lane base is not 8");
      // mode 5: l4gb 13:12, apb 11:8, axis 7:0, lanes 19:14 unused
      if (dft_part_map_pkg::lane_lo(3'd5, dft_part_map_pkg::BLK_L4GB) != 12)
        $fatal(1, "illegal parameters: mode 5 l4gb lane base is not 12");
      if (dft_part_map_pkg::lane_lo(3'd5, dft_part_map_pkg::BLK_APB) != 8)
        $fatal(1, "illegal parameters: mode 5 apb lane base is not 8");
      // mode 6: scc 19:14, hic 13:8, axis 7:0
      if (dft_part_map_pkg::lane_lo(3'd6, dft_part_map_pkg::BLK_SCC) != 14)
        $fatal(1, "illegal parameters: mode 6 scc lane base is not 14");
      if (dft_part_map_pkg::lane_lo(3'd6, dft_part_map_pkg::BLK_HIC) != 8)
        $fatal(1, "illegal parameters: mode 6 hic lane base is not 8");
      // every mode 1-6: axis on lanes 7:0, and every member inside the
      // twenty lanes
      for (int unsigned m = 1; m <= 6; m++) begin
        if (dft_part_map_pkg::lane_lo(m[2:0], dft_part_map_pkg::BLK_AXIS) != 0)
          $fatal(1, "illegal parameters: axis lane base is not 0 in a mode 1-6");
        for (int unsigned b = 0; b < dft_part_map_pkg::NSCAN; b++) begin
          if ((((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b) & 13'd1) != 13'd0) &&
              (dft_part_map_pkg::lane_lo(m[2:0], b) + dft_part_map_pkg::nch(b)
               > dft_part_map_pkg::NPIN))
            $fatal(1, "illegal parameters: a block's lanes pass lane 19");
          // no two blocks of one mode share a lane
          for (int unsigned b2 = b + 1; b2 < dft_part_map_pkg::NSCAN; b2++) begin
            if ((((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b) & 13'd1) != 13'd0) &&
                (((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b2) & 13'd1) != 13'd0) &&
                (dft_part_map_pkg::lane_lo(m[2:0], b) < dft_part_map_pkg::lane_lo(m[2:0], b2) + dft_part_map_pkg::nch(b2)) &&
                (dft_part_map_pkg::lane_lo(m[2:0], b2) < dft_part_map_pkg::lane_lo(m[2:0], b) + dft_part_map_pkg::nch(b)))
              $fatal(1, "illegal parameters: two blocks share a lane in one scan mode");
          end
        end
      end
      // every block but axis is in exactly one mode 1-6, and axis is in all
      // six: the router feeds a block from the bus of its one mode only
      for (int unsigned b = 0; b < dft_part_map_pkg::NSCAN; b++) begin
        int unsigned n_in;
        n_in = 0;
        for (int unsigned m = 1; m <= 6; m++)
          if ((((dft_part_map_pkg::scan_mode_sel(m[2:0]) >> b) & 13'd1) != 13'd0)) n_in++;
        if ((b == dft_part_map_pkg::BLK_AXIS) ? (n_in != 6) : (n_in != 1))
          $fatal(1, "illegal parameters: a block is not in exactly one scan mode (axis: all six)");
      end
    end
  end
`endif

  // =====================================================================
  // Internal nets of 6.6
  // =====================================================================
  logic        tm;
  logic        dftmax_i;
  logic        dftse_i;
  logic        rst_dtr_n;

  logic        sms_tms1;
  logic        sms_tdo1;
  logic        sms_tdo1_oe;
  logic        tap_tdi;
  // The stub TAP's own TDO enable. The TSEL1 = 11 chain's pad enable is the
  // SOC_DFT TAP's, never the stub's (6.6), so the top reads this one nowhere.
  logic        unused_sms_tap_tdo_oe;

  logic [3:0]  tap_state;
  logic [4:0]  ir;
  logic        capture_dr;
  logic        shift_dr;
  logic        update_dr;

  logic        dr_tdo_cfg;
  logic        dr_tdo_lpddr;
  logic        dr_tdo_sts;
  logic        dr_tdo_ddr;

  logic [31:0] dtr_cfg;
  logic [31:0] dtr_lpddr;
  logic        ddr_tdr_en;
  logic [2:0]  lpddr_sms_dm;
  logic [6:0]  lpddr_ring_bypass;
  logic        lpddr_sfp_dft_mode;

  logic [12:0] sel;
  logic        extest;
  logic        loopback;
  // The mode decoder's outputs before DFTTM is applied
  logic [12:0] sel_dec;
  logic        extest_dec;
  logic        loopback_dec;

  // DTR_TM and the eleven two-bit test_mode codes (sheet bit map)
  logic [31:0] dtr_tm;
  logic        dr_tdo_tm;
  logic        dtr_clr_req;
  logic [21:0] blk_test_mode;       // 11 slots of TMW = 2
  logic [21:0] blk_test_mode_dec;   // before DFTTM is applied

  // The router's block-side view: block b's channels occupy NCH[b] bits of
  // the channel bus from CHAN_BASE[b] (the lane widths of sheet "Scan Test
  // Modes"), so that one router serves blocks of different widths without a
  // per-block port list.
  logic [dft_part_map_pkg::NCHAN-1:0] blk_test_si;
  logic [dft_part_map_pkg::NCHAN-1:0] blk_test_so;
  logic [10:0]  blk_wrap_si;   // one wrapper chain per block
  logic [10:0]  blk_wrap_so;

  // the SMS shell's packed wrapper buses, one per instance
  logic [9:0]  pcia_sms_in;
  logic [1:0]  pcia_sms_out;
  logic [9:0]  pcib_sms_in;
  logic [1:0]  pcib_sms_out;
  logic [9:0]  g2muc_sms_in;
  logic [1:0]  g2muc_sms_out;
  logic [4:0]  l4ga_sms_in;
  logic        l4ga_sms_out;
  logic [4:0]  l4gb_sms_in;
  logic        l4gb_sms_out;
  logic [4:0]  scc_sms_in;
  logic        scc_sms_out;
  logic [4:0]  hic_sms_in;
  logic        hic_sms_out;
  logic [4:0]  ahb_sms_in;
  logic        ahb_sms_out;
  logic [4:0]  ddr_sms_in;
  logic        ddr_sms_out;

  // the test reset
  logic        rst_n_test;

  assign ddr_tdr_en = dtr_cfg[dft_part_map_pkg::CFG_DDR_TDR_EN];

  // the source side: the eight levels DTR_STS captures, in the bit
  // order of Table 52. Bits 7:5 are tied 0: the connect sheet has no PLL-ready
  // port and the clock sheet draws no PLL signal into SOC DFT, so
  // DTR_STS.PLL_RDY reads 0.
  logic [7:0] sts_levels;
  assign sts_levels = {3'b000, PwrOk, TSEL1, dftmax_i, DFTTM};

  // =====================================================================
  // u_pad_if
  // =====================================================================
  dft_pad_if #(
      .P_DFTSO_HIZ_M0(P_DFTSO_HIZ_M0),
      .P_DFTMAX_COMP (P_DFTMAX_COMP)
  ) u_pad_if (
      .dfttm_pad (DFTTM),
      .dftmax_pad(DFTMAX),
      .dftse_pad (DFTSE),
      .pwrok_pad (PwrOk),
      .trstn1    (TRSTN1),
      .tck1      (TCK1),
      .tm        (tm),
      .dftmax_i  (dftmax_i),
      .dftse_i   (dftse_i),
      .dftso_oe  (DFTSO_OE),
      .rst_dtr_n (rst_dtr_n)
  );

  // =====================================================================
  // u_jtag1_rtr
  //
  // Sheet "JTAG1 Logic": TSEL1 selects one of four targets; each unselected
  // external TAP sees TMS = 1 (P_TM_OPEN = 0), and TDO1 and TDO1_OE are taken
  // from the selected target. The ARC target is the GUCC -> SCC -> HIC daisy
  // chain, whose last TDO and TDO enable return as arc_tdo1 and arc_tdo1_oe.
  // =====================================================================
  dft_jtag1_rtr #(
      .P_OE_GATED(P_OE_GATED),
      .P_TM_OPEN (P_TM_OPEN)
  ) u_jtag1_rtr (
      .tm          (tm),
      .tsel1       (TSEL1),
      .tms1        (TMS1),
      .arc_tdo1    (arc_tdo1),
      .arc_tdo1_oe (arc_tdo1_oe),
      .pcia_tdo1   (pcia_tdo1),
      .pcia_tdo1_oe(pcia_tdo1_oe),
      .pcib_tdo1   (pcib_tdo1),
      .pcib_tdo1_oe(pcib_tdo1_oe),
      .sms_tdo1    (sms_tdo1),
      .sms_tdo1_oe (sms_tdo1_oe),
      .arc_tms1    (arc_tms1),
      .pcia_tms1   (pcia_tms1),
      .pcib_tms1   (pcib_tms1),
      .sms_tms1    (sms_tms1),
      .tdo1        (TDO1),
      .tdo1_oe     (TDO1_OE)
  );

  // =====================================================================
  // u_sms_srv -- the SMS shell, device 1 of the TSEL1 = 11 chain, clocked by
  // TCK1
  // =====================================================================
  dft_sms_srv #(
      .P_SMS_IR_LEN(P_SMS_IR_LEN),
      .P_SMS_IDCODE(P_SMS_IDCODE)
  ) u_sms_srv (
      .tck1          (TCK1),
      .trstn1        (TRSTN1),
      .tdi1          (TDI1),
      .sms_tms1      (sms_tms1),
      .dfttm         (tm),
      .dftse         (dftse_i),
      .pcia_sms_out  (pcia_sms_out),
      .pcib_sms_out  (pcib_sms_out),
      .g2muc_sms_out (g2muc_sms_out),
      .l4ga_sms_out  (l4ga_sms_out),
      .l4gb_sms_out  (l4gb_sms_out),
      .scc_sms_out   (scc_sms_out),
      .hic_sms_out   (hic_sms_out),
      .ahb_sms_out   (ahb_sms_out),
      .ddr_sms_out   (ddr_sms_out),
      .pcia_sms_in   (pcia_sms_in),
      .pcib_sms_in   (pcib_sms_in),
      .g2muc_sms_in  (g2muc_sms_in),
      .l4ga_sms_in   (l4ga_sms_in),
      .l4gb_sms_in   (l4gb_sms_in),
      .scc_sms_in    (scc_sms_in),
      .hic_sms_in    (hic_sms_in),
      .ahb_sms_in    (ahb_sms_in),
      .ddr_sms_in    (ddr_sms_in),
      .tap_tdi       (tap_tdi),
      .sms_tap_tdo_oe(unused_sms_tap_tdo_oe)
  );

  // =====================================================================
  // u_sms_ports -- the sheet's wrapper port names
  // =====================================================================
  dft_sms_ports u_sms_ports (
      .pcia_sms_in       (pcia_sms_in),
      .pcia_sms_out      (pcia_sms_out),
      .pcib_sms_in       (pcib_sms_in),
      .pcib_sms_out      (pcib_sms_out),
      .g2muc_sms_in      (g2muc_sms_in),
      .g2muc_sms_out     (g2muc_sms_out),
      .l4ga_sms_in       (l4ga_sms_in),
      .l4ga_sms_out      (l4ga_sms_out),
      .l4gb_sms_in       (l4gb_sms_in),
      .l4gb_sms_out      (l4gb_sms_out),
      .scc_sms_in        (scc_sms_in),
      .scc_sms_out       (scc_sms_out),
      .hic_sms_in        (hic_sms_in),
      .hic_sms_out       (hic_sms_out),
      .ahb_sms_in        (ahb_sms_in),
      .ahb_sms_out       (ahb_sms_out),
      .ddr_sms_in        (ddr_sms_in),
      .ddr_sms_out       (ddr_sms_out),
      .lpddr_ring_bypass (lpddr_ring_bypass),
      .lpddr_sfp_dft_mode(lpddr_sfp_dft_mode),
      .*
  );

  // =====================================================================
  // u_tap -- device 2 of the chain
  // =====================================================================
  dft_tap #(
      .P_IR_LEN    (5),
      .P_DR_CLIENTS(1'b1),
      .P_IDCODE    (P_IDCODE)
  ) u_tap (
      .tck1        (TCK1),
      .trstn1      (TRSTN1),
      .tms         (sms_tms1),
      .tdi         (tap_tdi),
      .dr_tdo_cfg  (dr_tdo_cfg),
      .dr_tdo_lpddr(dr_tdo_lpddr),
      .dr_tdo_sts  (dr_tdo_sts),
      .dr_tdo_ddr  (dr_tdo_ddr),
      .dr_tdo_tm   (dr_tdo_tm),
      .tap_state   (tap_state),
      .ir          (ir),
      .capture_dr  (capture_dr),
      .shift_dr    (shift_dr),
      .update_dr   (update_dr),
      // The SOC_DFT TAP is the last device in the chain, so its TDO and its
      // enable are the chain's, and the JTAG router puts them on the pad.
      .tdo         (sms_tdo1),
      .tdo_oe      (sms_tdo1_oe)
  );

  // =====================================================================
  // u_dtr
  // =====================================================================
  dft_dtr #(
      .P_CFG_RST  (P_CFG_RST),
      .P_LPDDR_RST(P_LPDDR_RST),
      .P_RTL_REV  (P_RTL_REV)
  ) u_dtr (
      .tck1              (TCK1),
      .rst_dtr_n         (rst_dtr_n),
      .tdi               (tap_tdi),
      .ir                (ir),
      .capture_dr        (capture_dr),
      .shift_dr          (shift_dr),
      .update_dr         (update_dr),
      .sts_levels        (sts_levels),
      .dtr_cfg           (dtr_cfg),
      .dtr_lpddr         (dtr_lpddr),
      .lpddr_sms_dm      (lpddr_sms_dm),
      .lpddr_ring_bypass (lpddr_ring_bypass),
      .lpddr_sfp_dft_mode(lpddr_sfp_dft_mode),
      .dr_tdo_cfg        (dr_tdo_cfg),
      .dr_tdo_lpddr      (dr_tdo_lpddr),
      .dr_tdo_sts        (dr_tdo_sts),
      .dtr_clr_req       (dtr_clr_req)
  );

  // the LPDDR SMS mode bits (rows 150-152)
  assign sms_dm0 = lpddr_sms_dm[0];
  assign sms_dm1 = lpddr_sms_dm[1];
  assign sms_dm2 = lpddr_sms_dm[2];

  // =====================================================================
  // u_dtr_tm -- DTR_TM
  // =====================================================================
  dft_dtr_tm u_dtr_tm (
      .tck1      (TCK1),
      .rst_dtr_n (rst_dtr_n),
      .tdi       (tap_tdi),
      .ir        (ir),
      .capture_dr(capture_dr),
      .shift_dr  (shift_dr),
      .update_dr (update_dr),
      .clr_req   (dtr_clr_req),
      .dtr_tm    (dtr_tm),
      .dr_tdo_tm (dr_tdo_tm)
  );

  // =====================================================================
  // u_mode_dec
  // =====================================================================
  dft_mode_dec u_mode_dec (
      .tm               (tm),
      .dtr_cfg          (dtr_cfg),
      .dtr_lpddr        (dtr_lpddr),
      .demux_sel        (DeMuxSel),
      .dtr_tm           (dtr_tm),
      .sel              (sel_dec),
      .extest           (extest_dec),
      .loopback         (loopback_dec),
      .blk_test_mode    (blk_test_mode_dec),
      .lpddr_phy0_burnin(phy0_BurnIn),
      .lpddr_phy1_burnin(phy1_BurnIn),
      .lpddr_scan_ctl   (scan_ctl)
  );

  // DFTTM is applied here, not in the decoder, so
  // nothing moves while DFTTM is low.
  assign sel      = {13{tm}} & sel_dec;
  assign extest   = tm & extest_dec;
  assign loopback = tm & loopback_dec;
  assign blk_test_mode = tm ? blk_test_mode_dec : '0;

  // =====================================================================
  // u_scan_rtr -- instantiated only in the hierarchical build (P_PARTITIONED)
  //
  // In the partial build the router does not exist and the partition-dependent
  // outputs take the fixed values of 11.3: no channel is routed and every
  // DFTSO lane drives 0.
  // =====================================================================
  if (P_PARTITIONED == 1) begin : g_router
    dft_scan_rtr u_scan_rtr (
        .tm           (tm),
        .demux_sel    (DeMuxSel),
        .sel          (sel),
        .extest       (extest),
        .loopback     (loopback),
        .dftsi        (DFTSI),
        .blk_test_so  (blk_test_so),
        .blk_wrap_so  (blk_wrap_so),
        .lpddr_test_so(ddr_test_so),
        .blk_test_si  (blk_test_si),
        .blk_wrap_si  (blk_wrap_si),
        .lpddr_test_si(ddr_test_si),
        .dftso        (DFTSO)
    );
  end else begin : g_no_router
    always_comb begin
      blk_test_si = '0;
      blk_wrap_si = '0;
      ddr_test_si = '0;
      DFTSO       = '0;
    end
    // The nets the router reads in the hierarchical build and nothing reads
    // here, taken to one deliberate sink (11.3: no channel is routed).
    logic unused_no_router;
    assign unused_no_router = ^{1'b0, DFTSI, DeMuxSel, sel, extest, loopback,
                                blk_test_so, blk_wrap_so, ddr_test_so};
  end

  // =====================================================================
  // u_crg_ctl -- the test reset only (no clock control)
  // =====================================================================
  dft_crg_ctl u_crg_ctl (
      .tm                (tm),
      .rstn_pad          (Rstn),
      .dtr_cfg           (dtr_cfg),
      .dft_crg_rst_n_test(rst_n_test),
      .lpddr_scan_rstn   (scan_resetn)
  );

  // The LPDDR rst_n (row 154) is the test reset: the Rstn pad unless, in
  // test, DTR_CFG.RST_OVR substitutes RST_VAL (architect decision 25 Nov 2026).
  assign rst_n = rst_n_test;

  // =====================================================================
  // u_ddr_tdr
  // =====================================================================
  dft_ddr_tdr #(
      .P_TDR_EN_EDGE(P_TDR_EN_EDGE)
  ) u_ddr_tdr (
      .tck1      (TCK1),
      .trstn1    (TRSTN1),
      .tdi       (tap_tdi),
      .tap_state (tap_state),
      .ir        (ir),
      .ddr_tdr_en(ddr_tdr_en),
      .dr_tdo_ddr(dr_tdo_ddr),
      .*
  );

  // =====================================================================
  // Block-side fan-out. Each block port is its slot of the router's channel
  // bus (sheet "Scan Test Modes" widths = connect-sheet widths).
  //
  // The blocks take DFTTM, scan shift enable and wrapper shift enable straight
  // from the DFTTM and DFTSE pads at the chip top ("Driven from the PAD"), so
  // soc_dft has no such block outputs. top_scan_shift_en is kept (architect
  // decision 18 Nov 2026).
  // =====================================================================
  localparam int unsigned CB_SCC   = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_SCC);
  localparam int unsigned CB_HIC   = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_HIC);
  localparam int unsigned CB_G2MUC = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_G2MUC);
  localparam int unsigned CB_L4GA  = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_L4GA);
  localparam int unsigned CB_L4GB  = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_L4GB);
  localparam int unsigned CB_PCIA  = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_PCIA);
  localparam int unsigned CB_PCIB  = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_PCIB);
  localparam int unsigned CB_AHB   = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_AHB);
  localparam int unsigned CB_APB   = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_APB);
  localparam int unsigned CB_AXIS  = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_AXIS);
  localparam int unsigned CB_AXIM  = dft_part_map_pkg::chan_base(dft_part_map_pkg::BLK_AXIM);

  // top_scan_shift_en follows DFTSE in mode 7 (EXTEST) only.
  assign top_scan_shift_en = dftse_i & extest;

  // the test_mode fields of the DTR_TM bit map (sheet "Scan Test Modes" rows 19-29)
  assign scc_test_mode    = blk_test_mode[dft_part_map_pkg::BLK_SCC*2   +: 2];  // [1:0] scc
  assign hic_test_mode    = blk_test_mode[dft_part_map_pkg::BLK_HIC*2   +: 2];  // [3:2] hic
  assign g2muc_test_mode  = blk_test_mode[dft_part_map_pkg::BLK_G2MUC*2 +: 2];  // [5:4] g2muc
  assign L4ga_test_mode   = blk_test_mode[dft_part_map_pkg::BLK_L4GA*2  +: 2];  // [7:6] l4ga
  assign L4gb_test_mode   = blk_test_mode[dft_part_map_pkg::BLK_L4GB*2  +: 2];  // [9:8] l4gb
  assign pciea_test_mode  = blk_test_mode[dft_part_map_pkg::BLK_PCIA*2  +: 2];  // [11:10] pciea
  assign pcieb_test_mode  = blk_test_mode[dft_part_map_pkg::BLK_PCIB*2  +: 2];  // [13:12] pcieb
  assign ahb_test_mode    = blk_test_mode[dft_part_map_pkg::BLK_AHB*2   +: 2];  // [15:14] ahb
  assign apb_test_mode    = blk_test_mode[dft_part_map_pkg::BLK_APB*2   +: 2];  // [17:16] apb
  assign axis_test_mode   = blk_test_mode[dft_part_map_pkg::BLK_AXIS*2  +: 2];  // [19:18] axis
  assign axim_test_mode   = blk_test_mode[dft_part_map_pkg::BLK_AXIM*2  +: 2];  // [21:20] axim

  // scan-in, block by block
  assign scc_test_si   = blk_test_si[CB_SCC   +: 6];
  assign hic_test_si   = blk_test_si[CB_HIC   +: 6];
  assign g2muc_test_si = blk_test_si[CB_G2MUC +: 8];
  assign l4ga_test_si  = blk_test_si[CB_L4GA  +: 2];
  assign l4gb_test_si  = blk_test_si[CB_L4GB  +: 2];
  assign pcia_test_si  = blk_test_si[CB_PCIA  +: 12];
  assign pcib_test_si  = blk_test_si[CB_PCIB  +: 12];
  assign ahb_test_si   = blk_test_si[CB_AHB   +: 6];
  assign apb_test_si   = blk_test_si[CB_APB   +: 4];
  assign axis_test_si  = blk_test_si[CB_AXIS  +: 8];
  assign axim_test_si  = blk_test_si[CB_AXIM  +: 4];

  // wrapper chains (lane b of mode 7 is block b's chain)
  assign scc_wrap_si   = blk_wrap_si[dft_part_map_pkg::BLK_SCC];
  assign hic_wrap_si   = blk_wrap_si[dft_part_map_pkg::BLK_HIC];
  assign g2muc_wrap_si = blk_wrap_si[dft_part_map_pkg::BLK_G2MUC];
  assign l4ga_wrap_si  = blk_wrap_si[dft_part_map_pkg::BLK_L4GA];
  assign l4gb_wrap_si  = blk_wrap_si[dft_part_map_pkg::BLK_L4GB];
  assign pcia_wrap_si  = blk_wrap_si[dft_part_map_pkg::BLK_PCIA];
  assign pcib_wrap_si  = blk_wrap_si[dft_part_map_pkg::BLK_PCIB];
  assign ahb_wrap_si   = blk_wrap_si[dft_part_map_pkg::BLK_AHB];
  assign apb_wrap_si   = blk_wrap_si[dft_part_map_pkg::BLK_APB];
  assign axis_wrap_si  = blk_wrap_si[dft_part_map_pkg::BLK_AXIS];
  assign axim_wrap_si  = blk_wrap_si[dft_part_map_pkg::BLK_AXIM];

  // The block-side returns, packed into the router's slots in block index
  // order (slot widths 6, 6, 8, 2, 2, 12, 12, 6, 4, 8, 4 from bit 0, the NCH
  // that g_map_check holds). Continuous assignments, so that no process is
  // sensitive to a whole port for one slice of it.
  assign blk_test_so = {axim_test_so, axis_test_so, apb_test_so, ahb_test_so,
                        pcib_test_so, pcia_test_so, l4gb_test_so, l4ga_test_so,
                        g2muc_test_so, hic_test_so, scc_test_so};   // 4+8+4+6+12+12+2+2+8+6+6 = 70

  // wrapper returns, bit b = block b
  assign blk_wrap_so = {axim_wrap_so, axis_wrap_so, apb_wrap_so, ahb_wrap_so,
                        pcib_wrap_so, pcia_wrap_so, l4gb_wrap_so, l4ga_wrap_so,
                        g2muc_wrap_so, hic_wrap_so, scc_wrap_so};

endmodule
