// dft_ddr_tdr -- the LPDDR phy0 and phy1 TDR bridge: the twelve
// capture/shift/update enables, the two WSI paths and the two pairs of TDO
// returns, named as the LPDDR block ports of sheet "SOC DFT to Block level
// Connect" rows 168-176 and 187-195 (the architect workbook of 25 Nov 2026).
//
// The twelve enables are registered, not combinational decodes of the TAP
// state, because the PHY samples them on TDRCLK and a decode would change
// while TDRCLK is high. The launch edge is P_TDR_EN_EDGE.
//
// TDRCLK and WRSTN are not made here. The sheet connects the LPDDR's TDRCLK
// to TCK1 (row 166) and its WRSTN to TRSTN1 (row 167): both are soc_dft input
// nets the chip top takes to the LPDDR directly, so this module has no clock
// gate and no reset synchroniser. Every enable and both WSI paths are held at
// 0 unless DTR_CFG.DDR_TDR_EN is set and a DDRx instruction is loaded, which
// is what keeps the PHY TDRs quiet.
//

module dft_ddr_tdr #(
    parameter bit P_TDR_EN_EDGE = 1'b1  // 1 = launch on falling TCK1
) (
    input  logic       tck1,
    input  logic       trstn1,
    input  logic       tdi,
    input  logic [3:0] tap_state,
    input  logic [4:0] ir,
    input  logic       ddr_tdr_en,
    // returns from the PHYs, into the TAP's DR multiplexer
    input  logic       phy0_DdrPhyCsrCmdTdr_Tdo,
    input  logic       phy0_DdrPhyCsrRdDataTdr_Tdo,
    input  logic       phy1_DdrPhyCsrCmdTdr_Tdo,
    input  logic       phy1_DdrPhyCsrRdDataTdr_Tdo,
    output logic       dr_tdo_ddr,
    // the TDR interface of phy0 (sheet rows 168-174)
    output logic       phy0_DdrPhyCsrCmdTdrCaptureEn,
    output logic       phy0_DdrPhyCsrCmdTdrShiftEn,
    output logic       phy0_DdrPhyCsrCmdTdrUpdateEn,
    output logic       phy0_DdrPhyCsrRdDataTdrCaptureEn,
    output logic       phy0_DdrPhyCsrRdDataTdrShiftEn,
    output logic       phy0_DdrPhyCsrRdDataTdrUpdateEn,
    output logic       phy0_WSI,
    // the TDR interface of phy1 (sheet rows 187-193)
    output logic       phy1_DdrPhyCsrCmdTdrCaptureEn,
    output logic       phy1_DdrPhyCsrCmdTdrShiftEn,
    output logic       phy1_DdrPhyCsrCmdTdrUpdateEn,
    output logic       phy1_DdrPhyCsrRdDataTdrCaptureEn,
    output logic       phy1_DdrPhyCsrRdDataTdrShiftEn,
    output logic       phy1_DdrPhyCsrRdDataTdrUpdateEn,
    output logic       phy1_WSI
);
  // ---------------------------------------------------------------------
  // Which TDR the loaded instruction addresses. There are four codes, one per
  // PHY per register (Table 46), and exactly one register is in the TDI-to-TDO
  // path at a time: the command and read-data TDRs of a PHY are separate
  // instructions, not one.
  // ---------------------------------------------------------------------
  logic ddr0_cmd_sel;
  logic ddr0_rd_sel;
  logic ddr1_cmd_sel;
  logic ddr1_rd_sel;

  assign ddr0_cmd_sel = (ir == dft_part_map_pkg::IR_DDR0_CMD);
  assign ddr0_rd_sel  = (ir == dft_part_map_pkg::IR_DDR0_RD);
  assign ddr1_cmd_sel = (ir == dft_part_map_pkg::IR_DDR1_CMD);
  assign ddr1_rd_sel  = (ir == dft_part_map_pkg::IR_DDR1_RD);

  // ---------------------------------------------------------------------
  // The twelve enables and both WSI paths follow the TAP at any DFTTM value
  // (architect decision 25 Nov 2026): the DDR PHY TDR access (DDR0/DDR1 CMD
  // and RD) works in functional and in test mode, gated only by
  // DTR_CFG.DDR_TDR_EN. So during scan the test program keeps TSEL1 != 11
  // (or TMS1 and TCK1 quiet), so that a TAP walk accesses neither the DTRs
  // nor the PHY TDRs in the middle of a pattern (8.1, 15.4). Change TSEL1
  // only with the selected TAP in Run-Test/Idle or Test-Logic-Reset; do not
  // use TRST1_n for this, because TRST1_n low also clears the DTRs.
  // ---------------------------------------------------------------------
  logic [11:0] tdr_en_d;
  logic [11:0] tdr_en_q;

  logic in_capture;
  logic in_shift;
  logic in_update;

  assign in_capture = (tap_state == dft_part_map_pkg::CAPTURE_DR);
  assign in_shift   = (tap_state == dft_part_map_pkg::SHIFT_DR);
  assign in_update  = (tap_state == dft_part_map_pkg::UPDATE_DR);

  always_comb begin
    tdr_en_d = '0;
    if (ddr_tdr_en) begin
      // bits 1:0 command capture, 3:2 command shift, 5:4 command update,
      // 7:6 read capture, 9:8 read shift, 11:10 read update; within each
      // pair bit 0 is phy0 and bit 1 is phy1.
      tdr_en_d[0]  = in_capture & ddr0_cmd_sel;
      tdr_en_d[1]  = in_capture & ddr1_cmd_sel;
      tdr_en_d[2]  = in_shift   & ddr0_cmd_sel;
      tdr_en_d[3]  = in_shift   & ddr1_cmd_sel;
      tdr_en_d[4]  = in_update  & ddr0_cmd_sel;
      tdr_en_d[5]  = in_update  & ddr1_cmd_sel;
      tdr_en_d[6]  = in_capture & ddr0_rd_sel;
      tdr_en_d[7]  = in_capture & ddr1_rd_sel;
      tdr_en_d[8]  = in_shift   & ddr0_rd_sel;
      tdr_en_d[9]  = in_shift   & ddr1_rd_sel;
      tdr_en_d[10] = in_update  & ddr0_rd_sel;
      tdr_en_d[11] = in_update  & ddr1_rd_sel;
    end
  end

  // The launch edge is a build-time choice, so both edges are written and one
  // is elaborated. Writing it as a clock expression instead would put a
  // parameter on a clock, which no lint flow accepts.
  if (P_TDR_EN_EDGE) begin : g_fall
    always_ff @(negedge tck1 or negedge trstn1) begin
      if (!trstn1) tdr_en_q <= '0;
      else         tdr_en_q <= tdr_en_d;
    end
  end else begin : g_rise
    always_ff @(posedge tck1 or negedge trstn1) begin
      if (!trstn1) tdr_en_q <= '0;
      else         tdr_en_q <= tdr_en_d;
    end
  end

  assign phy0_DdrPhyCsrCmdTdrCaptureEn    = tdr_en_q[0];
  assign phy1_DdrPhyCsrCmdTdrCaptureEn    = tdr_en_q[1];
  assign phy0_DdrPhyCsrCmdTdrShiftEn      = tdr_en_q[2];
  assign phy1_DdrPhyCsrCmdTdrShiftEn      = tdr_en_q[3];
  assign phy0_DdrPhyCsrCmdTdrUpdateEn     = tdr_en_q[4];
  assign phy1_DdrPhyCsrCmdTdrUpdateEn     = tdr_en_q[5];
  assign phy0_DdrPhyCsrRdDataTdrCaptureEn = tdr_en_q[6];
  assign phy1_DdrPhyCsrRdDataTdrCaptureEn = tdr_en_q[7];
  assign phy0_DdrPhyCsrRdDataTdrShiftEn   = tdr_en_q[8];
  assign phy1_DdrPhyCsrRdDataTdrShiftEn   = tdr_en_q[9];
  assign phy0_DdrPhyCsrRdDataTdrUpdateEn  = tdr_en_q[10];
  assign phy1_DdrPhyCsrRdDataTdrUpdateEn  = tdr_en_q[11];

  // ---------------------------------------------------------------------
  // The WSI path: TDI reaches the addressed PHY while its code is loaded. The
  // sheet gives each PHY one WSI (rows 174, 193), shared by its command and
  // read-data TDRs.
  // ---------------------------------------------------------------------
  assign phy0_WSI = (ddr_tdr_en && (ddr0_cmd_sel || ddr0_rd_sel)) ? tdi : 1'b0;
  assign phy1_WSI = (ddr_tdr_en && (ddr1_cmd_sel || ddr1_rd_sel)) ? tdi : 1'b0;

  // The return into the TAP's DR multiplexer: the one addressed TDR, or 0 when
  // no DDRx code is loaded. Written as a continuous assignment rather than a
  // process, because a process that bit-selects an input vector is sensitive
  // to every bit of it, which is both wasteful and a thing one of the flow's
  // front ends declines to model.
  assign dr_tdo_ddr = ddr0_cmd_sel ? phy0_DdrPhyCsrCmdTdr_Tdo
                    : ddr1_cmd_sel ? phy1_DdrPhyCsrCmdTdr_Tdo
                    : ddr0_rd_sel  ? phy0_DdrPhyCsrRdDataTdr_Tdo
                    : ddr1_rd_sel  ? phy1_DdrPhyCsrRdDataTdr_Tdo
                    : 1'b0;

endmodule
