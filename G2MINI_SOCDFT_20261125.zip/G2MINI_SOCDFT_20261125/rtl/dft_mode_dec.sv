// dft_mode_dec -- the combinational test-mode decoder: scan-mode select from
// DeMuxSel, the per-block two-bit test_mode from DTR_TM, and
// the three LPDDR statics soc_dft still drives (phy0_BurnIn, phy1_BurnIn and
// scan_ctl).
//
// It holds no state. The scan-mode outputs (sel, extest, loopback) and
// blk_test_mode are functions of DeMuxSel and the DTR_TM shadow only; DFTTM
// is not used for them here. The burn-in statics are functions of DFTTM and
// the DTR_CFG and DTR_LPDDR shadows.
//
// Sheet "SOC DFT to Block level Connect" rows 153-186: the LPDDR's
// compression_mode, atpg_mode, atpg_se[9:0] and scan_shift_cg are the
// DFTMAX, DFTTM and DFTSE pad nets themselves at the chip top, not soc_dft
// outputs, so this decoder drives none of them. DTR_LPDDR bits 3:0 and 17
// read back and drive nothing.
//
// There are no test-point enables, and DFTTM, DFTSE and DFTMAX reach no
// block control from here: the chip top takes DFTTM and DFTSE straight from
// the pads to the blocks. DFTTM and DFTSE are not used inside this decoder
// except in the LPDDR statics section; soc_dft applies DFTTM to the decoded
// outputs.
//
// Invariants: (nothing moves while DFTTM is low; it holds because
// soc_dft gates these outputs with DFTTM, and the LPDDR statics here keep
// their own DFTTM terms).

module dft_mode_dec (
    input  logic        tm,
    input  logic [31:0] dtr_cfg,
    input  logic [31:0] dtr_lpddr,
    // the scan-mode select from the DeMuxSel pads; the DTR_TM shadow
    input  logic [2:0]  demux_sel,
    input  logic [31:0] dtr_tm,
    // the scan-mode state, published for the router
    output logic [12:0] sel,
    output logic        extest,
    output logic        loopback,
    // The eleven two-bit test_mode codes, packed low block first. A
    // packed vector rather than an unpacked array because an unpacked array
    // port is not read by every front end the checks run.
    output logic [21:0] blk_test_mode,
    // LPDDR statics
    output logic        lpddr_phy0_burnin,
    output logic        lpddr_phy1_burnin,
    output logic [1:0]  lpddr_scan_ctl
);
  // ---------------------------------------------------------------------
  // The configuration fields this decoder reads.
  // ---------------------------------------------------------------------
  logic burnin;

  assign burnin  = dtr_cfg[dft_part_map_pkg::CFG_BURNIN];

  // ---------------------------------------------------------------------
  // Scan-mode decode. DeMuxSel picks one of the eight modes of sheet
  // "Scan Test Modes" rows 4-11. A block is selected when the INTEST mode 1-6
  // names it. Mode 0 routes LPDDR only, on its own lanes; LPDDR's select bit
  // stays 0. The LPDDR's atpg_mode, atpg_se and scan_shift_cg are the DFTTM
  // and DFTSE pads themselves (sheet rows 156, 157, 186), so mode 0 is a
  // working LPDDR scan mode without any decode here. DeMuxSel is used as it
  // stands; it is taken as static during a pattern.
  // No DFTTM term here: soc_dft applies DFTTM to sel, extest and loopback.
  // ---------------------------------------------------------------------
  assign extest   = (demux_sel == dft_part_map_pkg::SMODE_EXTEST);
  // the pad loopback is DTR_TM bit 22 (sheet "Scan Test Modes" row 30).
  assign loopback = dtr_tm[dft_part_map_pkg::TM_LOOPBACK];

  assign sel = dft_part_map_pkg::scan_mode_sel(demux_sel);

  // ---------------------------------------------------------------------
  // Per-block test_mode. Each block's two bits are its two DTR_TM bits, in the
  // bit map of sheet "Scan Test Modes" rows 17-31, passed through unchanged
  // (the block-level table of that sheet: 00 internal scan, 01 wrp_if, 10
  // wrp_if_comp, 11 wrp_of). soc_dft holds them at 00 while DFTTM is low
  // ---------------------------------------------------------------------
  assign blk_test_mode = dtr_tm[dft_part_map_pkg::TM_MODE_HI:dft_part_map_pkg::TM_MODE_LO];

  // DTR_TM bits 31:23 read 0 and carry nothing; one deliberate sink, as the
  // SMS shell uses for its contracted inputs (rtl/dft_sms_srv.sv).
  logic unused_dtr_tm_high;
  assign unused_dtr_tm_high = ^{1'b0, dtr_tm[31:dft_part_map_pkg::TM_LOOPBACK+1]};

  // ---------------------------------------------------------------------
  // LPDDR statics soc_dft still drives: scan_ctl, phy0_BurnIn and phy1_BurnIn
  // (connect sheet rows 177, 178, 196).
  // ---------------------------------------------------------------------
  // DTR_LPDDR bits 3:0 (the atpg_mode and compression overrides) and 17 (the
  // scan_shift_cg override) have no output: the LPDDR takes
  // those controls from the pads directly. They stay in the register and read
  // back; one deliberate sink reads them, as rtl/dft_sms_srv.sv does for its
  // contracted inputs.
  logic unused_lpddr_ovr_bits;
  assign unused_lpddr_ovr_bits = ^{1'b0,
      dtr_lpddr[dft_part_map_pkg::LP_ATPG_MODE_OVR], dtr_lpddr[dft_part_map_pkg::LP_ATPG_MODE_VAL],
      dtr_lpddr[dft_part_map_pkg::LP_COMP_OVR], dtr_lpddr[dft_part_map_pkg::LP_COMP_VAL],
      dtr_lpddr[dft_part_map_pkg::LP_SCAN_SHIFT_CG_OVR]};

  // the burn-in controls need DFTTM, DTR_CFG.BURNIN and the
  // per-PHY bit of DTR_LPDDR, so no single bit can put a PHY into burn-in.
  assign lpddr_phy0_burnin = tm & burnin & dtr_lpddr[dft_part_map_pkg::LP_PHY0_BURNIN];
  assign lpddr_phy1_burnin = tm & burnin & dtr_lpddr[dft_part_map_pkg::LP_PHY1_BURNIN];

  // tied off because ASST is not used.
  assign lpddr_scan_ctl = 2'b00;

  // The LPDDR scan reset is driven by dft_crg_ctl, which owns
  // the reset path and holds the library mux cell that selects it.

endmodule
