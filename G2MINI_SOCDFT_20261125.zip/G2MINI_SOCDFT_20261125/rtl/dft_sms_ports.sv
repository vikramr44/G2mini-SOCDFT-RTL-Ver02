// dft_sms_ports -- the SMS wrapper ports of sheet "SOC DFT to Block level
// Connect" (the architect workbook of 25 Nov 2026), between the SMS shell
// (dft_sms_srv) and the block pins.
//
// What is done here, and only this: the sheet's names and directions for every
// wrapper the sheet lists, one set per block instance, and the LPDDR
// sub-server's two DTR_LPDDR statics (ring_bypass, sfp_dft_mode). Each
// wrapper's five controls come from the shell's packed bus ([0] WSI,
// [1] SelectWIR, [2] ShiftWR, [3] CaptureWR, [4] UpdateWR); each WSO goes back
// to the shell. The index_based_repair controls have no source in the shell
// and are held at 0, the stub's idle value; TopG2mL4ga_1,
// TopG2mL4gb_1 and the LPDDR sub-server have none in the sheet.
//
// The shell is still the verification stub (open: the generated SMS server
// is not in this copy), so every control is 0; this module fixes the names
// and the connection.

module dft_sms_ports (
    // from and to the SMS shell
    input  logic [9:0] pcia_sms_in,
    output logic [1:0] pcia_sms_out,
    input  logic [9:0] pcib_sms_in,
    output logic [1:0] pcib_sms_out,
    input  logic [9:0] g2muc_sms_in,
    output logic [1:0] g2muc_sms_out,
    input  logic [4:0] l4ga_sms_in,
    output logic       l4ga_sms_out,
    input  logic [4:0] l4gb_sms_in,
    output logic       l4gb_sms_out,
    input  logic [4:0] scc_sms_in,
    output logic       scc_sms_out,
    input  logic [4:0] hic_sms_in,
    output logic       hic_sms_out,
    input  logic [4:0] ahb_sms_in,
    output logic       ahb_sms_out,
    input  logic [4:0] ddr_sms_in,
    output logic       ddr_sms_out,
    // the LPDDR sub-server statics, from DTR_LPDDR
    input  logic [6:0] lpddr_ring_bypass,
    input  logic       lpddr_sfp_dft_mode,
    // TopG2mPcia_1 (sheet rows 39-45)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_index_based_repair,
    // TopG2mPcia_2 (sheet rows 46-52)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_index_based_repair,
    // TopG2mPcib_1 (sheet rows 207-213)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_index_based_repair,
    // TopG2mPcib_2 (sheet rows 214-220)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_index_based_repair,
    // TopGucc_1 (sheet rows 68-74)
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair,
    // TopGucc_2 (sheet rows 75-81)
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair,
    // TopG2mL4ga_1 (sheet rows 97-102)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_UpdateWR,
    // TopG2mL4gb_1 (sheet rows 260-265)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_UpdateWR,
    // TopG2mScc_1 (sheet rows 114-120)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mScc_1_index_based_repair,
    // TopG2mHic_1 (sheet rows 237-243)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mHic_1_index_based_repair,
    // TopG2mAhb_1 (sheet rows 138-144)
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSI,
    input  logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSO,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_SelectWIR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_ShiftWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_CaptureWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_UpdateWR,
    output logic       vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_index_based_repair,
    // LPDDR sub-server (sheet rows 158-165)
    output logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSI,
    input  logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSO,
    output logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_SelectWIR,
    output logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_ShiftWR,
    output logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_CaptureWR,
    output logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_UpdateWR,
    output logic [6:0] vl_srv_u_sms_sub_server_snps_ddr_subsystem_ring_bypass,
    output logic       vl_srv_u_sms_sub_server_snps_ddr_subsystem_sfp_dft_mode
);

  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSI = pcia_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_SelectWIR = pcia_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_ShiftWR = pcia_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_CaptureWR = pcia_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_UpdateWR = pcia_sms_in[4];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSI = pcia_sms_in[5];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_SelectWIR = pcia_sms_in[6];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_ShiftWR = pcia_sms_in[7];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_CaptureWR = pcia_sms_in[8];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_UpdateWR = pcia_sms_in[9];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSI = pcib_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_SelectWIR = pcib_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_ShiftWR = pcib_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_CaptureWR = pcib_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_UpdateWR = pcib_sms_in[4];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSI = pcib_sms_in[5];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_SelectWIR = pcib_sms_in[6];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_ShiftWR = pcib_sms_in[7];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_CaptureWR = pcib_sms_in[8];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_UpdateWR = pcib_sms_in[9];
  assign vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_WSI = g2muc_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_SelectWIR = g2muc_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_ShiftWR = g2muc_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_CaptureWR = g2muc_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_UpdateWR = g2muc_sms_in[4];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_1_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_WSI = g2muc_sms_in[5];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_SelectWIR = g2muc_sms_in[6];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_ShiftWR = g2muc_sms_in[7];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_CaptureWR = g2muc_sms_in[8];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_UpdateWR = g2muc_sms_in[9];
  assign vl_sms_u_1_sms_sram_proc_TopGucc_2_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSI = l4ga_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_SelectWIR = l4ga_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_ShiftWR = l4ga_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_CaptureWR = l4ga_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_UpdateWR = l4ga_sms_in[4];

  assign vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSI = l4gb_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_SelectWIR = l4gb_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_ShiftWR = l4gb_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_CaptureWR = l4gb_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_UpdateWR = l4gb_sms_in[4];

  assign vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSI = scc_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mScc_1_SelectWIR = scc_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mScc_1_ShiftWR = scc_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mScc_1_CaptureWR = scc_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mScc_1_UpdateWR = scc_sms_in[4];
  assign vl_sms_u_1_sms_sram_proc_TopG2mScc_1_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSI = hic_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mHic_1_SelectWIR = hic_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mHic_1_ShiftWR = hic_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mHic_1_CaptureWR = hic_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mHic_1_UpdateWR = hic_sms_in[4];
  assign vl_sms_u_1_sms_sram_proc_TopG2mHic_1_index_based_repair = 1'b0;

  assign vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSI = ahb_sms_in[0];
  assign vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_SelectWIR = ahb_sms_in[1];
  assign vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_ShiftWR = ahb_sms_in[2];
  assign vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_CaptureWR = ahb_sms_in[3];
  assign vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_UpdateWR = ahb_sms_in[4];
  assign vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_index_based_repair = 1'b0;

  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSI = ddr_sms_in[0];
  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_SelectWIR = ddr_sms_in[1];
  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_ShiftWR = ddr_sms_in[2];
  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_CaptureWR = ddr_sms_in[3];
  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_UpdateWR = ddr_sms_in[4];
  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_ring_bypass = lpddr_ring_bypass;
  assign vl_srv_u_sms_sub_server_snps_ddr_subsystem_sfp_dft_mode = lpddr_sfp_dft_mode;

  // the WSO returns, back to the shell
  assign pcia_sms_out = {vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_WSO, vl_sms_u_1_sms_sram_proc_TopG2mPcia_1_WSO};
  assign pcib_sms_out = {vl_sms_u_1_sms_sram_proc_TopG2mPcib_2_WSO, vl_sms_u_1_sms_sram_proc_TopG2mPcib_1_WSO};
  assign g2muc_sms_out = {vl_sms_u_1_sms_sram_proc_TopGucc_2_WSO, vl_sms_u_1_sms_sram_proc_TopGucc_1_WSO};
  assign l4ga_sms_out = vl_sms_u_1_sms_sram_proc_TopG2mL4ga_1_WSO;
  assign l4gb_sms_out = vl_sms_u_1_sms_sram_proc_TopG2mL4gb_1_WSO;
  assign scc_sms_out = vl_sms_u_1_sms_sram_proc_TopG2mScc_1_WSO;
  assign hic_sms_out = vl_sms_u_1_sms_sram_proc_TopG2mHic_1_WSO;
  assign ahb_sms_out = vl_sms_u_1_sms_sram_proc_TopG2mAhb_1_WSO;
  assign ddr_sms_out = vl_srv_u_sms_sub_server_snps_ddr_subsystem_WSO;

endmodule
