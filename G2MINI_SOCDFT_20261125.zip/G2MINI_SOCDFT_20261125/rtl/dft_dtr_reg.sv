// dft_dtr_reg -- the generic JTAG data-register engine of SOC_DFT. One shift
// stage on the rising TCK1 edge, one shadow stage loaded at Update-DR on the
// falling edge, and a capture of either the shadow (a configuration register)
// or a status input (a capture-only register).
//
// All three DFT test registers are instances of this one module, so the shift,
// capture and update behaviour cannot drift between them.
//
// Invariants: (the shadows change only at Update-DR, on rst_dtr_n, or on
// CLR, at any DFTTM value), (CLR reads back 0).

module dft_dtr_reg #(
    parameter int unsigned P_WIDTH   = 32,
    // 1 = the register has a shadow stage and captures it (DTR_CFG, DTR_LPDDR, DTR_TM)
    // 0 = capture only, from capture_value (DTR_STS)
    parameter bit          P_HAS_SHADOW = 1'b1,
    parameter logic [31:0] P_RESET   = 32'h0000_0000,
    // the bits the shadow holds; the rest read 0, which is how a reserved
    // field and the self-clearing CLR bit return 0
    parameter logic [31:0] P_MASK    = 32'hFFFF_FFFF
) (
    input  logic               tck1,
    input  logic               rst_dtr_n,
    input  logic               tdi,
    // decoded strobes from the TAP, already qualified with this register's
    // instruction match
    input  logic               sel,
    input  logic               capture_dr,
    input  logic               shift_dr,
    input  logic               update_dr,
    // the value a capture-only register loads
    input  logic [P_WIDTH-1:0] capture_value,
    // a synchronous clear request, taken from the shift stage at Update-DR
    input  logic               clr_req,
    output logic [P_WIDTH-1:0] shadow,
    // the shift stage itself, for the one bit that is acted on at Update-DR
    // from the written word rather than from the shadow (DTR_CFG.CLR)
    output logic [P_WIDTH-1:0] sr_value,
    output logic               dr_tdo
);

  logic [P_WIDTH-1:0] sr_q;
  logic [P_WIDTH-1:0] shadow_q;

  // ---------------------------------------------------------------------
  // The shift stage. Rising edge, LSB first toward TDO. It carries no reset:
  // it is loaded at Capture-DR before any shift can reach TDO, and the TAP's
  // TDO stage holds its value outside the shift states.
  // ---------------------------------------------------------------------
  always_ff @(posedge tck1) begin
    if (sel && capture_dr) begin
      sr_q <= P_HAS_SHADOW ? shadow_q : capture_value;
    end else if (sel && shift_dr) begin
      sr_q <= {tdi, sr_q[P_WIDTH-1:1]};
    end
  end

  assign dr_tdo   = sr_q[0];
  assign sr_value = sr_q;

  // ---------------------------------------------------------------------
  // The shadow stage. Falling edge at Update-DR, at any DFTTM value: DTR_CFG,
  // DTR_LPDDR and DTR_TM are writable and readable in functional and in test
  // mode (architect decision 25 Nov 2026). Because a write can now land in
  // test, the test program keeps the DTRs from being rewritten during scan:
  // TSEL1 != 11 (or TMS1 and TCK1 quiet) during scan, and TRST1_n high.
  // Change TSEL1 only with the selected TAP in Run-Test/Idle or
  // Test-Logic-Reset; do not use TRST1_n for this, because TRST1_n low also
  // clears the DTRs.
  //
  // CLR is synchronous and returns this register and the other configuration
  // registers (DTR_CFG, DTR_LPDDR, DTR_TM) to their reset values, also at any
  // DFTTM value; each instance receives the same clr_req.
  // ---------------------------------------------------------------------
  if (P_HAS_SHADOW) begin : g_shadow
    always_ff @(negedge tck1 or negedge rst_dtr_n) begin
      if (!rst_dtr_n) begin
        shadow_q <= P_RESET[P_WIDTH-1:0] & P_MASK[P_WIDTH-1:0];
      end else if (update_dr) begin
        if (clr_req) shadow_q <= P_RESET[P_WIDTH-1:0] & P_MASK[P_WIDTH-1:0];
        else if (sel) shadow_q <= sr_q & P_MASK[P_WIDTH-1:0];
      end
    end
  end else begin : g_no_shadow
    // A capture-only register has no shadow. Its output is tied to its reset
    // value so that every bit of the module's interface is defined; nothing
    // reads it.
    assign shadow_q = P_RESET[P_WIDTH-1:0] & P_MASK[P_WIDTH-1:0];

    // rst_dtr_n, update_dr and clr_req are the three controls the shadow
    // stage above reads on every load. They are ports of this module
    // whichever way it is built -- the u_cfg and u_lpddr instances and the
    // DTR_TM instance (u_tm in dft_dtr_tm) read all three -- and in this elaboration the stage they belong to is gone, so
    // nothing reads them here. One deliberate sink reads them, named for
    // what it is: the same device the SMS shell uses for its contracted
    // inputs (rtl/dft_sms_srv.sv), and for the same reason. The sink is
    // combinational, drives nothing, and synthesises away; what it buys is
    // that an unread port of this module is a report worth keeping, because
    // the ports that are unread by construction are read here on purpose.
    logic unused_no_shadow_controls;
    assign unused_no_shadow_controls = ^{1'b0, rst_dtr_n, update_dr,
                                         clr_req};
  end

  assign shadow = shadow_q;

endmodule
