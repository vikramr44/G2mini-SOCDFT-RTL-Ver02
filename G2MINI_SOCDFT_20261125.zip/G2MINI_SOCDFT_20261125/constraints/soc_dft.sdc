# soc_dft.sdc -- the one top-level SDC of SOC_DFT (constraints are one
# top-level SDC under constraints/, and rtl/ holds RTL only).
#
# Scope: the block-level constraints of SOC_DFT. The chip top owns the pad
# constraints, the functional clocks and the inter-block budgets; nothing here
# describes anything outside u_soc_dft.
#
# The numbers come from the specification: TCK1 at 20 MHz maximum (50 ns), and
# 10 MHz (100 ns) while the instruction register holds a DDRx code, because the
# PHY's TDR path is slower (24.7).
#
# TCK1 is 20 MHz (50 ns) by default. For the 10 MHz TDR mode, set
# TCK1_PERIOD_NS to $TCK1_TDR_PERIOD_NS (100) before reading this file. The
# frequency is a constraint, not RTL: nothing in rtl/ divides, multiplies or
# selects TCK1, and soc_dft holds no clock mux or PLL logic (sheet "DFT clock
# architecture").

if {![info exists TCK1_PERIOD_NS]} { set TCK1_PERIOD_NS 50.0 }
set TCK1_TDR_PERIOD_NS  100.0

# ---------------------------------------------------------------------------
# Clocks
# ---------------------------------------------------------------------------
# TCK1 is the only clock entering SOC_DFT. It is not buffered in RTL: the
# chip-top clock tree drives it. Inside SOC_DFT it clocks the SMS server shell
# (u_sms_srv), the TAP, the DTRs and the LPDDR TDR enables. The same chip net
# is each block's SMS wrapper clock (the blocks' TCK1 pins, connect sheet rows
# 53, 82, 103, 121, 145, 221, 244, 266) and the LPDDR's TDRCLK (row 166); those
# loads are outside u_soc_dft and the chip-top SDC times them on this clock.
create_clock -name TCK1 -period $TCK1_PERIOD_NS [get_ports TCK1]

# There is no generated clock: the sheet joins the LPDDR's TDRCLK to TCK1
# itself, and SOC_DFT holds no clock gate.

# The two edges of TCK1 are both used: shift stages launch on the rising edge
# and the update stages, the TDO retime and the TDR enable launch on the
# falling edge. That is one clock with both edges, not two clocks, so no
# exception is needed between them.

# ---------------------------------------------------------------------------
# Input and output delays at the SOC_DFT boundary
# ---------------------------------------------------------------------------
# TMS1 and TDI1 are driven by the tester through the pads and are sampled on
# the rising TCK1 edge; TDO1 is launched on the falling edge. The budgets are
# a quarter period each way, which is what the 1149.1 timing of 24.7 allows.
set_input_delay  -clock TCK1 [expr {$TCK1_PERIOD_NS / 4}] [get_ports {TMS1 TDI1}]
set_output_delay -clock TCK1 -clock_fall [expr {$TCK1_PERIOD_NS / 4}] \
    [get_ports {TDO1 TDO1_OE}]

# JTAG1 feed-through (sheet "JTAG1 Logic"): TMS to each external TAP, each TAP's
# TDO and TDO enable back to the pad, all combinational inside SOC_DFT.
set_max_delay [expr {$TCK1_PERIOD_NS / 4}] -from [get_ports TMS1] \
    -to [get_ports {arc_tms1 pcia_tms1 pcib_tms1}]
set_max_delay [expr {$TCK1_PERIOD_NS / 4}] \
    -from [get_ports {arc_tdo1 arc_tdo1_oe pcia_tdo1 pcia_tdo1_oe pcib_tdo1 pcib_tdo1_oe}] \
    -to [get_ports {TDO1 TDO1_OE}]
set_max_delay [expr {$TCK1_PERIOD_NS / 2}] -from [get_ports DFTSE] -to [get_ports top_scan_shift_en]

# The LPDDR PHY TDR interface. The twelve enables launch on
# the falling TCK1 edge (P_TDR_EN_EDGE = 1) and the PHY samples them on TDRCLK,
# which is TCK1; WSI is TDI through the SMS stub, launched on the falling edge;
# the four TDO returns are sampled on the rising edge by the TAP's DR stage.
set_output_delay -clock TCK1 -clock_fall [expr {$TCK1_PERIOD_NS / 4}] \
    [get_ports {phy0_DdrPhyCsr*En phy1_DdrPhyCsr*En phy0_WSI phy1_WSI}]
set_input_delay  -clock TCK1 [expr {$TCK1_PERIOD_NS / 4}] \
    [get_ports {phy0_DdrPhyCsr*_Tdo phy1_DdrPhyCsr*_Tdo}]

# The scan channels are timed by the block's own test clock at the chip top,
# not by TCK1. Inside SOC_DFT the scan path is purely combinational (12.8: no
# retiming flop on any scan path), so these ports carry no clock of their own
# and the chip top budgets them.
set_max_delay [expr {$TCK1_PERIOD_NS / 2}] \
    -from [get_ports DFTSI] -to [get_ports DFTSO]
# The same budget for the routed halves: DFTSI to each
# block scan-in, and each block scan-out to DFTSO.
set_max_delay [expr {$TCK1_PERIOD_NS / 2}] -from [get_ports DFTSI] \
    -to [get_ports {*_test_si *_wrap_si ddr_test_si}]
set_max_delay [expr {$TCK1_PERIOD_NS / 2}] \
    -from [get_ports {*_test_so *_wrap_so ddr_test_so}] -to [get_ports DFTSO]

# ---------------------------------------------------------------------------
# Static test configuration
# ---------------------------------------------------------------------------
# These pins are static for a test session: they are changed only with the
# design idle, and no pattern times a path from them. Declaring them false
# rather than leaving them unconstrained says which fact makes them safe.
# Change TSEL1 only with the selected TAP in Run-Test/Idle or
# Test-Logic-Reset; do not use TRST1_n for this, because TRST1_n low also
# clears the DTRs.
set_false_path -from [get_ports {DFTTM DFTMAX TSEL1}]

# The DTR-driven statics: the eleven test_mode codes,
# the LPDDR SMS mode bits, ring bypass, sfp_dft_mode and burn-in controls. They
# move only at an Update-DR with the design idle and are static for a pattern.
set_false_path -to [get_ports {*_test_mode sms_dm0 sms_dm1 sms_dm2 \
    vl_srv_u_sms_sub_server_snps_ddr_subsystem_ring_bypass* \
    vl_srv_u_sms_sub_server_snps_ddr_subsystem_sfp_dft_mode \
    phy0_BurnIn phy1_BurnIn scan_ctl*}]

# DeMuxSel[2:0] selects the scan mode for the scan routing. It is static
# during a pattern: changed only between patterns, with the design idle, so
# no pattern times a path from it.
set_false_path -from [get_ports {DeMuxSel}]

# DFTSE is dynamic within a session: it is the shift enable and it does time.
# It is deliberately NOT in the list above.

# ---------------------------------------------------------------------------
# Resets
# ---------------------------------------------------------------------------
# TRSTN1 is asynchronous in both directions, as 1149.1 specifies for a TAP
# reset. PwrOk and Rstn are asynchronous chip-level levels. Each reaches its
# destination domain through a library synchroniser cell, so the crossing is
# the cell's and the path into it is not timed. The LPDDR's WRSTN is TRSTN1
# itself at the chip top (connect sheet row 167), and its
# rst_n and scan_resetn are the test reset mux outputs of u_crg_ctl, asynchronous
# levels like Rstn.
set_false_path -from [get_ports {TRSTN1 PwrOk Rstn}]
set_false_path -to [get_ports {rst_n scan_resetn}]

# ---------------------------------------------------------------------------
# Clock-domain crossings
# ---------------------------------------------------------------------------
# PwrOk and TRSTN1 into TCK1, through u_pad_if/u_dft_mux2_dtr_arst_dont_touch
#        and u_pad_if/u_dft_reset_sync_rst_dtr_dont_touch.
# The eight DTR_STS levels into TCK1, through
#        u_dtr/u_dft_sync2_sts_dont_touch.
#
# The data path into the first flop of each synchroniser is the crossing and is
# not timed; the path between the two flops of a synchroniser IS timed, because
# that is what gives the cell its settling time.
set_false_path -to [get_pins u_pad_if/u_dft_reset_sync_rst_dtr_dont_touch/arst_n]
set_false_path -to [get_pins u_dtr/u_dft_sync2_sts_dont_touch/d*]

# There is no second clock inside SOC_DFT to group.

# ---------------------------------------------------------------------------
# The slower TDR mode
# ---------------------------------------------------------------------------
# While the IR holds a DDRx code the tester runs TCK1 at 10 MHz. That is a
# second STA mode: for the 10 MHz TDR mode, set TCK1_PERIOD_NS to
# $TCK1_TDR_PERIOD_NS (100) before reading this file, and the default at the
# top keeps that value. It is not a second clock in this mode. The mode list
# and its scope are in 24.7.

# ---------------------------------------------------------------------------
# Technology cells
# ---------------------------------------------------------------------------
# Every instance below is a technology cell carried through synthesis, scan
# insertion and place-and-route. The name ends in _dont_touch so that the
# constraint and the netlist name the same object (24.11).
set_dont_touch [get_cells u_crg_ctl/u_dft_mux2_rst_dont_touch]
set_dont_touch [get_cells u_crg_ctl/u_dft_mux2_scan_rstn_dont_touch]
set_dont_touch [get_cells u_pad_if/u_dft_mux2_dtr_arst_dont_touch]
set_dont_touch [get_cells u_pad_if/u_dft_reset_sync_rst_dtr_dont_touch]
set_dont_touch [get_cells u_dtr/u_dft_sync2_sts_dont_touch]

# The hierarchy itself is kept (u_soc_dft is dont_touch): that is set in the
# chip-top SDC, where the instance exists.
