"""Port-list check of rtl/soc_dft.sv against the "SOC DFT PORT NAME" column of sheet
"SOC DFT to Block level Connect" of the architect workbook (25 Nov 2026), and of
constraints/soc_dft.sdc against the port list.

Usage: python dv_dir/check_ports.py [<workbook.xlsx>]
The workbook is read from the path given, else from the environment variable
SOC_DFT_SHEET; with neither, the sheet part is skipped and reported as such.

Recorded readings of the sheet:
  SHEET_NOT_PORT  names in the column that are not soc_dft ports
  SHEET_ALIAS     a name the sheet misspells, read as the name it stands for
  PORT_NOT_SHEET  soc_dft ports the column does not list, and the sheet that names them
Also keeps the 18 Nov rule: no output matching *wrap*shift*, *dfttm* or *scan_shift_en*
other than top_scan_shift_en.
Prints TEST START / CHECK FAIL / PT / TEST PASS|FAIL lines like the bench.
"""
import fnmatch
import os
import re
import sys

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHEET = "SOC DFT to Block level Connect"
SHEET_NOT_PORT = {
    "TRST1_n": "hidden row 127 repeats TRSTN1 -> TRST1_n; TRSTN1 is the soc_dft port",
    "PClk": "LPDDR atpg_PClk; the clock sheet draws Pclk from the PLL mux, not through SOC DFT",
    "UcClk": "LPDDR atpg_UcClk; the clock sheet draws Uclk from the PLL mux, not through SOC DFT",
    "atpg_DlyTestClk": "'Need clarity from LPDDR team' (row 181); not through SOC DFT",
    "atpg_RDQSClk": "'Need clarity from LPDDR team' (row 183); not through SOC DFT",
    "atpg_TxDllClk": "'Need clarity from LPDDR team' (row 184); not through SOC DFT",
    "gucc_tdo1": "ARC daisy-chain net GUCC -> SCC (rows 86, 124); sheet JTAG1 returns arc_tdo1 only",
    "scc_tdo1": "ARC daisy-chain net SCC -> HIC (rows 125, 247); sheet JTAG1 returns arc_tdo1 only",
}
SHEET_ALIAS = {
    "vl_sms_u_1_sms_sram_proc_TopG2mPci_2a_index_based_repair":
        "vl_sms_u_1_sms_sram_proc_TopG2mPcia_2_index_based_repair",   # row 52
}
PORT_NOT_SHEET = {
    "DFTSI": "sheet SOC_DFT r0.62", "DFTSO": "sheet SOC_DFT r0.62", "DeMuxSel": "sheet SOC_DFT r0.62",
    "TSEL1": "sheet JTAG1 Logic", "TMS1": "sheet JTAG1 Logic", "TDO1": "sheet JTAG1 Logic",
    "TDO1_OE": "sheet JTAG1 Logic", "DFTSO_OE": "DFTSO pad enable", "PwrOk": "DTR power-on reset",
    "Rstn": "source of the LPDDR rst_n", "top_scan_shift_en": "18 Nov architect decision",
}
SKIP = {"Driven from the PAD", "SOC DFT  PORT NAME", "SOC DFT PORTS"}

checks = fails = 0


def chk(ok, msg):
    global checks, fails
    checks += 1
    if not ok:
        fails += 1
        print(f"CHECK FAIL t_port_list: {msg}")


print("TEST START t_port_list")
t = open(os.path.join(PKG, "rtl", "soc_dft.sv"), encoding="utf-8").read()
hdr = t[t.index("module soc_dft"):]
hdr = hdr[hdr.index(") (") + 3:]
hdr = hdr[:hdr.index(");")]
ports = {}
for d, hi, lo, n in re.findall(r"^\s*(input|output|inout)\s+logic\s*(?:\[(\d+):(\d+)\])?\s*(\w+)", hdr, re.M):
    ports[n] = (d, int(hi) - int(lo) + 1 if hi else 1)
chk(len(ports) > 0, "no ports read from rtl/soc_dft.sv")

xlsx = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("SOC_DFT_SHEET", "")
if xlsx and os.path.isfile(xlsx):
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True)
    ws = wb[SHEET]
    sheet = {}
    for rno, row in enumerate(ws.iter_rows(min_row=1, values_only=True), start=1):
        a, c = row[0], (row[1] if len(row) > 1 else None)
        if c is None or a is not None:       # column A numbers the block title rows
            continue
        s = str(c).strip()
        if not s or s in SKIP:
            continue
        m = re.fullmatch(r"(\w+)\s*(?:\[(\d+):(\d+)\])?", s)
        chk(m is not None, f"sheet row {rno}: cannot read port name {s!r}")
        if not m:
            continue
        name = SHEET_ALIAS.get(m.group(1), m.group(1))
        w = int(m.group(2)) - int(m.group(3)) + 1 if m.group(2) else 1
        if name in sheet and sheet[name][0] != w:
            chk(False, f"sheet gives {name} two widths ({sheet[name][0]}, {w})")
        sheet.setdefault(name, (w, rno))
    for n, (w, r) in sorted(sheet.items()):
        if n in SHEET_NOT_PORT:
            chk(n not in ports, f"{n} (sheet row {r}) is a soc_dft port, but it is read as not one ({SHEET_NOT_PORT[n]})")
            continue
        chk(n in ports, f"sheet row {r}: {n} is not a soc_dft port")
        if n in ports:
            chk(ports[n][1] == w, f"sheet row {r}: {n} is {ports[n][1]} bits, the sheet says {w}")
    for n in sorted(ports):
        if n in sheet:
            continue
        chk(n in PORT_NOT_SHEET, f"soc_dft port {n} is not in the sheet column and nothing names it")
    for n in PORT_NOT_SHEET:
        chk(n in ports, f"{n} ({PORT_NOT_SHEET[n]}) was to be kept and is gone")
else:
    print("NOTE t_port_list: no workbook given (argument or SOC_DFT_SHEET); the sheet part is skipped")

outs = [n for n, (d, _) in ports.items() if d == "output"]
for pat in ("*wrap*shift*", "*dfttm*", "*scan_shift_en*"):
    hits = [n for n in outs if fnmatch.fnmatch(n.lower(), pat) and n != "top_scan_shift_en"]
    chk(not hits, f"outputs matching {pat}: {', '.join(hits)} (18 Nov rule)")

# SDC: every get_ports name or pattern names a port
sdc = open(os.path.join(PKG, "constraints", "soc_dft.sdc"), encoding="utf-8").read()
sdc = re.sub(r"#.*", "", sdc).replace("\\\n", " ")
for grp in re.findall(r"\[get_ports\s+\{?([^}\]]+)\}?\]", sdc):
    for tok in grp.split():
        hit = [n for n in ports if fnmatch.fnmatchcase(n, tok)]
        chk(bool(hit), f"constraints/soc_dft.sdc: get_ports {tok} matches no soc_dft port")

print(f"PT t_port_list checks={checks} cycles=0")
print(("TEST PASS" if fails == 0 else "TEST FAIL") + " t_port_list")
sys.exit(0)
