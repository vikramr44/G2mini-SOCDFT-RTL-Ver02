"""Generate dv_dir/tb_dir.sv: a self-checking directed bench for rtl/soc_dft.sv.

Expected values are written here from the architect workbook of 25 Nov 2026 and the
SOC_DFT block specification r0.92, never read from the RTL:
  sheet Connect = "SOC DFT to Block level Connect", sheet STM = "Scan Test Modes",
  sheet JTAG1 = "JTAG1 Logic" (row numbers are the sheet's own); spec = the block
  specification (section or table number).
Only the DUT's port names, directions and widths are read from rtl/soc_dft.sv, to declare
the bench signals; every port the tables below name must exist there with the width the
sheet gives, or generation stops. Two internal nets are probed by name: the SMS shell's
WSO inputs and its clock (u_dut.u_sms_srv), because the shell is a stub with no other
observable effect of them.

The lane positions inside a scan mode are this design's pin map: the sheet gives the lane
counts per mode only.

Usage: python dv_dir/gen_tb_dir.py
"""
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)

# ---- blocks in DTR_TM order (sheet STM rows 19-29: [1:0] scc ... [21:20] axim)
BLOCKS = ["scc", "hic", "g2muc", "l4ga", "l4gb", "pcia", "pcib", "ahb", "apb", "axis", "axim"]
# lane widths, sheet STM rows 5-10 and row 14 ("SI/SO of MCP and Axis to be 8")
NCH = {"scc": 6, "hic": 6, "g2muc": 8, "l4ga": 2, "l4gb": 2, "pcia": 12, "pcib": 12,
       "ahb": 6, "apb": 4, "axis": 8, "axim": 4}
# scan-in port of each block, its width and its row, sheet Connect column "SOC DFT PORT NAME"
PORT = {"scc": ("scc_test_si", 6, 107), "hic": ("hic_test_si", 6, 230),
        "g2muc": ("g2muc_test_si", 8, 61), "l4ga": ("l4ga_test_si", 2, 90),
        "l4gb": ("l4gb_test_si", 2, 253), "pcia": ("pcia_test_si", 12, 32),
        "pcib": ("pcib_test_si", 12, 200), "ahb": ("ahb_test_si", 6, 131),
        "apb": ("apb_test_si", 4, 23), "axis": ("axis_test_si", 8, 5), "axim": ("axim_test_si", 4, 14)}
WRAP = {"scc": ("scc_wrap_si", 112), "hic": ("hic_wrap_si", 235), "g2muc": ("g2muc_wrap_si", 66),
        "l4ga": ("l4ga_wrap_si", 95), "l4gb": ("l4gb_wrap_si", 258), "pcia": ("pcia_wrap_si", 37),
        "pcib": ("pcib_wrap_si", 205), "ahb": ("ahb_wrap_si", 136), "apb": ("apb_wrap_si", 28),
        "axis": ("axis_wrap_si", 10), "axim": ("axim_wrap_si", 19)}
TMPORT = {"scc": ("scc_test_mode", 111), "hic": ("hic_test_mode", 234), "g2muc": ("g2muc_test_mode", 65),
          "l4ga": ("L4ga_test_mode", 94), "l4gb": ("L4gb_test_mode", 257), "pcia": ("pciea_test_mode", 36),
          "pcib": ("pcieb_test_mode", 204), "ahb": ("ahb_test_mode", 135), "apb": ("apb_test_mode", 27),
          "axis": ("axis_test_mode", 9), "axim": ("axim_test_mode", 18)}
# modes: blocks and lowest lane (sheet STM rows 4-10 give the counts; this design's pin map:
# Axis on 7:0, the second-named block from lane 8, the first-named directly above it)
MODES = {
    0: [("lpddr", 0)],
    1: [("pcia", 8), ("axis", 0)],
    2: [("pcib", 8), ("axis", 0)],
    3: [("g2muc", 12), ("axim", 8), ("axis", 0)],
    4: [("l4ga", 14), ("ahb", 8), ("axis", 0)],
    5: [("l4gb", 12), ("apb", 8), ("axis", 0)],
    6: [("scc", 14), ("hic", 8), ("axis", 0)],
}
SRC = {0: "sheet STM row 4: mode 0 LPDDR 20", 1: "sheet STM row 5: Pciea + Axis 12, 8",
       2: "sheet STM row 6: Pcieb + Axis 12, 8", 3: "sheet STM row 7: Mcp + Axim + Axis 8, 4, 8",
       4: "sheet STM row 8: L4ga + Ahb + Axis 2, 6, 8", 5: "sheet STM row 9: L4gb + Apb + Axis 2, 4, 8",
       6: "sheet STM row 10: Scc + Hic + Axis 6, 6, 8", 7: "sheet STM row 11: all 11 blocks, 11, Extest"}
# SMS wrapper groups, one per block instance: (name, sheet Connect rows, has index_based_repair,
# the shell input that carries its WSO, bit or None)
SMS_PFX = "vl_sms_u_1_sms_sram_proc_"
SMS = [("TopG2mPcia_1", "39-45", True, "pcia_sms_out", 0), ("TopG2mPcia_2", "46-52", True, "pcia_sms_out", 1),
       ("TopG2mPcib_1", "207-213", True, "pcib_sms_out", 0), ("TopG2mPcib_2", "214-220", True, "pcib_sms_out", 1),
       ("TopGucc_1", "68-74", True, "g2muc_sms_out", 0), ("TopGucc_2", "75-81", True, "g2muc_sms_out", 1),
       ("TopG2mL4ga_1", "97-102", False, "l4ga_sms_out", None), ("TopG2mL4gb_1", "260-265", False, "l4gb_sms_out", None),
       ("TopG2mScc_1", "114-120", True, "scc_sms_out", None), ("TopG2mHic_1", "237-243", True, "hic_sms_out", None),
       ("TopG2mAhb_1", "138-144", True, "ahb_sms_out", None)]
SMS_CTL = ["WSI", "SelectWIR", "ShiftWR", "CaptureWR", "UpdateWR"]
SRV_PFX = "vl_srv_u_sms_sub_server_snps_ddr_subsystem_"   # sheet Connect rows 158-165 (sheet-mandated name)
# JTAG1 targets, sheet JTAG1 rows 41-63 and Connect rows 54, 57-58, 83, 122, 222, 225-226, 245, 248-249
JT = [("arc", 0), ("pcia", 1), ("pcib", 2)]

# ---- the observed vector: every scan-in port, every wrapper port, ddr_test_si
OBS = [PORT[b][0] for b in BLOCKS]
OBSW = {PORT[b][0]: PORT[b][1] for b in BLOCKS}
WOBS = [WRAP[b][0] for b in BLOCKS]
OFF, pos = {}, 0
for p in OBS:
    OFF[p] = pos
    pos += OBSW[p]
for p in WOBS:
    OFF[p] = pos
    pos += 1
OFF["ddr_test_si"] = pos
pos += 20
NOBS = pos


def lane_owner(m, i):
    """(block, channel) of lane i in mode m, or (None, None)."""
    for b, lo in MODES[m]:
        n = 20 if b == "lpddr" else NCH[b]
        if lo <= i < lo + n:
            return b, i - lo
    return None, None


def exp_obs(m, i):
    b, c = lane_owner(m, i)
    if b is None:
        return -1
    if b == "lpddr":
        return OFF["ddr_test_si"] + c
    return OFF[PORT[b][0]] + c


def ext_obs(i):
    return OFF[WRAP[BLOCKS[i]][0]] if i < 11 else -1


# ---- DUT ports, and the sheet's ports held to them
t = open(os.path.join(PKG, "rtl", "soc_dft.sv"), encoding="utf-8").read()
hdr = t[t.index("module soc_dft"):]
hdr = hdr[hdr.index(") (") + 3:]
hdr = hdr[:hdr.index(");")]
ports = re.findall(r"^\s*(input|output|inout)\s+logic\s*(\[[^\]]+\])?\s*(\w+)", hdr, re.M)
pdir = {n: d for d, _, n in ports}
pwid = {n: (int(re.match(r"\[(\d+):(\d+)\]", w).group(1)) - int(re.match(r"\[(\d+):(\d+)\]", w).group(2)) + 1) if w else 1
        for _, w, n in ports}


def need(name, d, w):
    assert name in pdir, f"sheet port {name} is not a soc_dft port"
    assert pdir[name] == d, f"sheet port {name} is {pdir[name]}, expected {d}"
    assert pwid[name] == w, f"sheet port {name} is {pwid[name]} bits, the sheet says {w}"


for b in BLOCKS:
    need(PORT[b][0], "output", PORT[b][1])
    need(PORT[b][0].replace("_si", "_so"), "input", PORT[b][1])
    need(WRAP[b][0], "output", 1)
    need(WRAP[b][0].replace("_si", "_so"), "input", 1)
    need(TMPORT[b][0], "output", 2)
for n, rows, rep, sh, bit in SMS:
    for c in SMS_CTL + (["index_based_repair"] if rep else []):
        need(SMS_PFX + n + "_" + c, "output", 1)
    need(SMS_PFX + n + "_WSO", "input", 1)
for c in SMS_CTL:
    need(SRV_PFX + c, "output", 1)
need(SRV_PFX + "WSO", "input", 1)
for tg, _ in JT:
    need(f"{tg}_tms1", "output", 1)
    need(f"{tg}_tdo1", "input", 1)
    need(f"{tg}_tdo1_oe", "input", 1)
need("ddr_test_si", "output", 20)
need("TSEL1", "input", 2)

PHY_EN = [f"phy{p}_DdrPhyCsr{r}Tdr{k}En" for p in (0, 1) for r in ("Cmd", "RdData")
          for k in ("Capture", "Shift", "Update")]
PHY_TDO = {(p, r): f"phy{p}_DdrPhyCsr{r}Tdr_Tdo" for p in (0, 1) for r in ("Cmd", "RdData")}
DDR_IR = [("5'b00101", 0, "Cmd", "spec Table 46: DDR0_CMD"),
          ("5'b00110", 0, "RdData", "spec Table 46: DDR0_RD"),
          ("5'b00111", 1, "Cmd", "spec Table 46: DDR1_CMD"),
          ("5'b01000", 1, "RdData", "spec Table 46: DDR1_RD")]
# DTR_TM's instruction code, assigned by the architect on 25 Nov 2026 (5'b01001 is now BYPASS)
TMIR = "5'b01010"
OUTS = [n for d, _, n in ports if d == "output"]
SMS_CTL_PORTS = [SMS_PFX + n + "_" + c for n, _, rep, _, _ in SMS for c in SMS_CTL + (["index_based_repair"] if rep else [])]
SRV_CTL = [SRV_PFX + c for c in SMS_CTL]

# Each output's value in power-on reset (PwrOk 0, Rstn 0, TRSTN1 0, DFTTM 0, TSEL1 11, TMS1 1):
# the spec's reset values (DTR_CFG 32'h003F_FFA5, DTR_LPDDR 0, DTR_TM 0), DFTTM low (spec 11.3:
# every scan output 0, DFTSO Hi-Z enable 0) and sheet JTAG1 row 67 (an unselected TAP sees TMS 1).
RESET = {"arc_tms1": "1'b1", "pcia_tms1": "1'b1", "pcib_tms1": "1'b1", "scan_resetn": "1'b1"}

L = []
a = L.append
a("// tb_dir.sv -- generated by dv_dir/gen_tb_dir.py; do not edit.")
a("// Self-checking directed bench for soc_dft. Expected values come from the architect workbook")
a("// of 25 Nov 2026 and the SOC_DFT block specification; dv_dir/gen_tb_dir.py names each source.")
a("`timescale 1ns/1ps")
a("module tb_dir;")
LOOPED = set()
for d, w, n in ports:
    a(f"  logic {w + ' ' if w else ''}{n};")
a("")
a("  soc_dft u_dut (.*);")
a("")
a("  // Block models: every block returns its scan-in on its scan-out (a wire per lane), so a lane")
a("  // that reaches a block comes back on DFTSO. With inj = 1 every scan-out is all ones instead,")
a("  // to show which return bits reach DFTSO at all.")
a("  logic inj = 1'b0;")
for b in BLOCKS:
    p = PORT[b][0]
    so = p.replace("_si", "_so")
    a(f"  assign {so} = inj ? '1 : {p};")
    LOOPED.add(so)
    w = WRAP[b][0]
    so = w.replace("_si", "_so")
    a(f"  assign {so} = inj ? 1'b1 : {w};")
    LOOPED.add(so)
a("  assign ddr_test_so = inj ? '1 : ddr_test_si;")
LOOPED.add("ddr_test_so")
a("")
a(f"  logic [{NOBS - 1}:0] obs;")
a("  assign obs = {ddr_test_si, " + ", ".join(reversed(WOBS)) + ", " + ", ".join(reversed(OBS)) + "};")
a("")
a("  // every output of the DUT, for the X check")
a("  logic [" + str(sum(pwid[n] for n in OUTS) - 1) + ":0] all_outs;")
a("  assign all_outs = {" + ", ".join(OUTS) + "};")
a("")
a("  int unsigned checks = 0, fails = 0, tfails = 0, tchecks = 0, tests = 0, tpass = 0;")
a("  string cur;")
a("  task automatic chk(input bit ok, input string what, input string src);")
a("    checks++; tchecks++;")
a("    if (!ok) begin fails++; tfails++; $display(\"CHECK FAIL %s: %s [%s]\", cur, what, src); end")
a("  endtask")
a("  task automatic tstart(input string n); cur = n; tfails = 0; tchecks = 0; tests++; $display(\"TEST START %s\", n); endtask")
a("  task automatic tend();")
a("    $display(\"PT %s checks=%0d cycles=0\", cur, tchecks);")
a("    if (tfails == 0) begin tpass++; $display(\"TEST PASS %s\", cur); end")
a("    else $display(\"TEST FAIL %s (%0d checks failed)\", cur, tfails);")
a("  endtask")
a("")
a("  function automatic int exp_obs(input int m, input int i);")
a("    exp_obs = -1;")
a("    case (m)")
for m in MODES:
    items = [(i, exp_obs(m, i)) for i in range(20) if exp_obs(m, i) >= 0]
    a(f"      {m}: case (i)")
    for i, e in items:
        a(f"             {i}: exp_obs = {e};")
    a("             default: ;")
    a("           endcase")
a("      default: ;")
a("    endcase")
a("  endfunction")
a("  function automatic int ext_obs(input int i);")
a("    ext_obs = -1;")
a("    case (i)")
for i in range(11):
    a(f"      {i}: ext_obs = {ext_obs(i)};   // {WRAP[BLOCKS[i]][0]}")
a("      default: ;")
a("    endcase")
a("  endfunction")
a("  function automatic string src_of(input int m);")
a("    case (m)")
for m, s in SRC.items():
    a(f"      {m}: src_of = \"{s}\";")
a("      default: src_of = \"\";")
a("    endcase")
a("  endfunction")
masks = {m: sum(1 << i for i in range(20) if exp_obs(m, i) >= 0) for m in MODES}
masks[7] = sum(1 << i for i in range(11))
a("  function automatic logic [19:0] ret_mask(input int m);")
a("    case (m)")
for m in range(8):
    a(f"      {m}: ret_mask = 20'h{masks[m]:05x};")
a("      default: ret_mask = '0;")
a("    endcase")
a("  endfunction")
a("")
a("""  // ------------------------------------------------------------------ JTAG
  // TSEL1 = 11: TDI1 -> SMS TAP -> SOC_DFT TAP -> TDO1 (spec 8.4); TDO launched on the
  // falling edge, TDI sampled on the rising edge (spec Table 48).
  task automatic tck(input bit tms, input bit tdi, output bit tdo);
    TMS1 = tms; TDI1 = tdi;
    #25 tdo = TDO1;
    TCK1 = 1'b1; #50 TCK1 = 1'b0; #25;
  endtask
  task automatic tms_seq(input int n, input logic [15:0] bits);   // bits[0] first
    bit d;
    for (int k = 0; k < n; k++) tck(bits[k], 1'b0, d);
  endtask
  task automatic tap_reset();
    TRSTN1 = 1'b0; #100 TRSTN1 = 1'b1; #100;
    tms_seq(6, 16'b011111);            // five 1s to Test-Logic-Reset, then Run-Test/Idle
  endtask
  // IR scan from Run-Test/Idle: the SOC_DFT TAP IR (5 bits, LSB first) then the SMS TAP IR
  // (4 ones, BYPASS); returns the first 5 bits seen on TDO (the SOC_DFT TAP's capture)
  task automatic ir_scan(input logic [4:0] ir, output logic [4:0] cap);
    bit d; logic [8:0] v;
    v = {4'b1111, ir};
    tms_seq(4, 16'b0011);              // Select-DR, Select-IR, Capture-IR, Shift-IR
    for (int k = 0; k < 9; k++) begin tck(k == 8, v[k], d); if (k < 5) cap[k] = d; end
    tms_seq(2, 16'b01);                // Update-IR, Run-Test/Idle
  endtask
  // DR scan from Run-Test/Idle of n bits (LSB first); returns what came out of TDO and the
  // two PHY WSI levels seen just before each rising edge
  logic [127:0] wsi0_seen, wsi1_seen;
  task automatic dr_scan(input int n, input logic [127:0] din, output logic [127:0] dout);
    bit d;
    dout = '0; wsi0_seen = '0; wsi1_seen = '0;
    tms_seq(3, 16'b001);               // Select-DR, Capture-DR, Shift-DR
    for (int k = 0; k < n; k++) begin
      TMS1 = (k == n - 1); TDI1 = din[k];
      #25 dout[k] = TDO1; wsi0_seen[k] = phy0_WSI; wsi1_seen[k] = phy1_WSI;
      TCK1 = 1'b1; #50 TCK1 = 1'b0; #25;
    end
    tms_seq(2, 16'b01);                // Update-DR, Run-Test/Idle
  endtask
  // write a 32-bit DTR (the SMS TAP in BYPASS adds one bit) and return what it held
  task automatic dtr_rw(input logic [4:0] code, input logic [31:0] v, output logic [31:0] old);
    logic [4:0] cap; logic [127:0] dout;
    ir_scan(code, cap);
    dr_scan(33, {95'd0, 1'b0, v}, dout);
    old = dout[31:0];
  endtask

  // The twelve PHY TDR enables, counted at each rising TCK1 edge (the PHY samples them on
  // TDRCLK = TCK1, sheet Connect row 166)
  int en_cnt[12];
  logic [11:0] en_vec;
  assign en_vec = {""" + ", ".join(reversed(PHY_EN)) + """};
  always @(posedge TCK1) for (int k = 0; k < 12; k++) if (en_vec[k]) en_cnt[k]++;
  task automatic en_clear(); for (int k = 0; k < 12; k++) en_cnt[k] = 0; endtask
""")
a("  initial begin")
for d, w, n in ports:
    if d == "input" and n not in LOOPED:
        a(f"    {n} = '0;")
a("    // power-on: PwrOk, Rstn and TRSTN1 start low (t_power_on releases them)")
a("    PwrOk = 1'b0; Rstn = 1'b0; TRSTN1 = 1'b0; TSEL1 = 2'b11; TMS1 = 1'b1; DFTMAX = 1'b1;")
a("    #200;")

# ---------------------------------------------------------------- t_power_on
a("""
    // ---------------------------------------------------------- power-on reset
    // In reset with TCK1 running, every output holds its reset value and none is unknown;
    // after release the DTRs read their reset values (spec Tables 50, 51; DTR_TM 0).
    tstart("t_power_on");
    begin
      logic [31:0] old;
      for (int k = 0; k < 4; k++) begin TCK1 = 1'b1; #50 TCK1 = 1'b0; #50; end
      chk(!$isunknown(all_outs), $sformatf("an output is unknown in power-on reset: %h", all_outs), "spec 11.3: defined outputs in reset");""")
for n in OUTS:
    e = RESET.get(n, "'0")
    a(f"      chk({n} == {e}, $sformatf(\"{n} %h in power-on reset\", {n}), \"spec 11.3; sheet JTAG1 row 67\");")
a("""      PwrOk = 1'b1;
      for (int k = 0; k < 4; k++) begin TCK1 = 1'b1; #50 TCK1 = 1'b0; #50; end
      TRSTN1 = 1'b1; #50 Rstn = 1'b1; #50;
      chk(!$isunknown(all_outs), $sformatf("an output is unknown after release: %h", all_outs), "spec 11.3");
      chk(rst_n == 1'b1, "rst_n follows Rstn after release", "spec: Rst_n_test = Rstn with RST_OVR 0 at reset");
      tap_reset();
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG at power-on %h, expected 003FFFA5", old), "spec Table 50 reset value");
      dtr_rw(5'b00011, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_LPDDR at power-on %h, expected 0", old), "spec Table 51 reset value");
      dtr_rw(@TMIR@, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_TM at power-on %h, expected 0", old), "sheet STM rows 17-31: every test_mode 00");
    end
    tend();
""")

# ---------------------------------------------------------------- tests
a("""
    // ---------------------------------------------------------- modes 0-6, lane by lane
    tstart("t_modes_lanes");
    for (int m = 0; m < 7; m++) begin
      DFTTM = 1'b0; DeMuxSel = m[2:0]; #10 DFTTM = 1'b1;
      for (int i = 0; i < 20; i++) begin
        int e;
        DFTSI = 20'd1 << i; #10;
        e = exp_obs(m, i);
        chk(obs == ((e >= 0) ? (""" + str(NOBS) + """'(1) << e) : '0),
            $sformatf("mode %0d SI lane %0d: block ports %h, expected only bit %0d", m, i, obs, e), src_of(m));
        chk(DFTSO == ((e >= 0) ? (20'd1 << i) : '0),
            $sformatf("mode %0d SI lane %0d: DFTSO %h, expected %h", m, i, DFTSO, (e >= 0) ? (20'd1 << i) : 20'd0),
            {src_of(m), "; unused lanes drive 0"});
      end
    end
    DFTSI = '0; DFTTM = 1'b0; DeMuxSel = 3'd0; #10;
    tend();

    // ---------------------------------------------------------- mode 7, EXTEST
    tstart("t_mode7_extest");
    DFTTM = 1'b0; DeMuxSel = 3'd7; #10 DFTTM = 1'b1;
    for (int i = 0; i < 20; i++) begin
      int e;
      DFTSI = 20'd1 << i; #10;
      e = ext_obs(i);
      chk(obs == ((e >= 0) ? (""" + str(NOBS) + """'(1) << e) : '0),
          $sformatf("mode 7 SI lane %0d: block ports %h, expected only bit %0d", i, obs, e), "sheet STM row 11; spec 12.5: block b on pin b");
      chk(DFTSO == ((e >= 0) ? (20'd1 << i) : '0),
          $sformatf("mode 7 SI lane %0d: DFTSO %h", i, DFTSO), "sheet STM row 11; lanes 11-19 drive 0");
    end
    DFTSI = '0; DFTTM = 1'b0; DeMuxSel = 3'd0; #10;
    tend();

    // ---------------------------------------------------------- returns with no lane
    // Every block scan-out all ones, DFTSI 0: DFTSO shows exactly the return bits a mode routes.
    tstart("t_unmapped_returns");
    inj = 1'b1;
    for (int m = 0; m < 8; m++) begin
      DFTTM = 1'b0; DeMuxSel = m[2:0]; DFTSI = '0; #10 DFTTM = 1'b1; #10;
      chk(DFTSO == ret_mask(m), $sformatf("mode %0d all returns 1: DFTSO %h, expected %h", m, DFTSO, ret_mask(m)),
          {src_of(m), "; unused lanes drive 0"});
    end
    inj = 1'b0; DFTTM = 1'b0; DeMuxSel = 3'd0; #10;
    tend();

    // ---------------------------------------------------------- DFTTM low
    tstart("t_dfttm_low_quiet");
    for (int m = 0; m < 8; m++) begin
      DFTTM = 1'b0; DeMuxSel = m[2:0]; DFTSI = '1; DFTSE = 1'b1; #10;
      chk(obs == '0 && DFTSO == '0, $sformatf("mode %0d DFTTM 0: ports %h DFTSO %h, expected 0", m, obs, DFTSO),
          "spec 11.3: nothing moves while DFTTM is low");
      chk(DFTSO_OE == 1'b0, "DFTSO_OE 0 while DFTTM is low", "spec: DFTSO Hi-Z in functional mode");
      chk(top_scan_shift_en == 1'b0, "top_scan_shift_en 0 while DFTTM is low", "release 18 Nov: DFTSE in EXTEST only");
      DFTTM = 1'b1; #10;
      chk(DFTSO_OE == 1'b1, "DFTSO_OE 1 while DFTTM is high", "spec: DFTSO driven in test");
    end
    DFTSI = '0; DFTSE = 1'b0; DFTTM = 1'b0; DeMuxSel = 3'd0; #10;
    tend();

    // ---------------------------------------------------------- TAP
    tstart("t_tap_reset_idcode_bypass");
    begin
      logic [4:0] cap; logic [127:0] dout;
      tap_reset();
      dr_scan(64, '0, dout);
      chk(dout[31:0] == 32'h0000_0001, $sformatf("IDCODE after TAP reset %h, expected 00000001", dout[31:0]),
          "spec 9.4: default IDCODE 32'h0000_0001; Test-Logic-Reset loads IDCODE");
      chk(dout[63:33] == 31'h0000_8000 && dout[32] == 1'b1, $sformatf("SMS stub IDCODE %h, expected 00010001", dout[64:33]),
          "spec 14.6: stub IDCODE 32'h0001_0001");
      ir_scan(5'b00001, cap);
      chk(cap == 5'b00001, $sformatf("IR capture %b, expected 00001", cap), "spec 9.4: Capture-IR loads 1");
      dr_scan(64, '0, dout);
      chk(dout[31:0] == 32'h0000_0001, $sformatf("IDCODE by IR 00001 %h", dout[31:0]), "spec Table 46");
      ir_scan(5'b11111, cap);
      dr_scan(18, 128'h0_A5C3, dout);
      chk(dout[1:0] == 2'b00, $sformatf("BYPASS captured bits %b, expected 00", dout[1:0]), "spec 9.4: BYPASS captures 0");
      chk(dout[17:2] == 16'hA5C3, $sformatf("BYPASS through 2 devices %h", dout[17:2]), "spec Table 46");
      // a reserved code selects BYPASS (spec Table 46: all others); 01001 is reserved since the
      // architect gave DTR_TM the code 01010 (25 Nov 2026)
      ir_scan(5'b01001, cap);
      dr_scan(18, 128'h0_3C5A, dout);
      chk(dout[17:2] == 16'h3C5A, $sformatf("reserved IR 01001 %h, expected BYPASS", dout[17:2]), "architect 25 Nov 2026: DTR_TM is 01010, 01001 is BYPASS");
      ir_scan(5'b10011, cap);
      dr_scan(18, 128'h0_9669, dout);
      chk(dout[17:2] == 16'h9669, $sformatf("reserved IR 10011 %h, expected BYPASS", dout[17:2]), "spec Table 46: all others BYPASS");
    end
    tend();

    // ---------------------------------------------------------- TAP pause states
    // IDCODE read with a Pause-DR / Exit2-DR detour, then an IR scan through Pause-IR / Exit2-IR:
    // the data must come out whole (IEEE 1149.1 state machine, spec 9.3).
    tstart("t_tap_pause_states");
    begin
      bit d; logic [63:0] got; logic [4:0] cap;
      tap_reset();
      got = '0;
      tms_seq(3, 16'b001);                         // Select-DR, Capture-DR, Shift-DR
      for (int k = 0; k < 16; k++) begin tck(k == 15, 1'b0, d); got[k] = d; end   // Exit1-DR
      tms_seq(4, 16'b0100);                        // Pause-DR, Pause-DR, Exit2-DR, Shift-DR
      for (int k = 16; k < 64; k++) begin tck(k == 63, 1'b0, d); got[k] = d; end
      tms_seq(2, 16'b01);                          // Update-DR, Run-Test/Idle
      chk(got[31:0] == 32'h0000_0001, $sformatf("IDCODE through Pause-DR %h", got[31:0]), "spec 9.3");
      // IR scan with a pause: load BYPASS (11111 + stub 1111)
      tms_seq(4, 16'b0011);                        // Select-DR, Select-IR, Capture-IR, Shift-IR
      for (int k = 0; k < 4; k++) tck(k == 3, 1'b1, d);   // 4 bits, Exit1-IR
      tms_seq(4, 16'b0100);                        // Pause-IR x2, Exit2-IR, Shift-IR
      for (int k = 0; k < 5; k++) tck(k == 4, 1'b1, d);
      tms_seq(2, 16'b01);                          // Update-IR, Run-Test/Idle
      begin
        logic [127:0] dout;
        dr_scan(18, 128'h0_F00F, dout);
        chk(dout[17:2] == 16'hF00F, $sformatf("BYPASS after a paused IR scan %h", dout[17:2]), "spec 9.3; Table 46");
      end
      // Exit1-IR straight to Update-IR, and Select-IR back to Test-Logic-Reset
      ir_scan(5'b00001, cap);
      tms_seq(3, 16'b111);                         // Select-DR, Select-IR, Test-Logic-Reset
      tms_seq(1, 16'b0);                           // Run-Test/Idle
      begin
        logic [127:0] dout;
        dr_scan(32, '0, dout);
        chk(dout[31:0] == 32'h0000_0001, "IDCODE after Select-IR to TLR", "spec 9.4: TLR loads IDCODE");
      end
      // Capture-DR -> Exit1-DR -> Update-DR (no shift), and Exit2-DR -> Update-DR; the same
      // detours on the IR side. The IDCODE read after them must still be whole (spec 9.3).
      tms_seq(5, 16'b01101);         // Select-DR, Capture-DR, Exit1-DR, Update-DR, Run-Test/Idle
      tms_seq(8, 16'b01101001);      // Select-DR, Capture-DR, Shift-DR, Exit1-DR, Pause-DR, Exit2-DR, Update-DR, RTI
      tms_seq(9, 16'b011010011);     // Select-DR, Select-IR, Capture-IR, Shift-IR, Exit1-IR, Pause-IR, Exit2-IR, Update-IR, RTI
      tms_seq(6, 16'b011011);        // Select-DR, Select-IR, Capture-IR, Exit1-IR, Update-IR (IR = captured IDCODE), RTI
      begin
        logic [127:0] dout;
        dr_scan(64, {64'd0, 64'hFFFF_FFFF_FFFF_FFFF}, dout);
        chk(dout[31:0] == 32'h0000_0001 && dout[63:32] == 32'h0001_0001,
            $sformatf("IDCODEs after the detours %h %h", dout[63:32], dout[31:0]), "spec 9.3; 9.4; 14.6");
      end
      // the SMS stub's IR loaded with 0000 (a code it does not decode): BYPASS (spec 9.1, 14.6)
      begin
        bit d2; logic [8:0] v; logic [127:0] dout;
        v = {4'b0000, 5'b11111};
        tms_seq(4, 16'b0011);
        for (int k = 0; k < 9; k++) tck(k == 8, v[k], d2);
        tms_seq(2, 16'b01);
        dr_scan(18, 128'h0_6CC6, dout);
        chk(dout[17:2] == 16'h6CC6, $sformatf("stub IR 0000: %h, expected BYPASS on both devices", dout[17:2]),
            "spec 14.6: stub has IDCODE and BYPASS only; unknown codes select BYPASS");
      end
      // TRSTN1 in the middle of Shift-DR returns the TAP to TLR (spec 9.3)
      tms_seq(3, 16'b001);
      for (int k = 0; k < 5; k++) tck(1'b0, 1'b1, d);
      TRSTN1 = 1'b0; #20 TRSTN1 = 1'b1; #20;
      tms_seq(1, 16'b0);
      begin
        logic [127:0] dout;
        dr_scan(32, '0, dout);
        chk(dout[31:0] == 32'h0000_0001, "IDCODE after TRSTN1 in Shift-DR", "spec 9.4: TRSTN1 loads IDCODE");
      end
    end
    tend();

    // ---------------------------------------------------------- DTR_TM bit map
    // sheet STM rows 17-31: [1:0] scc ... [21:20] axim, [22] loopback, [31:23] reserved (read 0).
    tstart("t_dtr_tm_bitmap");
    begin
      logic [31:0] v, old;
      tap_reset();
      for (int c = 0; c < 5; c++) begin
        v = '0;
        for (int b = 0; b < 11; b++) v[2*b +: 2] = 2'((b + c) % 4);
        if (c == 4) v[21:0] = 22'h2A_AAAA;
        v[31:23] = 9'h1FF;                 // reserved: written 1, must read 0
        DFTTM = 1'b0;
        dtr_rw(@TMIR@, v, old);          // DTR_TM (IR 01010)
        DFTTM = 1'b1; #10;
""")
for k, b in enumerate(BLOCKS):
    p, row = TMPORT[b]
    a(f"        chk({p} == v[{2*k + 1}:{2*k}], $sformatf(\"code %0d: {p} %b, expected %b\", c, {p}, v[{2*k + 1}:{2*k}]),")
    a(f"            \"sheet STM row {19 + k}: [{2*k + 1}:{2*k}] {b}; sheet Connect row {row}\");")
a("""        DFTTM = 1'b0; #10;
""")
for b in BLOCKS:
    p = TMPORT[b][0]
    a(f"        chk({p} == 2'b00, \"{p} 00 while DFTTM is low\", \"spec 11.3; block table: mission TMODE 00\");")
a("""        dtr_rw(@TMIR@, v, old);
        chk(old == {9'h000, v[22:0]}, $sformatf("DTR_TM readback %h, expected %h", old, {9'h000, v[22:0]}),
            "sheet STM rows 19-31: 23 bits used, [31:23] reserved");
      end
      dtr_rw(@TMIR@, 32'h0, old);
    end
    tend();

    // ---------------------------------------------------------- pad loopback
    tstart("t_loopback");
    begin
      logic [31:0] old;
      tap_reset();
      DFTTM = 1'b0;
      dtr_rw(@TMIR@, 32'h0040_0000, old);  // loopback_test_mode, DTR_TM[22]
      for (int m = 0; m < 8; m++) begin
        DeMuxSel = m[2:0]; DFTTM = 1'b1;
        for (int k = 0; k < 4; k++) begin
          DFTSI = (k == 0) ? 20'hA_5A5A : (k == 1) ? 20'h5_A5A5 : (k == 2) ? 20'hF_FFFF : 20'h0_0000; #10;
          chk(DFTSO == DFTSI, $sformatf("mode %0d loopback: DFTSO %h, DFTSI %h", m, DFTSO, DFTSI),
              "sheet STM row 30: [22] loopback_test_mode, before every mode");
          chk(obs == '0, $sformatf("mode %0d loopback feeds a block", m), "spec: no block fed in loopback");
        end
        DFTTM = 1'b0; #10;
      end
      DFTSI = '0;
      dtr_rw(@TMIR@, 32'h0, old);
    end
    tend();

    // ---------------------------------------------------------- top_scan_shift_en
    tstart("t_top_scan_shift_en");
    for (int m = 0; m < 8; m++) begin
      for (int c = 0; c < 4; c++) begin
        DFTTM = 1'b0; DeMuxSel = m[2:0]; #10;
        DFTTM = c[1]; DFTSE = c[0]; #10;
        chk(top_scan_shift_en == ((m == 7) && c[1] && c[0]),
            $sformatf("mode %0d DFTTM %0d DFTSE %0d: top_scan_shift_en %b", m, c[1], c[0], top_scan_shift_en),
            "release 18 Nov: DFTSE in EXTEST (mode 7) only");
      end
    end
    DFTTM = 1'b0; DFTSE = 1'b0; DeMuxSel = 3'd0; #10;
    tend();

    // ---------------------------------------------------------- JTAG1: TMS parking
    // sheet JTAG1 rows 41-50 and note row 67: TSEL1[1:0] selects one target; every other
    // external TAP sees TMS = 1 (held in Test-Logic-Reset), at either DFTTM value.
    tstart("t_jtag1_tms_park");
    for (int s = 0; s < 4; s++) begin
      for (int t = 0; t < 2; t++) begin
        for (int q = 0; q < 2; q++) begin
          TSEL1 = s[1:0]; DFTTM = t[0]; TMS1 = q[0]; #10;
""")
for tg, code in JT:
    a(f"          chk({tg}_tms1 == ((s == {code}) ? q[0] : 1'b1),")
    a(f"              $sformatf(\"TSEL1 %0d DFTTM %0d TMS1 %0d: {tg}_tms1 %b\", s, t, q, {tg}_tms1),")
    a(f"              \"sheet JTAG1 rows 41-50, note row 67\");")
a("""        end
      end
    end
    // TSEL1 at each value with TCK1 running: the parked targets' enables stay 0 on TDO1_OE and
    // DTR_STS samples TSEL1 through its synchroniser (spec Table 52 bits 3:2)
    for (int s = 0; s < 4; s++) begin
      bit d;
      TSEL1 = s[1:0]; TMS1 = 1'b0; DFTTM = 1'b0;
      for (int k = 0; k < 3; k++) tck(1'b0, 1'b0, d);
      chk(TDO1_OE == 1'b0, $sformatf("TSEL1 %0d with TCK1 running, targets idle: TDO1_OE %b", s, TDO1_OE),
          "sheet JTAG1 rows 47-50");
    end
    TSEL1 = 2'b11; DFTTM = 1'b0; TMS1 = 1'b1; #10;
    tend();


    // ---------------------------------------------------------- JTAG1: TDO return
    // sheet JTAG1 rows 47-63: TDO1 and TDO1_OE come from the selected target. The unselected
    // targets are parked (their TDO enable 0); their TDO data is driven opposite to show that
    // it cannot reach TDO1.
    tstart("t_jtag1_tdo_return");
    for (int s = 0; s < 3; s++) begin
      for (int v = 0; v < 4; v++) begin
        TSEL1 = s[1:0];
""")
for tg, code in JT:
    a(f"        {tg}_tdo1 = (s == {code}) ? v[0] : ~v[0];")
    a(f"        {tg}_tdo1_oe = (s == {code}) ? v[1] : 1'b0;")
a("""        #10;
        chk(TDO1 == v[0] && TDO1_OE == v[1], $sformatf("TSEL1 %0d: TDO1 %b TDO1_OE %b, expected %b %b", s, TDO1, TDO1_OE, v[0], v[1]),
            "sheet JTAG1 rows 47-63; sheet Connect rows 57-58, 225-226, 248-249");
      end
    end
    // TSEL1 = 11: the SOC_DFT chain, idle in Run-Test/Idle; the parked targets' TDO does not reach TDO1
    TSEL1 = 2'b11;
""")
for tg, _ in JT:
    a(f"    {tg}_tdo1 = 1'b1; {tg}_tdo1_oe = 1'b0;")
a("""    #10;
    chk(TDO1_OE == 1'b0, $sformatf("TSEL1 11 idle: TDO1_OE %b", TDO1_OE), "spec 9.4: TDO enabled in Shift only");
""")
for tg, _ in JT:
    a(f"    {tg}_tdo1 = 1'b0;")
a("""    tend();

    // ---------------------------------------------------------- DDR TDR
    // sheet Connect rows 168-176, 187-195; spec 15.4 and Table 46: one register per DDRx code;
    // capture, shift and update enables follow the TAP state, launched on the falling edge;
    // WSI = TDI through the SMS stub in BYPASS (one bit later); TDO = the addressed TDR's Tdo.
    // architect 25 Nov 2026: all of it works at either DFTTM value, gated only by DDR_TDR_EN.
    tstart("t_ddr_tdr");
    begin
      logic [31:0] old; logic [4:0] cap; logic [127:0] dout; logic [15:0] pat;
      tap_reset();
      DFTTM = 1'b0;
      dtr_rw(5'b00010, 32'h007F_FFA5, old);   // DTR_CFG: reset value with DDR_TDR_EN (bit 22)
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG reset value %h", old), "spec Table 50: reset 32'h003F_FFA5");
      for (int t = 0; t < 2; t++) begin
      DFTTM = t[0]; #10;
""")
CON_TDO = {(0, "Cmd"): 175, (0, "RdData"): 176, (1, "Cmd"): 194, (1, "RdData"): 195}
for ir, phy, reg, src in DDR_IR:
    ci = PHY_EN.index(f"phy{phy}_DdrPhyCsr{reg}TdrCaptureEn")
    si = PHY_EN.index(f"phy{phy}_DdrPhyCsr{reg}TdrShiftEn")
    ui = PHY_EN.index(f"phy{phy}_DdrPhyCsr{reg}TdrUpdateEn")
    sel_tdo = PHY_TDO[(phy, reg)]
    others = [v for k, v in PHY_TDO.items() if k != (phy, reg)]
    a(f"      // {src}")
    a(f"      for (int pv = 0; pv < 2; pv++) begin")
    a(f"        {sel_tdo} = pv[0]; " + " ".join(f"{o} = ~pv[0];" for o in others))
    a(f"        ir_scan({ir}, cap);")
    a(f"        en_clear(); pat = (pv == 0) ? 16'hC35A : 16'h1E87;")
    a(f"        dr_scan(16, {{112'd0, pat}}, dout);")
    a(f"        #100;")
    a(f"        chk(dout[15:0] == (pv[0] ? 16'hFFFF : 16'h0000), $sformatf(\"{ir}: TDO %h, expected the addressed Tdo %b\", dout[15:0], pv[0]),")
    a(f"            \"{src}; sheet Connect row {CON_TDO[(phy, reg)]}\");")
    a(f"        for (int k = 0; k < 12; k++) begin")
    a(f"          int e;")
    a(f"          e = (k == {ci}) ? 1 : (k == {si}) ? 16 : (k == {ui}) ? 1 : 0;")
    a(f"          chk(en_cnt[k] == e, $sformatf(\"{ir}: enable %0d high for %0d TCK1 cycles, expected %0d\", k, en_cnt[k], e),")
    a(f"              \"spec 15.4: capture 1, shift n, update 1 for the addressed TDR only\");")
    a(f"        end")
    a(f"        chk(wsi{phy}_seen[15:0] == {{pat[14:0], 1'b0}}, $sformatf(\"{ir}: phy{phy}_WSI %h, expected %h\", wsi{phy}_seen[15:0], {{pat[14:0], 1'b0}}),")
    a(f"            \"spec 15.4: WSI = TDI through the SMS stub BYPASS bit; sheet Connect row {174 if phy == 0 else 193}\");")
    a(f"        chk(wsi{1 - phy}_seen[15:0] == 16'h0, \"{ir}: the other PHY's WSI stays 0\", \"spec 15.4\");")
    a(f"      end")
a("""      // DDR_TDR_EN = 0: no enable and no WSI moves, at either DFTTM value
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      ir_scan(5'b00101, cap);
      en_clear();
      dr_scan(16, 128'hFFFF, dout);
      #100;
      for (int k = 0; k < 12; k++) chk(en_cnt[k] == 0, $sformatf("DFTTM %0d DDR_TDR_EN 0: enable %0d moved", t, k), "spec Table 50 bit 22");
      chk(wsi0_seen[15:0] == 16'h0, $sformatf("DFTTM %0d DDR_TDR_EN 0: phy0_WSI moved", t), "spec Table 50 bit 22");
      dtr_rw(5'b00010, 32'h007F_FFA5, old);   // DDR_TDR_EN set again for the next pass
      end
      DFTTM = 1'b0; #10;
      // DFTTM rising in Shift-DR: the TAP keeps shifting and the shift enable keeps following
      // it; no capture or update enable moves (architect 25 Nov 2026: no DFTTM guard)
      dtr_rw(5'b00010, 32'h007F_FFA5, old);
      ir_scan(5'b00111, cap);
      tms_seq(3, 16'b001);                      // Shift-DR
      begin
        bit d;
        for (int k = 0; k < 4; k++) tck(1'b0, 1'b1, d);
        en_clear();
        DFTTM = 1'b1; #10;
        chk(phy1_WSI == 1'b1, "phy1_WSI still follows TDI once DFTTM is high", "architect 25 Nov 2026; spec 15.4");
        for (int k = 0; k < 6; k++) tck(1'b0, 1'b1, d);   // the TAP keeps shifting in test
        #100;
        for (int k = 0; k < 12; k++)
          chk(en_cnt[k] == ((k == @P1CS@) ? 6 : 0),
              $sformatf("DFTTM rise in Shift-DR: enable %0d high at %0d rising edges", k, en_cnt[k]),
              "architect 25 Nov 2026: the enables follow the TAP at any DFTTM value");
        chk(en_vec == (12'h001 << @P1CS@), $sformatf("DFTTM rise in Shift-DR: enables %h, expected the shift enable only", en_vec),
            "spec 15.4: the shift enable is high in Shift-DR");
        DFTTM = 1'b0; #10;
      end
      // TRSTN1 clears a set enable at once (asynchronous, spec 15.4). The TAP reset also clears
      // DTR_CFG (architect 25 Nov 2026), so DDR_TDR_EN is written again.
      tap_reset();
      dtr_rw(5'b00010, 32'h007F_FFA5, old);
      ir_scan(5'b00101, cap);
      tms_seq(3, 16'b001);
      begin
        bit d;
        tck(1'b0, 1'b0, d);
        chk(phy0_DdrPhyCsrCmdTdrShiftEn == 1'b1, "phy0 Cmd shift enable high in Shift-DR", "spec 15.4");
        TRSTN1 = 1'b0; #5;
        chk(phy0_DdrPhyCsrCmdTdrShiftEn == 1'b0, "TRSTN1 clears the shift enable at once", "spec 15.4: asynchronous reset");
        TRSTN1 = 1'b1; #20;
      end
      tap_reset();
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
""")
for (p, r), n in PHY_TDO.items():
    a(f"      {n} = 1'b0;")
a("""    end
    tend();

    // ---------------------------------------------------------- LPDDR statics
    // spec Table 51; sheet Connect rows 150-152 (sms_dm0..2), 164-165 (ring_bypass,
    // sfp_dft_mode), 178 and 196 (BurnIn), 177 (scan_ctl: tied 00, at-speed scan not used).
    tstart("t_lpddr_statics");
    begin
      logic [31:0] old, v;
      tap_reset();
      DFTTM = 1'b0;
      dtr_rw(5'b00010, 32'h003F_FFB5, old);   // DTR_CFG with BURNIN (bit 4)
      for (int k = 0; k < 7; k++) begin
        v = (k == 0) ? 32'h0001_5550 : (k == 1) ? 32'h0002_AAA0 : (k == 2) ? 32'h0003_FFF0 :
            (k == 3) ? 32'hFFFC_0000 : (k == 4) ? 32'h0000_4030 : (k == 5) ? 32'h0000_000F : 32'h0;
        dtr_rw(5'b00011, v, old);
        chk({sms_dm2, sms_dm1, sms_dm0} == v[16:14], $sformatf("sms_dm %b, expected %b", {sms_dm2, sms_dm1, sms_dm0}, v[16:14]),
            "spec Table 51: {sms_dm2, sms_dm1, sms_dm0} = bits 16:14");
        chk(""" + SRV_PFX + """ring_bypass == v[13:7],
            $sformatf("ring_bypass %h, expected %h", """ + SRV_PFX + """ring_bypass, v[13:7]),
            "spec Table 51; sheet Connect row 164");
        chk(""" + SRV_PFX + """sfp_dft_mode == v[6], "sfp_dft_mode = DTR_LPDDR[6]",
            "spec Table 51; sheet Connect row 165");
        chk(phy0_BurnIn == 1'b0 && phy1_BurnIn == 1'b0, "BurnIn 0 while DFTTM is low", "spec: BurnIn = DFTTM & BURNIN & bit");
        DFTTM = 1'b1; #10;
        chk(phy0_BurnIn == v[4] && phy1_BurnIn == v[5], $sformatf("BurnIn %b%b, expected %b%b", phy1_BurnIn, phy0_BurnIn, v[5], v[4]),
            "spec Table 51; sheet Connect rows 178, 196");
        chk(scan_ctl == 2'b00, "scan_ctl 00", "sheet r0.62 row 153: at-speed scan not used, tied 00");
        DFTTM = 1'b0; #10;
        dtr_rw(5'b00011, v, old);
        chk(old == (v & 32'h0003_FFFF), $sformatf("DTR_LPDDR readback %h, expected %h", old, v & 32'h0003_FFFF),
            "spec Table 51: bits 31:18 read 0");
      end
      // BURNIN = 0 holds BurnIn at 0 whatever DTR_LPDDR says
      dtr_rw(5'b00011, 32'h0000_0030, old);
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      DFTTM = 1'b1; #10;
      chk(phy0_BurnIn == 1'b0 && phy1_BurnIn == 1'b0, "BurnIn 0 with DTR_CFG.BURNIN = 0", "spec Table 50 bit 4");
      DFTTM = 1'b0; #10;
      dtr_rw(5'b00011, 32'h0, old);
    end
    tend();

    // ---------------------------------------------------------- DTR_CFG: CLR, write guard, PwrOk
    tstart("t_dtr_cfg_clr_guard_pwrok");
    begin
      logic [31:0] old; logic [4:0] cap; bit d;
      tap_reset();
      DFTTM = 1'b0;
      dtr_rw(5'b00010, 32'h0012_3456, old);
      dtr_rw(5'b00011, 32'h0001_2345, old);
      dtr_rw(5'b00010, 32'h8000_0000, old);     // CLR
      chk(old == 32'h0012_3456, $sformatf("DTR_CFG before CLR %h", old), "spec Table 50: write and read back");
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG after CLR %h, expected the reset value", old), "spec Table 50: CLR");
      dtr_rw(5'b00011, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_LPDDR after CLR %h, expected 0", old), "spec Table 50: CLR");
      // DFTTM rising during a DTR_CFG shift: the TAP goes on to Update-DR in test, and the
      // shadow loads what was shifted (architect 25 Nov 2026: the DTRs load at any DFTTM)
      ir_scan(5'b00010, cap);
      tms_seq(3, 16'b001);
      for (int k = 0; k < 32; k++) tck(1'b0, ((32'h0001_2306 >> k) & 32'h1) != 0, d);   // DTR_CFG bits, LSB first
      DFTTM = 1'b1; #10;
      tck(1'b1, 1'b0, d);                       // the SMS stub's BYPASS bit; Exit1-DR
      tms_seq(2, 16'b01);                       // Update-DR (in test), Run-Test/Idle
      DFTTM = 1'b0; #10;
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h0001_2306, $sformatf("DTR_CFG after Update-DR in test %h, expected 00012306", old),
          "architect 25 Nov 2026: the DTRs load at any DFTTM value");
      // TRSTN1 resets the shadows, as PwrOk does (architect 25 Nov 2026)
      dtr_rw(5'b00010, 32'h0001_0003, old);
      tap_reset();
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG after TRSTN1 %h, expected the reset value", old),
          "architect 25 Nov 2026: TRST1_n clears the DTR shadows");
      // PwrOk low with TCK1 running: DTR_STS.PWROK reads 0 (spec Table 52 bit 7; the DTR_STS
      // register has no reset, so it still captures), then the shadows are back at reset
      PwrOk = 1'b0; #100;
      dtr_rw(5'b00100, 32'h0, old);
      chk(old[7] == 1'b0, $sformatf("DTR_STS.PWROK %b while PwrOk is low", old[7]), "spec Table 52 bit 7");
      PwrOk = 1'b1; #100;
      tap_reset();
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG after PwrOk %h, expected the reset value", old), "spec 10.1: PwrOk resets");
    end
    tend();

    // ---------------------------------------------------------- CLR clears DTR_TM
    // architect 25 Nov 2026: DTR_CFG.CLR also returns DTR_TM to its reset value (every test_mode
    // 00, loopback off), at the same Update-DR as DTR_CFG and DTR_LPDDR, at any DFTTM value; a
    // DTR_TM write in test loads and drives the outputs at once. Loopback is observed in mode 4,
    // whose lanes 19:16 carry no block (0 unless looped).
    tstart("t_clr_clears_dtr_tm");
    begin
      logic [31:0] old;
      tap_reset();
      DFTTM = 1'b1; DeMuxSel = 3'd4; #10;
      // a DTR_TM write with DFTTM high loads and drives the ports
      dtr_rw(@TMIR@, 32'h0055_5555, old);      // every test_mode 01, loopback on
      DFTSI = 20'hF_0000; #10;
      chk(DFTSO == 20'hF_0000, $sformatf("DTR_TM written in test: DFTSO %h, loopback must be on", DFTSO), "architect 25 Nov 2026: the DTRs load at any DFTTM value");
""")
for b in BLOCKS:
    p = TMPORT[b][0]
    a(f"      chk({p} == 2'b01, \"DTR_TM written in test: {p} must be 01\", \"architect 25 Nov 2026: the DTRs load at any DFTTM value\");")
a("""      // CLR written with DFTTM high clears DTR_TM at once
      dtr_rw(5'b00010, 32'h8000_0000, old);
      #10;
      chk(DFTSO == 20'h0_0000, $sformatf("CLR in test: DFTSO %h, loopback must be off", DFTSO), "architect 25 Nov 2026: CLR at any DFTTM value");
""")
for b in BLOCKS:
    p = TMPORT[b][0]
    a(f"      chk({p} == 2'b00, \"CLR in test: {p} must be 00\", \"architect 25 Nov 2026: CLR at any DFTTM value\");")
a("""      DFTSI = '0; DFTTM = 1'b0; #10;
      // CLR written with DFTTM low: DTR_TM returns to reset with DTR_CFG and DTR_LPDDR
      dtr_rw(@TMIR@, 32'h0055_5555, old);
      dtr_rw(5'b00010, 32'h8000_0000, old);
      DFTTM = 1'b1; DFTSI = 20'hF_0000; #10;
      chk(DFTSO == 20'h0_0000, $sformatf("after CLR: DFTSO %h, loopback must be off", DFTSO), "architect 25 Nov 2026: CLR clears DTR_TM");
""")
for b in BLOCKS:
    p = TMPORT[b][0]
    a(f"      chk({p} == 2'b00, \"after CLR: {p} must be 00\", \"architect 25 Nov 2026: CLR clears DTR_TM\");")
a("""      DFTSI = '0; DFTTM = 1'b0; DeMuxSel = 3'd0; #10;
      dtr_rw(@TMIR@, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_TM after CLR %h, expected 0", old), "architect 25 Nov 2026: CLR clears DTR_TM");
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG after CLR %h", old), "spec Table 50: CLR");
    end
    tend();

    // ---------------------------------------------------------- DTR_STS
    // spec Table 52. PLL_RDY (6:4) has no source (no PLL signal into SOC DFT, clock sheet) and
    // reads 0; RTL_REV 8'h06.
    tstart("t_dtr_sts");
    begin
      logic [31:0] old;
      tap_reset();
      DFTTM = 1'b0;
      for (int k = 0; k < 2; k++) begin
        DFTMAX = k[0]; #10;
        dtr_rw(5'b00010, (k == 0) ? 32'h003F_FFA5 : 32'h003F_FFAB, old);
        dtr_rw(5'b00100, k[0] ? 32'hFFFF_FFFF : 32'h0, old);   // capture only: what is shifted in is lost
        dtr_rw(5'b00100, k[0] ? 32'h0 : 32'hFFFF_FFFF, old);
        chk(old[0] == 1'b0, "DTR_STS.DFTTM 0 (DFTTM held low here)", "spec Table 52 bit 0");
        chk(old[1] == k[0], $sformatf("DTR_STS.DFTMAX_COMP %b with DFTMAX %0d", old[1], k), "spec Table 52 bit 1");
        chk(old[3:2] == 2'b11, "DTR_STS.TSEL1 = 11", "spec Table 52 bits 3:2");
        chk(old[6:4] == 3'b000, "DTR_STS.PLL_RDY = 000", "clock sheet: no PLL-ready signal into SOC DFT");
        chk(old[7] == 1'b1, "DTR_STS.PWROK = 1", "spec Table 52 bit 7");
        chk(old[11:8] == ((k == 0) ? 4'd5 : 4'd11), $sformatf("DTR_STS.PART %0d", old[11:8]), "spec Table 52: copy of DTR_CFG.PART");
        chk(old[15:12] == 4'd6, $sformatf("DTR_STS.NPART %0d", old[15:12]), "spec Table 52: NPART");
        chk(old[23:16] == 8'h06, $sformatf("DTR_STS.RTL_REV %h, expected 06", old[23:16]), "RTL revision 06");
        chk(old[31:24] == 8'h00, "DTR_STS bits 31:24 read 0", "spec Table 52");
      end
      DFTMAX = 1'b1;
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
    end
    tend();

    // ---------------------------------------------------------- LPDDR resets
    // architect 25 Nov 2026: rst_n = DFTTM ? (RST_OVR ? RST_VAL : Rstn) : Rstn (sheet Connect
    // row 154), so RST_OVR is ignored while DFTTM is low; scan_resetn = DFTTM ? rst_n : 1 (row 155).
    tstart("t_lpddr_resets");
    begin
      logic [31:0] old;
      tap_reset();
      for (int o = 0; o < 2; o++) begin
        for (int vv = 0; vv < 2; vv++) begin
          DFTTM = 1'b0;
          dtr_rw(5'b00010, 32'h003F_FF25 | (o[0] << 6) | (vv[0] << 7), old);
          for (int r = 0; r < 2; r++) begin
            for (int t = 0; t < 2; t++) begin
              logic e;
              Rstn = r[0]; DFTTM = t[0]; #10;
              e = (t[0] && o[0]) ? vv[0] : r[0];
              chk(rst_n == e, $sformatf("DFTTM %0d RST_OVR %0d RST_VAL %0d Rstn %0d: rst_n %b", t, o, vv, r, rst_n),
                  "architect 25 Nov 2026: override in test only; sheet Connect row 154");
              chk(scan_resetn == (t[0] ? e : 1'b1), $sformatf("DFTTM %0d: scan_resetn %b", t, scan_resetn), "spec; sheet Connect row 155");
            end
          end
        end
      end
      Rstn = 1'b1; DFTTM = 1'b0; #10;
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
    end
    tend();

    // ---------------------------------------------------------- DTR_TM instruction code
    // architect 25 Nov 2026: DTR_TM is reached at IR 01010; 01001 is an undecoded code and
    // selects BYPASS (spec Table 46: all others), and a DR scan under it leaves DTR_TM alone.
    tstart("t_dtr_tm_ir_code");
    begin
      logic [31:0] old; logic [4:0] cap; logic [127:0] dout;
      tap_reset();
      DFTTM = 1'b0;
      dtr_rw(@TMIR@, 32'h0015_5555, old);
      dtr_rw(@TMIR@, 32'h0015_5555, old);
      chk(old == 32'h0015_5555, $sformatf("DTR_TM by IR 01010 %h, expected 00155555", old), "architect 25 Nov 2026: IR_DTR_TM = 01010");
      ir_scan(5'b01001, cap);
      chk(cap == 5'b00001, $sformatf("IR capture %b, expected 00001", cap), "spec 9.4");
      dr_scan(34, {94'd0, 34'h2_AAAA_AAAA}, dout);
      chk(dout[33:2] == 32'hAAAA_AAAA && dout[1:0] == 2'b00, $sformatf("IR 01001: %h, expected BYPASS through 2 devices", dout[33:0]),
          "architect 25 Nov 2026: 01001 acts as BYPASS");
      dtr_rw(@TMIR@, 32'h0, old);
      chk(old == 32'h0015_5555, $sformatf("DTR_TM after a DR scan under IR 01001 %h, expected kept", old),
          "architect 25 Nov 2026: 01001 does not address DTR_TM");
    end
    tend();

    // ---------------------------------------------------------- SMS / SOC_DFT TAP in test
    // architect 25 Nov 2026: with TSEL1 = 11 the SMS and SOC_DFT TAPs follow TMS1 at DFTTM = 1,
    // a DTR write in test loads and drives its outputs, CLR acts, and the PHY TDR enables and
    // WSI follow the TAP whenever DDR_TDR_EN is set (and stay 0 when it is not).
    tstart("t_sms_tap_dfttm");
    begin
      logic [31:0] old; logic [4:0] cap; logic [127:0] dout;
      DFTTM = 1'b1; TSEL1 = 2'b11; #10;
      tap_reset();
      dtr_rw(5'b00010, 32'h007F_FFA5, old);    // DDR_TDR_EN written with DFTTM high: loads
      tms_seq(6, 16'b011111);                  // TMS1 walks both TAPs to Test-Logic-Reset in test, then RTI
      dr_scan(64, '0, dout);
      chk(dout[31:0] == 32'h0000_0001 && dout[63:32] == 32'h0001_0001,
          $sformatf("IDCODEs in test %h %h", dout[63:32], dout[31:0]), "architect 25 Nov 2026: TAP usable with DFTTM = 1");
      ir_scan(5'b11111, cap);
      chk(cap == 5'b00001, $sformatf("IR capture in test %b", cap), "spec 9.4");
      dr_scan(18, 128'h0_5AA5, dout);
      chk(dout[17:2] == 16'h5AA5, $sformatf("BYPASS in test %h", dout[17:2]), "spec Table 46");
      dtr_rw(5'b00100, 32'h0, old);
      chk(old[0] == 1'b1, $sformatf("DTR_STS.DFTTM %b read in test", old[0]), "spec Table 52 bit 0");
      chk(old[3:2] == 2'b11, "DTR_STS.TSEL1 = 11 in test", "spec Table 52 bits 3:2");
      // a PHY TDR scan in test with DDR_TDR_EN = 1: the enables and WSI follow the TAP
      ir_scan(5'b00101, cap);
      en_clear();
      dr_scan(16, 128'h3C5A, dout);
      #100;
      for (int k = 0; k < 12; k++) begin
        int e;
        e = (k == @P0CC@) ? 1 : (k == @P0CS@) ? 16 : (k == @P0CU@) ? 1 : 0;
        chk(en_cnt[k] == e, $sformatf("DFTTM 1 DDR_TDR_EN 1: PHY TDR enable %0d high %0d cycles, expected %0d", k, en_cnt[k], e),
            "architect 25 Nov 2026: PHY TDR access at any DFTTM value");
      end
      chk(wsi0_seen[15:0] == {15'h3C5A, 1'b0}, $sformatf("DFTTM 1: phy0_WSI %h, expected %h", wsi0_seen[15:0], {15'h3C5A, 1'b0}),
          "architect 25 Nov 2026: WSI follows TDI at any DFTTM value");
      // a DTR write in test loads and drives its outputs at once
      dtr_rw(5'b00010, 32'h0012_3456, old);
      chk(old == 32'h007F_FFA5, $sformatf("DTR_CFG read in test %h", old), "spec Table 50: Capture-DR loads the shadow");
      dtr_rw(5'b00010, 32'h0012_3456, old);
      chk(old == 32'h0012_3456, $sformatf("DTR_CFG after a write in test %h, expected 00123456", old),
          "architect 25 Nov 2026: the DTRs load at any DFTTM value");
      chk(rst_n == 1'b0, "DTR_CFG written in test: RST_OVR 1, RST_VAL 0 drive rst_n 0", "architect 25 Nov 2026");
      dtr_rw(@TMIR@, 32'h0015_5555, old);
      chk(pciea_test_mode == 2'b01 && axim_test_mode == 2'b01, "DTR_TM written in test drives the test_mode ports", "architect 25 Nov 2026");
      dtr_rw(@TMIR@, 32'h0015_5555, old);
      chk(old == 32'h0015_5555, $sformatf("DTR_TM after a write in test %h", old), "architect 25 Nov 2026");
      // DDR_TDR_EN = 0 (DTR_CFG 00123456 has bit 22 clear): a PHY TDR scan in test moves nothing
      ir_scan(5'b00101, cap);
      en_clear();
      dr_scan(16, 128'hFFFF, dout);
      #100;
      for (int k = 0; k < 12; k++) chk(en_cnt[k] == 0, $sformatf("DFTTM 1 DDR_TDR_EN 0: PHY TDR enable %0d moved", k), "spec Table 50 bit 22");
      chk(wsi0_seen[15:0] == 16'h0, "DFTTM 1 DDR_TDR_EN 0: phy0_WSI moved", "spec Table 50 bit 22");
      // CLR in test
      dtr_rw(5'b00010, 32'h8000_0000, old);
      dtr_rw(@TMIR@, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_TM after CLR in test %h", old), "architect 25 Nov 2026: CLR at any DFTTM value");
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG after CLR in test %h", old), "architect 25 Nov 2026: CLR at any DFTTM value");
""")
for tg, _ in JT:
    a(f"      chk({tg}_tms1 == 1'b1, \"TSEL1 11 in test: {tg}_tms1 parked at 1\", \"sheet JTAG1 note row 67\");")
a("""      DFTTM = 1'b0; #10;
      tap_reset();
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
    end
    tend();

    // ---------------------------------------------------------- TRSTN1 clears the DTRs
    // architect 25 Nov 2026: TRST1_n clears DTR_TM, DTR_CFG and DTR_LPDDR to their reset values,
    // as PwrOk does; the clear is asynchronous and is released on TCK1 (test rule: keep TRSTN1
    // high during scan, or the test-mode bits are cleared).
    tstart("t_trst_clears_dtrs");
    begin
      logic [31:0] old;
      tap_reset();
      DFTTM = 1'b0; Rstn = 1'b1;
      dtr_rw(5'b00010, 32'h003F_FF65, old);    // RST_OVR 1, RST_VAL 0
      dtr_rw(5'b00011, 32'h0001_C000, old);    // sms_dm = 111
      dtr_rw(@TMIR@, 32'h0015_5555, old);      // every test_mode 01
      DFTTM = 1'b1; #10;
      chk(rst_n == 1'b0, "rst_n = RST_VAL 0 in test before TRSTN1", "architect 25 Nov 2026");
      chk({sms_dm2, sms_dm1, sms_dm0} == 3'b111, "sms_dm 111 before TRSTN1", "spec Table 51");
""")
for b in BLOCKS:
    p = TMPORT[b][0]
    a(f"      chk({p} == 2'b01, \"{p} 01 before TRSTN1\", \"sheet STM rows 19-29\");")
a("""      TRSTN1 = 1'b0; #10;
      chk(rst_n == 1'b1, "TRSTN1 low: DTR_CFG at reset at once, rst_n follows Rstn", "architect 25 Nov 2026: TRST1_n clears DTR_CFG");
      chk({sms_dm2, sms_dm1, sms_dm0} == 3'b000, "TRSTN1 low: sms_dm 000 at once", "architect 25 Nov 2026: TRST1_n clears DTR_LPDDR");
""")
for b in BLOCKS:
    p = TMPORT[b][0]
    a(f"      chk({p} == 2'b00, \"TRSTN1 low: {p} 00 at once\", \"architect 25 Nov 2026: TRST1_n clears DTR_TM\");")
a("""      begin
        bit d;
        for (int k = 0; k < 3; k++) tck(1'b1, 1'b0, d);   // TCK1 running while TRSTN1 is low
      end
      chk(rst_n == 1'b1 && {sms_dm2, sms_dm1, sms_dm0} == 3'b000, "TRSTN1 low with TCK1 running: still at reset", "architect 25 Nov 2026");
      DFTTM = 1'b0; #10;
      tap_reset();
      dtr_rw(5'b00010, 32'h003F_FFA5, old);
      chk(old == 32'h003F_FFA5, $sformatf("DTR_CFG after TRSTN1 %h", old), "spec Table 50 reset value");
      dtr_rw(5'b00011, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_LPDDR after TRSTN1 %h", old), "spec Table 51 reset value");
      dtr_rw(@TMIR@, 32'h0, old);
      chk(old == 32'h0, $sformatf("DTR_TM after TRSTN1 %h", old), "sheet STM rows 17-31: reset 0");
    end
    tend();

    // ---------------------------------------------------------- SMS ports, 25 Nov sheet
    // One wrapper set per block instance (sheet Connect rows in the SMS table of dv_dir/gen_tb_dir.py):
    // every control and index_based_repair is 0 (spec 14.6: the stub drives every wrapper control
    // 0), each WSO reaches its own bit of the SMS shell and no other, and the SMS shell is
    // clocked by TCK1 (clock sheet).
    tstart("t_sms_ports_25nov");
    begin
      int seen = 0, same = 0;
""")
WSO_ALL = [SMS_PFX + n + "_WSO" for n, *_ in SMS] + [SRV_PFX + "WSO"]
SHELL = [(sh, bit) for _, _, _, sh, bit in SMS] + [("ddr_sms_out", None)]


def shell_ref(sh, bit):
    return f"u_dut.u_sms_srv.{sh}" + (f"[{bit}]" if bit is not None else "")


for k, w in enumerate(WSO_ALL):
    a(f"      // {w}")
    for j, w2 in enumerate(WSO_ALL):
        a(f"      {w2} = 1'b{1 if j == k else 0};")
    a("      #10;")
    rows = SMS[k][1] if k < len(SMS) else "158-165"
    for j, (sh, bit) in enumerate(SHELL):
        a(f"      chk({shell_ref(sh, bit)} == 1'b{1 if j == k else 0}, \"{w} = 1: {shell_ref(sh, bit)} %b\", \"sheet Connect rows {rows}\");")
    for c in SMS_CTL_PORTS + SRV_CTL:
        a(f"      chk({c} == 1'b0, \"{c} idle 0\", \"spec 14.6 stub\");")
for w in WSO_ALL:
    a(f"      {w} = 1'b0;")
a("""      for (int k = 0; k < 8; k++) begin
        TCK1 = k[0]; #5;
        seen++;
        if (u_dut.u_sms_srv.tck1 === TCK1) same++;
      end
      TCK1 = 1'b0;
      chk(same == seen, $sformatf("SMS server clock followed TCK1 %0d of %0d samples", same, seen), "clock sheet: TCK1 into SOC DFT and SMS");
    end
    tend();

    $display("BENCH tests=%0d pass=%0d checks=%0d failed_checks=%0d", tests, tpass, checks, fails);
    $finish;
  end
endmodule""")
SUBST = {"@P1CS@": "phy1_DdrPhyCsrCmdTdrShiftEn", "@P0CC@": "phy0_DdrPhyCsrCmdTdrCaptureEn",
         "@P0CS@": "phy0_DdrPhyCsrCmdTdrShiftEn", "@P0CU@": "phy0_DdrPhyCsrCmdTdrUpdateEn"}
for k, v in SUBST.items():
    L = [x.replace(k, str(PHY_EN.index(v))) for x in L]
L = [x.replace("@TMIR@", TMIR) for x in L]
open(os.path.join(HERE, "tb_dir.sv"), "w", encoding="utf-8", newline="\n").write("\n".join(L) + "\n")
print(f"wrote dv_dir/tb_dir.sv ({len(ports)} DUT ports, observed vector {NOBS} bits)")
