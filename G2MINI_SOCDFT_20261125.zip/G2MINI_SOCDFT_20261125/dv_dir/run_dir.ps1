# Build and run the dv_dir bench on Verilator (with line and toggle coverage) and on Icarus
# Verilog (4-state), then the port-list check; print a summary per simulator and the coverage
# of the files under rtl/.
#   powershell -ExecutionPolicy Bypass -File dv_dir\run_dir.ps1 [-Jobs 4] [-Sheet <workbook.xlsx>]
# -Sheet gives the architect workbook to the port-list check (else SOC_DFT_SHEET, else skipped).
# Everything is written to dv_dir\run (build output; not part of a delivery).
param([int]$Jobs = 4, [string]$Sheet = "")
$Pkg = Split-Path -Parent $PSScriptRoot
Set-Location $Pkg
if (-not $env:VERILATOR_ROOT) {
  $vb = Get-Command verilator_bin -ErrorAction SilentlyContinue
  if ($vb) { $env:VERILATOR_ROOT = Join-Path (Split-Path -Parent (Split-Path -Parent $vb.Source)) "share\verilator" }
}
$env:TEMP = Join-Path $Pkg "tmp"; $env:TMP = $env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null   # the compiler's scratch, inside this folder
if (-not $env:PYTHON3) {   # the build's helper scripts: the python3 shipped beside verilator_bin (a path with no spaces)
  $vb = Get-Command verilator_bin -ErrorAction SilentlyContinue
  if ($vb) { $p3 = Join-Path (Split-Path -Parent (Split-Path -Parent $vb.Source)) "lib\python3.exe"; if (Test-Path $p3) { $env:PYTHON3 = $p3 } }
}
# verilated.mk assigns PYTHON3 itself, so it is given to make as a command-line variable
if ($env:PYTHON3) { $env:MAKEFLAGS = "PYTHON3=" + ($env:PYTHON3 -replace '\\', '/') }
$out = Join-Path $Pkg "dv_dir\run"
New-Item -ItemType Directory -Force $out | Out-Null
Remove-Item -Force -ErrorAction SilentlyContinue "$out\coverage.dat", "$out\run.log", "$out\run_icarus.log", "$out\ivl.vvp"
python -I -X utf8 dv_dir\gen_tb_dir.py
$rtl = Get-Content rtl\soc_dft.f | Where-Object { $_ -match '^\s*rtl/' } | ForEach-Object { $_.Trim() }
(@($rtl) + @("dv_dir/tb_dir.sv")) | Set-Content -Encoding ascii "$out\dir.f"
# Verilator
cmd /c "verilator_bin --binary -j $Jobs --timing --coverage -sv -Wno-fatal -Wno-lint -Wno-style --top-module tb_dir -Mdir `"$out\obj`" -o Vdir -f `"$out\dir.f`" > `"$out\build.log`" 2>&1"
"verilator build exit=$LASTEXITCODE"
Push-Location $out
cmd /c "`"$out\obj\Vdir.exe`" +verilator+coverage+file+coverage.dat > `"$out\run.log`" 2>&1"
"verilator run exit=$LASTEXITCODE"
Pop-Location
# Icarus Verilog
cmd /c "iverilog -g2012 -s tb_dir -o `"$out\ivl.vvp`" -c `"$out\dir.f`" > `"$out\build_icarus.log`" 2>&1"
"icarus build exit=$LASTEXITCODE"
cmd /c "vvp -n `"$out\ivl.vvp`" > `"$out\run_icarus.log`" 2>&1"
"icarus run exit=$LASTEXITCODE"
python -I -X utf8 dv_dir\check_ports.py $Sheet | Set-Content -Encoding ascii "$out\ports.log"
python -I -X utf8 dv_dir\cov_summary.py "$out\coverage.dat" --uncovered --json "$out\coverage.json" | Set-Content -Encoding ascii "$out\coverage.txt"
foreach ($sim in @(@("verilator", "run.log"), @("icarus", "run_icarus.log"))) {
  $log = @(Get-Content (Join-Path $out $sim[1]) -ErrorAction SilentlyContinue)
  $log | Where-Object { $_ -match '^(TEST FAIL|CHECK FAIL)' } | ForEach-Object { "$($sim[0]): $_" }
  $tests = @($log | Where-Object { $_ -match '^TEST (PASS|FAIL)' }).Count
  $pass = @($log | Where-Object { $_ -match '^TEST PASS' }).Count
  $bench = @($log | Where-Object { $_ -match '^BENCH ' })
  "SUMMARY $($sim[0]) tests=$tests pass=$pass $($bench -join ' ')"
}
$ports = @(Get-Content "$out\ports.log")
$ports | Where-Object { $_ -match '^(TEST (PASS|FAIL)|CHECK FAIL|NOTE)' }
Get-Content "$out\coverage.txt" | Where-Object { $_ -match '^(COV|COVADJ|RULE_WRONG) ' }
