#!/bin/sh
# Run the dv_dir directed bench and the port-list check from the release folder:
#   sh dv_dir/run_dir.sh [<workbook.xlsx>]
set -e
cd "$(dirname "$0")/.."
mkdir -p dv_dir/run
python3 dv_dir/gen_tb_dir.py
{ grep -E '^\s*rtl/' rtl/soc_dft.f | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'; echo dv_dir/tb_dir.sv; } > dv_dir/run/dir.f
verilator --binary -j 0 --timing --coverage -sv -Wno-fatal -Wno-lint -Wno-style --top-module tb_dir \
  -Mdir dv_dir/run/obj -o Vdir -f dv_dir/run/dir.f > dv_dir/run/build.log 2>&1
(cd dv_dir/run && obj/Vdir +verilator+coverage+file+coverage.dat > run.log 2>&1) || true
iverilog -g2012 -s tb_dir -o dv_dir/run/ivl.vvp -c dv_dir/run/dir.f > dv_dir/run/build_icarus.log 2>&1
vvp -n dv_dir/run/ivl.vvp > dv_dir/run/run_icarus.log 2>&1 || true
python3 dv_dir/check_ports.py ${1:-} > dv_dir/run/ports.log
python3 dv_dir/cov_summary.py dv_dir/run/coverage.dat --uncovered --json dv_dir/run/coverage.json > dv_dir/run/coverage.txt
for s in run.log run_icarus.log; do echo "== $s"; grep -E '^(TEST (PASS|FAIL)|CHECK FAIL|BENCH )' dv_dir/run/$s; done
grep -E '^(TEST (PASS|FAIL)|CHECK FAIL|NOTE)' dv_dir/run/ports.log
grep -E '^(COV|COVADJ|RULE_WRONG) ' dv_dir/run/coverage.txt
