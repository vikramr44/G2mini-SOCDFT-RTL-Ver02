"""Summarise a Verilator coverage.dat for the files under rtl/ only.

Counts every coverage point of an rtl/ file by kind (the point's page: v_line, v_branch,
v_toggle, v_expr, v_user) and reports covered / total per kind and per file; "line" is
v_line + v_branch, which is what verilator_coverage --annotate counts as line coverage.
--uncovered prints every uncovered point (file, line, kind, hierarchy, comment).

Usage: python dv_dir/cov_summary.py <coverage.dat> [--uncovered] [--json <out>]
"""
import collections
import json
import re
import sys

path = sys.argv[1]
show = "--uncovered" in sys.argv
jout = sys.argv[sys.argv.index("--json") + 1] if "--json" in sys.argv else None

pts = []
with open(path, encoding="utf-8", errors="replace") as f:
    for ln in f:
        if not ln.startswith("C '"):
            continue
        body, cnt = ln.rstrip("\n").rsplit("' ", 1)
        body = body[3:]
        kv = {}
        for item in body.split("\x01")[1:]:
            k, _, v = item.partition("\x02")
            kv[k] = v
        fn = kv.get("f", "").replace("\\", "/")
        if "/rtl/" not in "/" + fn and not fn.startswith("rtl/"):
            continue
        kind = kv.get("page", "").split("/")[0]
        pts.append((fn, int(kv.get("l", 0)), kind, kv.get("h", ""), kv.get("o", ""), int(cnt)))

by_kind = collections.Counter()
hit_kind = collections.Counter()
by_file = collections.defaultdict(collections.Counter)
for fn, l, k, h, o, c in pts:
    by_kind[k] += 1
    hit_kind[k] += c > 0
    by_file[fn][k] += 1
    by_file[fn][k + "_hit"] += c > 0

# ---- structurally constant toggle points. Each rule names a net that the RTL ties to a
# constant, so no stimulus can toggle it; the reason is printed. A rule is (hierarchy, signal
# name, bits or None for all, reason[, direction]); with a direction ("0->1" or "1->0") it
# names that direction only. A point a rule names that DID toggle is reported as RULE_WRONG,
# so a rule cannot hide a coverable point silently.
U, R = "tb_dir.u_dut", "tb_dir.u_dut.g_router.u_scan_rtr"
SMS = "SMS stub: every wrapper control is tied 0 (spec 14.6; the generated SMS server is not in this design yet)"
RULES = []
for h in (U, U + ".u_sms_srv", U + ".u_sms_ports"):
    for s in ("pcia_sms_in", "pcib_sms_in", "g2muc_sms_in", "l4ga_sms_in", "l4gb_sms_in",
              "scc_sms_in", "hic_sms_in", "ahb_sms_in", "ddr_sms_in"):
        RULES.append((h, s, None, SMS))
RULES.append((None, re.compile(r"vl_sms_.*_(WSI|SelectWIR|ShiftWR|CaptureWR|UpdateWR|index_based_repair)$"), None, SMS))
RULES.append((None, re.compile(r"vl_srv_.*_(WSI|SelectWIR|ShiftWR|CaptureWR|UpdateWR)$"), None, SMS))
for s in ("dr_tdo_cfg", "dr_tdo_lpddr", "dr_tdo_sts", "dr_tdo_ddr", "dr_tdo_tm",
          "sel_cfg", "sel_lpddr", "sel_sts", "sel_ddr_any", "sel_tm"):
    RULES.append((U + ".u_sms_srv.u_stub", s, None, "stub TAP has no data register: tied 0"))
RULES.append((U + ".u_jtag1_rtr", "tm_o", None, "P_TM_OPEN = 0 (sheet JTAG1 row 67): the opening term is constant 0"))
MASKED = "reserved register bits, masked to 0 (spec Tables 50, 51; sheet STM row 31: write ignored, read 0)"
for h in (U, U + ".u_dtr", U + ".u_crg_ctl", U + ".u_mode_dec"):
    RULES.append((h, "dtr_cfg", set(range(23, 32)), MASKED))
    RULES.append((h, "dtr_lpddr", set(range(18, 32)), MASKED))
for h in (U, U + ".u_dtr_tm", U + ".u_mode_dec"):
    RULES.append((h, "dtr_tm", set(range(23, 32)), MASKED))
for s in ("shadow", "shadow_q"):
    RULES.append((U + ".u_dtr.u_cfg", s, set(range(23, 32)), MASKED))
    RULES.append((U + ".u_dtr.u_lpddr", s, set(range(18, 32)), MASKED))
    RULES.append((U + ".u_dtr_tm.u_tm", s, set(range(23, 32)), MASKED))
    RULES.append((U + ".u_dtr.u_sts", s, None, "DTR_STS has no shadow (P_HAS_SHADOW = 0): constant"))
RULES.append((U + ".u_dtr", "sts_shadow_unused", None, "DTR_STS has no shadow (P_HAS_SHADOW = 0): constant"))
RULES.append((U + ".u_mode_dec", "unused_dtr_tm_high", None, MASKED))
for h in (U + ".u_dtr.u_cfg", U + ".u_dtr.u_lpddr", U + ".u_dtr_tm.u_tm"):
    RULES.append((h, "capture_value", None, "a shadowed DTR captures its shadow; capture_value is tied 0"))
STS = "DTR_STS constant fields: PLL_RDY, NPART, RTL_REV, reserved (spec Table 52)"
STS_CONST1 = {13, 14, 17, 18}    # the 1 bits of NPART = 6 and RTL_REV = 8'h06: they rise once at start
STS_CONST = (set(range(4, 7)) | set(range(12, 32))) - STS_CONST1
for h, s in ((U + ".u_dtr.u_sts", "capture_value"), (U + ".u_dtr", "sts_capture")):
    RULES.append((h, s, STS_CONST, STS))
    RULES.append((h, s, STS_CONST1, STS + "; constant 1, never falls", "1->0"))
for h, s in ((U, "sts_levels"), (U + ".u_dtr", "sts_levels"), (U + ".u_dtr.u_dft_sync2_sts_dont_touch", "d"),
             (U + ".u_dtr", "sts_sync"), (U + ".u_dtr.u_dft_sync2_sts_dont_touch", "q"),
             (U + ".u_dtr.u_dft_sync2_sts_dont_touch", "stage0_q"),
             (U + ".u_dtr.u_dft_sync2_sts_dont_touch", "stage1_q")):
    RULES.append((h, s, {5, 6, 7}, "the three PLL-ready levels are tied 0 (no PLL signal into SOC DFT, clock sheet)"))
RULES.append((U + ".u_dtr.u_dft_sync2_sts_dont_touch", "rst_n", None,
              "synchroniser reset tied 1: constant 1, never falls", "1->0"))
for h in (U + ".u_dtr.u_sts",):
    RULES.append((h, "clr_req", None, "DTR_STS has no shadow, so CLR does not reach it; tied 0 here"))
for h, s in ((U, "scan_ctl"), (U + ".u_mode_dec", "lpddr_scan_ctl")):
    RULES.append((h, s, None, "scan_ctl tied 00: at-speed scan not used (sheet r0.62 row 153)"))
for h, s in ((U, "sel"), (U, "sel_dec"), (U + ".u_mode_dec", "sel"), (R, "sel")):
    RULES.append((h, s, {11, 12}, "no scan mode selects the LPDDR or TOP position (mode 0 routes LPDDR by lane)"))
RULES.append((R, "unused_sel_no_channel", None, "reads sel[12:11] only, which are constant"))
NOLANE = "lanes no block of the mode takes (sheet STM rows 8, 9, 11): drive 0"
RULES.append((R, "ext_so", set(range(11, 20)), NOLANE + "; mode 7 uses lanes 0-10"))
RULES.append((R, re.compile(r"axis_so_lanes\[\d\]"), set(range(8, 20)), "Axis is on lanes 7:0 in every mode"))
RULES.append((R, re.compile(r"g_axis_out\[\d\]\.lanes"), set(range(8, 20)), "Axis is on lanes 7:0 in every mode"))
STM0 = {4: set(range(16, 20)), 5: set(range(14, 20))}
for m, bits in STM0.items():
    RULES.append((R, f"stm_so[{m}]", bits, NOLANE))


def classify(h, o):
    m = re.match(r"(.*?)(?:\[(\d+)\])?:(0->1|1->0)$", o) or re.match(r"(.*?)(?:\[(\d+)\])?$", o)
    sig, bit = m.group(1), (int(m.group(2)) if m.group(2) else None)
    dirn = m.group(3) if m.lastindex and m.lastindex >= 3 else None
    for rule in RULES:
        rh, rs, rb, why = rule[:4]
        if len(rule) > 4 and rule[4] != dirn:
            continue
        if rh is not None and h != rh:
            continue
        if isinstance(rs, str):
            if sig != rs:
                continue
        elif not rs.fullmatch(sig) and not rs.search(sig):
            continue
        if rb is not None and (bit is None or bit not in rb):
            continue
        return why
    return None


const = collections.Counter()
const_pts = []
rule_wrong = []
for fn, l, k, h, o, c in pts:
    if k != "v_toggle":
        continue
    why = classify(h, o)
    if why is None:
        continue
    if c > 0:
        rule_wrong.append((fn, l, h, o, why))
    else:
        const[why] += 1
        const_pts.append((fn, l, h, o))

res = {}
for k in sorted(by_kind):
    res[k] = (hit_kind[k], by_kind[k])
res["line"] = (hit_kind["v_line"] + hit_kind["v_branch"], by_kind["v_line"] + by_kind["v_branch"])
for k, (h, n) in sorted(res.items()):
    print(f"COV {k:9s} {h:6d}/{n:<6d} {100.0 * h / n if n else 0:6.2f}%")
nconst = sum(const.values())
th, tn = res.get("v_toggle", (0, 0))
print(f"COVADJ v_toggle excluding {nconst} structurally constant points: {th}/{tn - nconst} "
      f"{100.0 * th / (tn - nconst) if tn - nconst else 0:6.2f}% (derived; the raw figure is the COV line)")
for why, n in const.most_common():
    print(f"CONST {n:5d} {why}")
for r in rule_wrong:
    print("RULE_WRONG {}:{} {} {} toggled but a rule calls it constant ({})".format(*r))
res["v_toggle_excl_const"] = (th, tn - nconst)
for fn in sorted(by_file):
    c = by_file[fn]
    parts = []
    for k in ("v_line", "v_branch", "v_toggle", "v_expr"):
        if c[k]:
            parts.append(f"{k[2:]} {c[k + '_hit']}/{c[k]}")
    print(f"COVFILE {fn}: " + ", ".join(parts))
if show:
    for fn, l, k, h, o, c in sorted(pts):
        if c == 0:
            tag = " [CONST]" if (k == "v_toggle" and classify(h, o)) else ""
            print(f"UNCOVERED {fn}:{l} {k} {h} {o}{tag}")
if jout:
    json.dump({"kinds": {k: {"covered": h, "total": n} for k, (h, n) in res.items()},
               "uncovered": [dict(file=fn, line=l, kind=k, hier=h, comment=o)
                             for fn, l, k, h, o, c in sorted(pts) if c == 0]},
              open(jout, "w", encoding="utf-8"), indent=1)
